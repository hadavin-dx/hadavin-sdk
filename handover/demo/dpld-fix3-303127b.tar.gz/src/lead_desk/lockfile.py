"""One desk per lead book."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import IO


def acquire(db_path: Path | str) -> IO[bytes]:
    """Open and hold `<db_path>.lock` non-blocking; return the open handle (keep it for the life of the process).

    Linux: fcntl.flock(fd, LOCK_EX | LOCK_NB). Windows: seek(0), then msvcrt.locking(fd, LK_NBLCK, 1) (one byte at
    offset 0). Platform branches use `sys.platform` so mypy strict passes on both systems; the imports sit inside
    the branches. A held lock raises OSError (the caller prints "another desk is using this database" and exits
    with constants.EXIT_ANOTHER_DESK)."""
    f = open(f"{db_path}.lock", "a+b")  # noqa: SIM115 (the handle is the lock; the caller keeps it)
    try:
        if sys.platform == "win32":
            import msvcrt

            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise
    return f
