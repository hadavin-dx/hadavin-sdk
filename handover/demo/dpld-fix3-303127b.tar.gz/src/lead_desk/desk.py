"""The desk API. Standard library only.

One SQLite connection per thread (threading.local); every write is BEGIN IMMEDIATE; no network call is made while a
transaction is open. Logs carry exception class names only (no addresses, no names)."""

from __future__ import annotations

import json
import logging
import secrets
import sqlite3
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Literal, TypeVar, cast

from lead_desk import db, identity
from lead_desk.config import Config
from lead_desk.constants import (
    HTTP_ACCEPTED,
    HTTP_BAD_REQUEST,
    HTTP_BUSY,
    HTTP_CONFLICT,
    HTTP_CREATED,
    HTTP_INTERNAL_ERROR,
    HTTP_NOT_FOUND,
    HTTP_OK,
    LEAD_ID_HEX_CHARS,
    LEAD_ID_PREFIX,
    LOCK_RETRIES,
)
from lead_desk.contract import (
    Crm,
    Outbox,
    OutboxModeMismatch,
    Qualifier,
    SendRefused,
    SendUnreachable,
)
from lead_desk.hooks import Hooks

log = logging.getLogger("lead_desk")
_T = TypeVar("_T")

HINTS = {
    "R": "Send a corrected submission with a NEW request id.",
    "D": "Informational only, no action needed.",
    "O": "Send the same request id again, or restart the desk.",
}
HINT_NOT_UNKNOWN = "Only a follow-up in state unknown can be resolved."
_RECEIPT_KEYS = (
    "receipt_id",
    "source",
    "source_ref",
    "payload",
    "attempts",
    "outcome",
    "outcome_lead_id",
    "outcome_reason",
    "differing_fields",
)
_RECEIPT_BY_ID = (
    "SELECT receipt_id, source, source_ref, payload, attempts, outcome, outcome_lead_id, outcome_reason,"
    " differing_fields FROM receipts WHERE receipt_id=?"
)
_ITEM_EXISTS = {
    "R": "SELECT 1 FROM receipts WHERE receipt_id=? AND outcome = 'review'",
    "D": "SELECT 1 FROM receipts WHERE receipt_id=? AND outcome = 'duplicate' AND differing_fields <> '[]'",
    "O": "SELECT 1 FROM receipts WHERE receipt_id=? AND outcome IS NULL",
}
_REVIEW_SQL = """
SELECT item_id, item_type, kind, reason, lead_id, since, source FROM (
  SELECT item_id, item_type, kind, reason, lead_id, since, source FROM review_items
  UNION ALL
  SELECT 'O' || receipt_id, 'receipt', 'stalled', 'open receipt', NULL, received_at, source
    FROM receipts WHERE outcome IS NULL AND received_at < :before
  UNION ALL
  SELECT 'F' || f.lead_id, 'followup', 'stalled', f.state, f.lead_id, f.updated_at, l.source
    FROM followups f JOIN leads l USING (lead_id) WHERE f.state IN ('pending','sending') AND f.updated_at < :before
) ORDER BY since, item_id
"""
_COUNTS_SQL = """
SELECT (SELECT count(*) FROM receipts),
       (SELECT count(*) FROM receipts WHERE outcome = 'new'),
       (SELECT count(*) FROM receipts WHERE outcome = 'duplicate'),
       (SELECT count(*) FROM receipts WHERE outcome = 'review'),
       (SELECT count(*) FROM receipts WHERE outcome IS NULL),
       (SELECT count(*) FROM followups WHERE state IN ('pending','sending'))
"""


def default_now() -> int:
    return int(time.time())


@dataclass
class Reply:
    status: int
    body: Any  # exactly the rows of the HTTP table in contract.md (a dict, or a list for GET /review)
    drive_lead_id: str | None = None  # set when the caller must now run the follow-up


class Desk:
    def __init__(
        self,
        config: Config,
        crm: Crm,
        outbox: Outbox,
        qualifier: Qualifier,
        hooks: Hooks | None = None,
        now: Callable[[], int] = default_now,
        schema_sql: str | None = None,  # test-only mutation seam
    ) -> None:
        self.config = config
        self.crm = crm
        self.outbox = outbox
        self.qualifier = qualifier
        self.hooks = hooks if hooks is not None else Hooks()
        self._now = now
        self._schema_sql = schema_sql
        self._local = threading.local()
        self._rejected = 0
        self._rejected_lock = threading.Lock()

    # -- plumbing
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = db.connect(self.config.db_path)
            self._local.conn = conn
        return cast(sqlite3.Connection, conn)

    @contextmanager
    def _write(self, conn: sqlite3.Connection) -> Iterator[None]:
        """BEGIN IMMEDIATE ... COMMIT; any exception (a simulated crash too) rolls back first."""
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield
            conn.execute("COMMIT")
        except BaseException:
            if conn.in_transaction:
                conn.rollback()
            raise

    def _locked_retry(self, fn: Callable[[], _T]) -> _T:
        """Run fn up to LOCK_RETRIES times while the database stays locked (each try already waited the busy time)."""
        for attempt in range(LOCK_RETRIES):
            try:
                return fn()
            except sqlite3.OperationalError as e:
                if not db.is_busy(e) or attempt == LOCK_RETRIES - 1:
                    raise
        raise RuntimeError("unreachable")

    def _error_reply(self, exc: Exception, receipt_id: int | None, with_receipt: bool = True) -> Reply:
        busy = db.is_busy(exc)
        log.warning("request failed: %s", type(exc).__name__)
        body: dict[str, Any] = {"error": "busy" if busy else "internal"}
        if with_receipt:
            body["receipt_id"] = receipt_id
        return Reply(HTTP_BUSY if busy else HTTP_INTERNAL_ERROR, body)

    def close(self) -> None:
        """Closes the calling thread's connection (the next use opens a new one)."""
        conn = getattr(self._local, "conn", None)
        self._local.conn = None
        if conn is not None:
            conn.close()

    def note_rejected_envelope(self) -> None:
        with self._rejected_lock:
            self._rejected += 1

    # -- start-up
    def startup(self) -> None:
        """init_schema, then the start-up sweep; call once."""
        conn = self._conn()
        db.init_schema(conn, self._schema_sql)
        # (1) finish every OPEN receipt from its stored payload
        open_ids = conn.execute("SELECT receipt_id FROM receipts WHERE outcome IS NULL ORDER BY receipt_id").fetchall()
        for (rid,) in open_ids:  # fetched first: _decide commits while this loop runs
            try:
                self._decide(int(rid))
            except Exception as e:  # the receipt stays open and shows as stalled
                log.warning("sweep: receipt left open: %s", type(e).__name__)
        # (2) the two `sending` rows of the transition table
        if self.outbox.capability == "keyed":
            new_state = "pending"
        else:
            new_state = "unknown"
        with self._write(conn):
            conn.execute(
                "UPDATE followups SET state=?, last_error='crash_while_sending', updated_at=? WHERE state='sending'",
                (new_state, self._now()),
            )
        # (3) drive every pending follow-up; run_followup catches its own errors
        for (lead_id,) in conn.execute(
            "SELECT lead_id FROM followups WHERE state='pending' ORDER BY lead_id"
        ).fetchall():
            self.run_followup(lead_id)

    # -- receipts and decisions
    def _receipt(self, conn: sqlite3.Connection, receipt_id: int) -> dict[str, Any] | None:
        row = conn.execute(_RECEIPT_BY_ID, (receipt_id,)).fetchone()
        return None if row is None else dict(zip(_RECEIPT_KEYS, row, strict=True))

    def _lookup_email_key(self, conn: sqlite3.Connection, email_key: str) -> str | None:
        """Called as self._lookup_email_key(conn, key): positional, via self, no inlining, no cached reference."""
        row = conn.execute("SELECT lead_id FROM leads WHERE email_key=?", (email_key,)).fetchone()
        return None if row is None else str(row[0])

    def _decide(self, receipt_id: int) -> tuple[dict[str, Any], bool]:
        """Transaction 2. Returns (receipt as stored afterwards, True when THIS call wrote the verdict)."""
        conn = self._conn()
        with self._write(conn):
            rec = self._receipt(conn, receipt_id)
            if rec is None:
                raise LookupError("receipt vanished")
            if rec["outcome"] is not None:  # another request or a restart finished it: nothing to write
                return rec, False
            now = self._now()
            chk = identity.check_payload(json.loads(rec["payload"]))
            if chk.kind == "review":
                conn.execute(
                    "UPDATE receipts SET outcome='review', outcome_reason=?, decided_at=? WHERE receipt_id=?",
                    (chk.reason, now, receipt_id),
                )
            else:
                if chk.email_key is None or chk.email is None or chk.name is None:
                    raise ValueError("checked payload is incomplete")
                existing = self._lookup_email_key(conn, chk.email_key)
                if existing is not None:
                    row = conn.execute(
                        "SELECT name, phone, company, message FROM leads WHERE lead_id=?", (existing,)
                    ).fetchone()
                    stored = dict(zip(("name", "phone", "company", "message"), row, strict=True))
                    diff = identity.diff_fields(
                        stored, {"name": chk.name, "phone": chk.phone, "company": chk.company, "message": chk.message}
                    )
                    conn.execute(
                        "UPDATE receipts SET outcome='duplicate', outcome_lead_id=?, differing_fields=?, decided_at=?"
                        " WHERE receipt_id=?",
                        (existing, json.dumps(diff), now, receipt_id),
                    )
                else:
                    lead_id = LEAD_ID_PREFIX + secrets.token_hex(LEAD_ID_HEX_CHARS // 2)
                    conn.execute(
                        "INSERT INTO leads(lead_id, receipt_id, source, name, email, email_key, phone, company,"
                        " message, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (lead_id, receipt_id, rec["source"], chk.name, chk.email, chk.email_key, chk.phone,
                         chk.company, chk.message, now),
                    )  # fmt: skip
                    conn.execute(
                        "INSERT INTO followups(lead_id, state, ai_label, attempts, last_error, updated_at, sent_at)"
                        " VALUES(?, 'pending', NULL, 0, NULL, ?, NULL)",
                        (lead_id, now),
                    )
                    conn.execute(
                        "UPDATE receipts SET outcome='new', outcome_lead_id=?, decided_at=? WHERE receipt_id=?",
                        (lead_id, now, receipt_id),
                    )
            self.hooks.crash_point("A2", conn)
        stored_rec = self._receipt(conn, receipt_id)
        if stored_rec is None:
            raise LookupError("receipt vanished")
        return stored_rec, True

    def _verdict_reply(self, rec: dict[str, Any], replayed: bool, payload_matches: bool | None) -> Reply:
        body: dict[str, Any] = {"receipt_id": rec["receipt_id"]}
        outcome = rec["outcome"]
        drive: str | None = None
        if outcome == "new":
            status = HTTP_CREATED
            body.update(verdict="new", lead_id=rec["outcome_lead_id"])
            if not replayed:
                drive = rec["outcome_lead_id"]
            elif self._followup_state(rec["outcome_lead_id"]) == "pending":
                drive = rec["outcome_lead_id"]  # a replay of `new` whose follow-up is still pending drives it
        elif outcome == "duplicate":
            status = HTTP_OK
            body.update(
                verdict="duplicate",
                lead_id=rec["outcome_lead_id"],
                differing_fields=json.loads(rec["differing_fields"]),
            )
        else:
            status = HTTP_ACCEPTED
            body.update(verdict="review", reason=rec["outcome_reason"])
        body["replayed"] = replayed
        if replayed:
            body["payload_matches"] = payload_matches
        return Reply(status, body, drive)

    def process(self, source: str, source_ref: str, payload: object) -> Reply:
        """Receipt and decision (envelope already checked); decision only; never raises (503/500 are Replies).

        Crash-point placement (crash_point(name, conn); each hook is one-shot: it fires once, then clears):
        "A"  right after transaction 1 commits (conn = that connection, no transaction open). It fires ONLY when
             THIS call created the receipt row; a replay that finds an existing receipt (open or with a verdict)
             never fires "A".
        "A2" in transaction 2 after all writes and before COMMIT (conn has the open transaction).
        "B"  at the end of process, after transaction 2 commits and before the Reply is returned (conn = that
             connection). It fires ONLY when THIS call committed transaction 2; a replay that finds a stored
             verdict never fires "B".
        process never claims a follow-up (it makes no `_claim` call); it only creates the follow-up in `pending`
        inside transaction 2."""
        rid: int | None = None
        try:
            conn = self._conn()
            canon = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
            with self._write(conn):  # transaction 1: the receipt, before anything else happens
                conn.execute(
                    "INSERT INTO receipts(source, source_ref, received_at, payload) VALUES(?,?,?,?)"
                    " ON CONFLICT(source, source_ref) DO UPDATE SET attempts = attempts + 1",
                    (source, source_ref, self._now(), canon),
                )
                found = conn.execute(
                    "SELECT receipt_id, attempts FROM receipts WHERE source=? AND source_ref=?", (source, source_ref)
                ).fetchone()
                rid = int(found[0])
                created = found[1] == 1  # this call created the row
            rec = self._receipt(conn, rid)
            if rec is None:
                raise LookupError("receipt vanished")
            matches = rec["payload"] == canon
            if created:
                self.hooks.crash_point("A", conn)
            if rec["outcome"] is not None:
                return self._verdict_reply(rec, True, matches)
            rec, decided_here = self._decide(rid)
            if not decided_here:
                return self._verdict_reply(rec, True, matches)
            self.hooks.crash_point("B", conn)
            return self._verdict_reply(rec, False, None)
        except Exception as e:
            return self._error_reply(e, rid)

    # -- follow-up
    def _followup_state(self, lead_id: str) -> str | None:
        row = self._conn().execute("SELECT state FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
        return None if row is None else str(row[0])

    def _prepare(self, lead_id: str) -> None:
        """Follow-up steps 1-2: the AI label (once), then the CRM row (idempotent by lead id)."""
        conn = self._conn()
        row = conn.execute(
            "SELECT l.name, l.email, l.email_key, l.company, l.source, ai_label"
            " FROM leads l JOIN followups f USING (lead_id) WHERE l.lead_id=?",
            (lead_id,),
        ).fetchone()
        if row is None:
            raise LookupError("no such lead")
        name, email, email_key, company, source, label = row
        if label is None:
            label = self.qualifier.qualify(lead_id, email_key)

            def store() -> None:
                with self._write(conn):
                    conn.execute(
                        "UPDATE followups SET ai_label=? WHERE lead_id=? AND ai_label IS NULL", (label, lead_id)
                    )

            self._locked_retry(store)
            label = conn.execute("SELECT ai_label FROM followups WHERE lead_id=?", (lead_id,)).fetchone()[0]
        record = {
            "lead_id": lead_id,
            "name": name,
            "email": email,
            "company": company or "",
            "source": source,
            "ai_label": label,
        }
        self.crm.put(lead_id, record)

    def run_followup(self, lead_id: str) -> None:
        """Follow-up steps 1-5 for one lead, as a fresh drive: steps 1-2, then the claim (step 3) as
        `self._claim(None, lead_id)` and, only if the claim returned True, `self._send_claimed(lead_id)` (steps 4-5).
        A lost claim (False) returns quietly. Catches Exception, logs the class name only; an exception in
        steps 1-2 is written by `self._fail_pending(lead_id, "internal:<class>")`. A follow-up that is not
        `pending` is left alone (nothing to drive). D1 and D2 live in `_send_claimed`."""
        try:
            if self._followup_state(lead_id) != "pending":
                return
            try:
                self._prepare(lead_id)
            except Exception as e:
                log.warning("follow-up steps 1-2 failed: %s", type(e).__name__)
                self._fail_pending(lead_id, f"internal:{type(e).__name__}")
                return
            if self._claim(None, lead_id):
                self._send_claimed(lead_id)
        except Exception as e:
            log.warning("follow-up failed: %s", type(e).__name__)

    def handle(self, source: str, source_ref: str, payload: object) -> Reply:
        """process, then run_followup if reply.drive_lead_id is set (tests use this)."""
        reply = self.process(source, source_ref, payload)
        if reply.drive_lead_id is not None:
            self.run_followup(reply.drive_lead_id)
        return reply

    def _claim(self, conn_or_none: sqlite3.Connection | None, lead_id: str) -> bool:
        """Owns its transaction; the UPDATE of step 3; True when exactly one row changed. Never leaves a
        transaction open. A lock that stays held through LOCK_RETRIES tries gives False (the item stays pending and
        shows as stalled)."""
        conn = self._conn() if conn_or_none is None else conn_or_none

        def attempt() -> bool:
            with self._write(conn):
                cur = conn.execute(
                    "UPDATE followups SET state='sending', attempts=attempts+1, updated_at=?"
                    " WHERE lead_id=? AND state IN ('pending','failed')",
                    (self._now(), lead_id),
                )
                return cur.rowcount == 1

        try:
            return self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            if db.is_busy(e):
                log.warning("claim gave up: database stayed locked")
                return False
            raise

    def _send_claimed(self, lead_id: str) -> None:
        """Follow-up steps 4-5 for a follow-up this thread has just claimed (state `sending`). Private; calls no claim.
        Crash points (conn=None for both; one-shot): "D1" after the claim committed and before outbox.send;
        "D2" after outbox.send returns and before the result is recorded. Send uses send_key=lead_id."""
        self.hooks.crash_point("D1", None)
        state: Literal["sent", "failed", "unknown"]
        err: str | None = None
        try:
            row = self._conn().execute("SELECT name, email FROM leads WHERE lead_id=?", (lead_id,)).fetchone()
            name, email = row
            self.outbox.send(
                lead_id,
                email,
                f"Thanks for getting in touch, {name}",
                f"Hi {name}, we received your message. (FAKE EMAIL)",
                self.config.send_timeout_seconds,
            )
            state = "sent"
        except OutboxModeMismatch:
            state, err = "failed", "mode_mismatch"
        except SendRefused:
            state, err = "failed", "refused"
        except SendUnreachable:
            state, err = "failed", "unreachable"
        except Exception as e:  # SendAmbiguous or anything unexpected: the email may have left
            log.warning("send ended unclear: %s", type(e).__name__)
            err = "ambiguous"
            state = "failed" if self.outbox.capability == "keyed" else "unknown"
        self.hooks.crash_point("D2", None)
        self._record_send_result(lead_id, state, err)

    def _fail_pending(self, lead_id: str, last_error: str) -> None:
        """Internal writer for the `pending` -> `failed` row (exception in step 1 or 2, nothing was sent):
        UPDATE ... WHERE lead_id=? AND state='pending'; a row count of 0 is logged and ignored."""
        conn = self._conn()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET state='failed', last_error=?, updated_at=?"
                    " WHERE lead_id=? AND state='pending'",
                    (last_error, self._now(), lead_id),
                ).rowcount

        self._finish_update(attempt, "fail_pending")

    def _record_send_result(
        self, lead_id: str, state: Literal["sent", "failed", "unknown"], last_error: str | None = None
    ) -> None:
        """Internal (not part of the HTTP or test API). Follow-up step 5 for rows in `sending` ONLY: UPDATE ...
        WHERE lead_id=? AND state='sending'; a row count of 0 is logged and ignored. A `sent` result clears
        last_error and sets sent_at."""
        conn = self._conn()
        now = self._now()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET state=?, last_error=?, updated_at=?, sent_at=? WHERE lead_id=?"
                    " AND state='sending'",
                    (state, None if state == "sent" else last_error, now, now if state == "sent" else None, lead_id),
                ).rowcount

        self._finish_update(attempt, "record_send_result")

    def _finish_update(self, attempt: Callable[[], int], what: str) -> None:
        try:
            changed = self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            if db.is_busy(e):
                log.warning("%s: database stayed locked; the row stays as it was and shows as stalled", what)
                return
            raise
        if changed != 1:
            log.warning("%s: expected one row, changed %d", what, changed)

    # -- review items, retry, resolve
    def _find_item(self, item_id: str) -> str | None:
        """'F', 'R', 'D' or 'O' when the item exists, else None (also for a malformed id)."""
        if not item_id[1:] or item_id[0] not in "FRDO":
            return None
        kind, ref = item_id[0], item_id[1:]
        conn = self._conn()
        if kind == "F":
            found = conn.execute("SELECT 1 FROM followups WHERE lead_id=?", (ref,)).fetchone()
        elif not (ref.isascii() and ref.isdecimal()):
            return None
        else:
            found = conn.execute(_ITEM_EXISTS[kind], (int(ref),)).fetchone()
        return kind if found else None

    @staticmethod
    def _not_actionable(kind: str) -> Reply:
        return Reply(HTTP_CONFLICT, {"error": "not_actionable", "hint": HINTS[kind]})

    def retry(self, item_id: str) -> Reply:
        """Check order: item id grammar and existence (404), then the 409 rows of contract.md. Reads no state
        first. For an F item it makes its OWN claim `self._claim(None, lead_id)` (state IN ('pending','failed')),
        and if that returns True it runs steps 1-2 and then `self._send_claimed(lead_id)`. It does NOT call
        run_followup and run_followup does not call it. If the claim returns False it re-reads the state to
        choose the 409 code. An exception in steps 1-2 after the claim records `failed` / `internal:<class>`
        (nothing was sent, so Retry stays possible)."""
        try:
            kind = self._find_item(item_id)
            if kind is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if kind != "F":
                return self._not_actionable(kind)
            lead_id = item_id[1:]
            if self._claim(None, lead_id):
                try:
                    self._prepare(lead_id)
                except Exception as e:
                    log.warning("retry steps 1-2 failed: %s", type(e).__name__)
                    self._record_send_result(lead_id, "failed", f"internal:{type(e).__name__}")
                else:
                    self._send_claimed(lead_id)
                return Reply(HTTP_OK, {"item_id": item_id, "state": self._followup_state(lead_id)})
            state = self._followup_state(lead_id)
            code = {"sending": "in_progress", "unknown": "unknown_needs_person", "sent": "not_retryable"}.get(
                str(state)
            )
            if state is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if code is None:  # pending or failed, yet the claim failed: the database stayed locked
                return Reply(HTTP_BUSY, {"error": "busy"})
            return Reply(HTTP_CONFLICT, {"error": code})
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    def resolve(self, item_id: str, decision: str) -> Reply:
        """Check order is frozen (contract.md, "Resolve check order", numbered paragraphs 2 to 5; paragraph 1 is
        the server). Here, in this order: (1) item id grammar and existence -> 404; (2) R, D or O item -> 409
        not_actionable (decision not looked at); (3) decision not in {"sent", "not_sent"} -> 400 bad_decision;
        (4) F item whose state is not `unknown` -> 409 not_unknown."""
        try:
            kind = self._find_item(item_id)
            if kind is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if kind != "F":
                return self._not_actionable(kind)
            if decision not in ("sent", "not_sent"):
                return Reply(HTTP_BAD_REQUEST, {"error": "bad_decision"})
            lead_id = item_id[1:]
            new_state, note = ("sent", "person: sent") if decision == "sent" else ("failed", "person: not sent")
            conn = self._conn()
            now = self._now()

            def attempt() -> int:
                with self._write(conn):
                    return conn.execute(
                        "UPDATE followups SET state=?, last_error=?, updated_at=?, sent_at=? WHERE lead_id=?"
                        " AND state='unknown'",
                        (new_state, note, now, now if new_state == "sent" else None, lead_id),
                    ).rowcount

            if self._locked_retry(attempt) != 1:
                return Reply(HTTP_CONFLICT, {"error": "not_unknown", "hint": HINT_NOT_UNKNOWN})
            return Reply(HTTP_OK, {"item_id": item_id, "state": new_state})
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    # -- reads
    def review(self) -> Reply:
        before = self._now() - self.config.stall_seconds
        rows = self._conn().execute(_REVIEW_SQL, {"before": before}).fetchall()
        keys = ("item_id", "item_type", "kind", "reason", "lead_id", "since", "source")
        return Reply(HTTP_OK, [dict(zip(keys, r, strict=True)) for r in rows])

    def lead(self, lead_id: str) -> Reply:
        conn = self._conn()
        row = conn.execute(
            "SELECT l.lead_id, l.receipt_id, l.source, l.name, l.email, l.phone, l.company, l.message, l.created_at,"
            " f.state, ai_label, f.attempts, f.last_error, f.sent_at"
            " FROM leads l JOIN followups f USING (lead_id) WHERE l.lead_id=?",
            (lead_id,),
        ).fetchone()
        if row is None:
            return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
        lead_keys = ("lead_id", "receipt_id", "source", "name", "email", "phone", "company", "message", "created_at")
        fu_keys = ("state", "ai_label", "attempts", "last_error", "sent_at")
        nl = len(lead_keys)
        return Reply(
            HTTP_OK,
            {
                "lead": dict(zip(lead_keys, row[:nl], strict=True)),
                "followup": dict(zip(fu_keys, row[nl:], strict=True)),
            },
        )

    def counts(self, expected: int | None) -> Reply:
        """expected=None when the query has no `expected`; server.py answers 400 bad_expected for a bad value."""
        received, new, dup, review, open_, pending = self._conn().execute(_COUNTS_SQL).fetchone()
        with self._rejected_lock:
            rejected = self._rejected
        match = None if expected is None else received == expected
        ok = None if expected is None else (open_ == 0 and rejected == 0 and match is True)
        return Reply(
            HTTP_OK,
            {
                "received": received,
                "new": new,
                "duplicate": dup,
                "review": review,
                "open": open_,
                "rejected_envelopes": rejected,
                "pending_followups": pending,
                "expected_match": match,
                "ok": ok,
            },
        )
