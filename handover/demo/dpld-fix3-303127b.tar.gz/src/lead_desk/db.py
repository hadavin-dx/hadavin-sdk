"""Database connection factory and schema loader."""

from __future__ import annotations

import importlib.resources
import sqlite3
from pathlib import Path

from lead_desk.constants import BUSY_WAIT_SECONDS, SCHEMA_VERSION, SQLITE_BUSY, SQLITE_LOCKED

LOW_BYTE = 0xFF  # sqlite_errorcode & 0xFF is the primary result code (extended codes such as 261 or 517 count)


def connect(path: Path | str) -> sqlite3.Connection:
    """One connection per request thread: isolation_level=None, timeout=BUSY_WAIT_SECONDS, foreign_keys=ON,
    recursive_triggers=ON, synchronous=FULL."""
    conn = sqlite3.connect(path, isolation_level=None, timeout=BUSY_WAIT_SECONDS)
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA recursive_triggers=ON")
    conn.execute("PRAGMA synchronous=FULL")
    return conn


def is_busy(exc: BaseException) -> bool:
    """True for 'database is locked' after the wait: OperationalError with primary code 5 or 6, or its message."""
    if not isinstance(exc, sqlite3.OperationalError):
        return False
    code = getattr(exc, "sqlite_errorcode", None)
    if isinstance(code, int) and (code & LOW_BYTE) in (SQLITE_BUSY, SQLITE_LOCKED):
        return True
    return "database is locked" in str(exc)


def init_schema(conn: sqlite3.Connection, sql: str | None = None) -> None:
    """Refuse user_version other than 0 or 1; WAL first; no-op when user_version is 1; else run schema.sql.

    executescript leaves its transaction open when the script fails after BEGIN IMMEDIATE, so the real body is:
    try: conn.executescript(BEGIN IMMEDIATE; sql; PRAGMA user_version=1; COMMIT)
    except BaseException: conn.rollback() (guarded by conn.in_transaction); raise.
    """
    version = int(conn.execute("PRAGMA user_version").fetchone()[0])
    if version not in (0, SCHEMA_VERSION):
        raise RuntimeError(f"unsupported schema version {version}")
    conn.execute("PRAGMA journal_mode=WAL")
    if version == SCHEMA_VERSION:
        return
    text = sql if sql is not None else importlib.resources.files("lead_desk").joinpath("schema.sql").read_text("utf-8")
    try:
        conn.executescript(f"BEGIN IMMEDIATE;\n{text}\nPRAGMA user_version={SCHEMA_VERSION};\nCOMMIT;")
    except BaseException:
        if conn.in_transaction:
            conn.rollback()
        raise
