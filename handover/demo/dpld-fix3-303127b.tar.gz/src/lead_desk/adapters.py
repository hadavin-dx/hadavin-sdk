"""HTTP adapters for the fakes server. Standard library only.

The opener has no proxy handler, so a laptop proxy setting cannot change local errors or successes. The base URL is
built by Config from host and port with the http scheme only, so the scheme audit (S310 / B310) is met by
construction."""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.request
from typing import Any, Literal, Mapping

from lead_desk.constants import HTTP_BAD_REQUEST, HTTP_INTERNAL_ERROR, HTTP_REQUEST_TIMEOUT
from lead_desk.contract import OutboxModeMismatch, SendAmbiguous, SendRefused, SendUnreachable

_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class FakesUnreachable(RuntimeError):
    """HttpOutbox cannot read GET /fake/info."""


class CrmError(RuntimeError):
    """The CRM call failed or answered something unexpected (the desk records it as internal:CrmError)."""


def _exchange(url: str, obj: Mapping[str, Any] | None, timeout: float) -> dict[str, Any]:
    """GET (obj None) or POST JSON; returns the parsed JSON object of a 2xx reply. Raises the urllib errors raw."""
    data = None if obj is None else json.dumps(obj).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="GET" if obj is None else "POST")  # noqa: S310  # nosec B310
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with _OPENER.open(req, timeout=timeout) as r:  # noqa: S310  # nosec B310
        reply = json.loads(r.read().decode("utf-8"))
    if not isinstance(reply, dict):
        raise ValueError("reply is not a JSON object")
    return reply


class HttpCrm:
    def __init__(self, base_url: str, timeout: float) -> None:
        self._url = base_url.rstrip("/") + "/fake/crm"
        self._timeout = timeout

    def put(self, lead_id: str, record: Mapping[str, str]) -> Literal["PUT", "ALREADY_PRESENT"]:
        try:
            reply = _exchange(self._url, {"lead_id": lead_id, "record": dict(record)}, self._timeout)
        except Exception as e:
            raise CrmError(type(e).__name__) from e
        if reply.get("status") == "put":
            return "PUT"
        if reply.get("status") == "already_present":
            return "ALREADY_PRESENT"
        raise CrmError("unexpected reply")


class HttpOutbox:
    def __init__(self, base_url: str, timeout: float) -> None:
        """Reads GET /fake/info once; raises FakesUnreachable if it cannot."""
        self._base = base_url.rstrip("/")
        try:
            info = _exchange(self._base + "/fake/info", None, timeout)
            cap, mode = info["outbox_capability"], info["mode"]
        except Exception as e:
            raise FakesUnreachable(type(e).__name__) from e
        if cap not in ("keyed", "blind") or mode not in ("keyed", "blind"):
            raise FakesUnreachable("unexpected /fake/info")
        self._capability: Literal["keyed", "blind"] = "keyed" if cap == "keyed" else "blind"
        self._mode: str = mode

    @property
    def capability(self) -> Literal["keyed", "blind"]:
        return self._capability

    def send(self, send_key: str, to: str, subject: str, body: str, timeout: float) -> Literal["SENT", "ALREADY_SENT"]:
        """Error table (contract.md). HTTPError is a URLError subclass, so it is caught first."""
        payload = {"key": send_key, "to": to, "subject": subject, "body": body}
        try:
            reply = _exchange(self._base + "/fake/outbox", payload, timeout)
        except urllib.error.HTTPError as e:
            code = e.code
            e.close()
            if code != HTTP_REQUEST_TIMEOUT and HTTP_BAD_REQUEST <= code < HTTP_INTERNAL_ERROR:
                raise SendRefused(f"http {code}") from e
            raise SendAmbiguous(f"http {code}") from e
        except urllib.error.URLError as e:
            if isinstance(e.reason, (ConnectionRefusedError, socket.gaierror)):  # nothing was sent
                raise SendUnreachable(type(e.reason).__name__) from e
            raise SendAmbiguous(type(e.reason).__name__) from e
        except Exception as e:  # timeouts, resets, unreadable reply: request bytes may have left
            raise SendAmbiguous(type(e).__name__) from e
        if reply.get("mode") != self._mode:
            raise OutboxModeMismatch(f"mode {reply.get('mode')!r}, expected {self._mode!r}")
        if reply.get("status") == "sent":
            return "SENT"
        if reply.get("status") == "already_sent":
            return "ALREADY_SENT"
        raise SendAmbiguous("unexpected reply")
