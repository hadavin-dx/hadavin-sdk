"""Email key, payload checks, difference log."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Literal, Mapping

from lead_desk.constants import COMPANY_MAX, EMAIL_MAX, MESSAGE_MAX, NAME_MAX, PHONE_MAX

_EMAIL_RE = re.compile(r"[^@\s<>\"',;]+@[^@\s<>\"',;]+\.[^@\s<>\"',;]+")
_FIELD_LIMITS: tuple[tuple[str, int | None], ...] = (  # fixed order; email has no length rule here (its rule is below)
    ("name", NAME_MAX),
    ("email", None),
    ("phone", PHONE_MAX),
    ("company", COMPANY_MAX),
    ("message", MESSAGE_MAX),
)
_DIFF_FIELDS = ("name", "phone", "company", "message")


@dataclass
class Checked:  # result of identity.check_payload
    kind: Literal["ok", "review"]
    reason: str | None  # for review
    name: str | None
    email: str | None
    email_key: str | None
    phone: str | None
    company: str | None
    message: str | None  # normalised, None when empty


def normalise_email(s: str) -> str:
    """Strip and lower case; nothing else."""
    return s.strip().lower()


def _encodable(s: str) -> bool:
    try:
        s.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return True


def _review(reason: str) -> Checked:
    return Checked("review", reason, None, None, None, None, None, None)


def _valid_email(e: str) -> bool:
    return (
        len(e) <= EMAIL_MAX
        and len(normalise_email(e)) <= EMAIL_MAX  # lower case can be longer (some letters become two characters)
        and _EMAIL_RE.fullmatch(e) is not None
        and not e.endswith(".")
        and not any(unicodedata.category(c).startswith("C") for c in e)
    )


def check_payload(obj: object) -> Checked:
    """Field types and lengths, completeness, email shape, in that order."""
    if not isinstance(obj, dict):
        return _review("bad_field:payload")
    vals: dict[str, str | None] = {}
    for field, limit in _FIELD_LIMITS:
        v = obj.get(field)
        if v is None:
            vals[field] = None
            continue
        if not isinstance(v, str):
            return _review(f"bad_field:{field}")
        if not _encodable(v):  # a lone surrogate cannot be stored: a bad field, not a server error
            return _review(f"bad_field:{field}")
        t = v.strip()
        if limit is not None and len(t) > limit:
            return _review(f"bad_field:{field}")
        vals[field] = t or None
    missing = [f for f in ("name", "email") if vals[f] is None]
    if missing:
        return _review("incomplete:" + ",".join(missing))
    email = vals["email"]
    if email is None or not _valid_email(email):
        return _review("invalid_email")
    return Checked(
        "ok", None, vals["name"], email, normalise_email(email), vals["phone"], vals["company"], vals["message"]
    )


def _collapse(s: str | None) -> str:
    return re.sub(" +", " ", (s or "").strip())


def diff_fields(stored: Mapping[str, str | None], new: Mapping[str, str | None]) -> list[str]:
    """Names of name, phone, company, message where the new value differs, in that fixed order."""
    out = []
    for f in _DIFF_FIELDS:
        b = _collapse(new.get(f))
        if b and b != _collapse(stored.get(f)):
            out.append(f)
    return out
