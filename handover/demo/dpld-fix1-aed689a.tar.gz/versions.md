# versions.md

Recorded on 2026-11-09 on the build laptop. Nothing here is a claim about other machines.

## Runtime
| Item | Value | How read |
|---|---|---|
| Python used on the build laptop | 3.13.3 (MSC v.1943, 64 bit) | `python --version` |
| Python required | 3.12 or newer (`requires-python`). 3.12 was chosen by the author as the lowest version tested. | pyproject.toml |
| SQLite library | 3.49.1 (needs 3.24 or newer for `ON CONFLICT ... DO UPDATE`) | `sqlite3.sqlite_version` |
| Runtime dependencies | none (Python standard library only) | pyproject.toml |

## n8n (demo only)
| Item | Value | How read |
|---|---|---|
| n8n | 2.46.6, regular mode (no queue), one process, SQLite inside n8n | the n8n-only runs, 2026-11-09 (measured by an AI agent) |
| Node.js | 24.22.2 | same runs |

This is the single home of the n8n version; the README and `docs/n8n-recipe.md` point here. n8n is not part of this repository and not a dependency of the desk. UNVERIFIED: that anyone else's n8n install matches these numbers (the author has not repeated the runs); the recipe is not claimed to work on other versions.

## Development tools (pinned with hashes, installed with `pip install --require-hashes`)
Direct pins live in `requirements-dev.in`. Two lock files, same versions: `requirements-dev.txt` (the authority: Linux x86_64, Python 3.12.16, made in the throwaway container `python:3.12-slim` with `pip-compile --generate-hashes --allow-unsafe --strip-extras`, pip-tools 7.6.2, a build helper that is not itself pinned) and `requirements-dev-win.txt` (Windows, Python 3.13, the author's laptop; made with uv 0.12.21: `uv pip compile requirements-dev.in --generate-hashes --python-version 3.13 --python-platform windows --no-strip-extras`). The only difference is `colorama` (a Windows-only transitive of pytest), which is in the Windows file and not in the Linux file. Neither file works on the other OS.

| Package | Version | Licence (from installed package metadata) | Used for |
|---|---|---|---|
| pytest | 9.2.0 | MIT | tests |
| ruff | 0.17.4 | MIT | lint and format; rules E, F, W, I, S, PLR2004 |
| bandit | 1.9.4 | Apache-2.0 | `bandit -ll -r src tools -c pyproject.toml` |
| mypy | 2.4.1 | MIT | `mypy` (strict, `src/` and `tools/`) |
| iniconfig 2.3.1, pluggy 1.7.0, mypy-extensions 1.2.0, librt 0.16.0, ast-serialize 0.13.1, rich 15.0.0, markdown-it-py 4.2.0, mdurl 0.1.2, pyyaml 6.0.3 | as shown | MIT (markdown-it-py and mdurl: classifier says MIT) | transitive |
| packaging 26.3 | | Apache-2.0 OR BSD-2-Clause | transitive |
| pygments 2.21.0 | | BSD-2-Clause | transitive |
| colorama 0.4.6 | | BSD (classifier) | transitive on Windows only; in `requirements-dev-win.txt`, not in the Linux lock |
| stevedore 5.9.1 | | Apache-2.0 | transitive |
| typing-extensions 4.16.0 | | PSF-2.0 | transitive |
| pathspec 1.1.1 | | **MPL-2.0** (classifier) | transitive of mypy. MPL-2.0 is file-level copyleft, not GPL, AGPL, SSPL or BUSL; used only as a development tool and not shipped. No separate licence scan has been run yet. |

Licences were read from the installed packages' metadata, not from each project's own page: treat as read-once, re-check with a `pip-licenses` scan before relying on them.

## UNVERIFIED
- Windows restart on a fixed port: `SO_EXCLUSIVEADDRUSE` plus TIME_WAIT (about 2 minutes) may make a restart bind fail, and the conflicting bind may raise `PermissionError` (WSAEACCES) instead of `EADDRINUSE`. The tests avoid it by using port 0 (the system picks a free port).
- The hashes in `requirements-dev.txt` are for all files PyPI listed on 2026-11-09; `requirements-dev.txt` verified by a successful `pip install --require-hashes` in a clean `python:3.12-slim` container (Linux x86_64, Python 3.12.16, SQLite 3.46.1) on 2026-11-09. `requirements-dev-win.txt` verified by `pip install --require-hashes` into a throwaway venv on the Windows laptop (Python 3.13.3) on 2026-11-09. Not tested: other Linux architectures, the GitHub CI runner image.
- The licences of `ast-serialize` and `librt` were read from package metadata only; a `pip-licenses` scan should confirm them.
- bandit B101 on tests: tests are excluded from bandit, so not relevant.
- gitleaks is a separate program (version and checksum pinned in `.github/workflows/lint.yml`), not part of the lock files. pre-commit and exiftool are not used.
