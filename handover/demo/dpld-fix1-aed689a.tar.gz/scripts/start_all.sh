#!/usr/bin/env bash
# Start the fake mail/CRM server and the desk in the background (Linux/macOS).
# Usage: scripts/start_all.sh [keyed|blind]     (default keyed). Run from the repository root.
# Ports and paths come from the desk configuration (DESK_* environment variables), not from this file.
# Logs and process ids go under the folder that holds the database file (git-ignored).
set -eu
mode="${1:-keyed}"
case "$mode" in keyed|blind) ;; *) echo "mode must be keyed or blind" >&2; exit 1 ;; esac
export PYTHONPATH="src:."
data_dir="$(python -c 'from lead_desk.config import Config; print(Config.from_env().db_path.parent)')"
fakes_port="$(python -c 'from lead_desk.config import Config; print(Config.from_env().fakes_port)')"
mkdir -p "$data_dir"
if [ -e "$data_dir/fakes.pid" ] || [ -e "$data_dir/desk.pid" ]; then
  echo "pid files exist: run scripts/reset.sh first" >&2
  exit 1
fi
python -m demo_only.fakes_server --outbox "$mode" --port "$fakes_port" >"$data_dir/fakes.log" 2>&1 &
echo $! >"$data_dir/fakes.pid"
python -m lead_desk.server >"$data_dir/desk.log" 2>&1 &
echo $! >"$data_dir/desk.pid"
echo "started: fakes ($mode outbox) pid $(cat "$data_dir/fakes.pid"), desk pid $(cat "$data_dir/desk.pid")"
echo "logs: $data_dir/fakes.log and $data_dir/desk.log"
