# Stop what start_all.ps1 started (only those process ids) and delete the lead book, so the next run starts empty.
# Run from the repository root. It deletes the database file, its -wal/-shm/.lock files, the logs and the pid files.
$ErrorActionPreference = 'Stop'
$env:PYTHONPATH = 'src;.'
$db = (python -c "from lead_desk.config import Config; print(Config.from_env().db_path)").Trim()
$dataDir = Split-Path -Parent $db
foreach ($name in 'desk', 'fakes') {
    $pidFile = "$dataDir\$name.pid"
    if (Test-Path $pidFile) {
        $procId = [int](Get-Content $pidFile)
        Stop-Process -Id $procId -ErrorAction SilentlyContinue
        Remove-Item $pidFile
    }
}
Start-Sleep -Seconds 1
foreach ($f in $db, "$db-wal", "$db-shm", "$db.lock", "$dataDir\desk.log", "$dataDir\desk.err.log",
    "$dataDir\fakes.log", "$dataDir\fakes.err.log", "$dataDir\crash.flag") {
    Remove-Item -Force -ErrorAction SilentlyContinue $f
}
Write-Host 'reset done'
