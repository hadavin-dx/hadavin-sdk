# Security

This is a demo. It uses made-up data and fake systems only, binds to this computer's own address, has no login, and is
not meant to run anywhere reachable by other people. Do not put real customer data into it.

## Reporting a problem

Use the "Report a vulnerability" button on this repository's Security tab (GitHub's private vulnerability reporting).
If that button is not shown, open the repository's Security tab and read what it says; this file lists no e-mail
address on purpose.

## What is and is not covered

* There are no secrets in this repository and none are needed: the demo makes no live model calls and talks only to
  fake servers on the same computer. If you find something that looks like a secret, report it as above.
* Pull requests are limited to the author. This repository does not accept outside contributions.
* The code is published for viewing only (see `LICENSE`).
* Automatic checks (`.github/workflows/`) look for known bug patterns and secret formats. They do not prove the code
  is free of problems, and they do not keep anything private once it has been published.
