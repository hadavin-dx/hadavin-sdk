# contract.md

This file is the single reference for the replies the desk and the fake servers give and the rules the tests check. Where code and this file disagree, this file is right and the code is fixed. Tests: 32 test functions, 42 test cases when the parametrised ones are expanded (desk tests, hygiene tests and two mutation guards). CI runs every test except `test_hygiene_wordlist` (it needs a private word list that is never committed).

## Reply rows that are easy to miss (all already in the table below; repeated here as a checklist)

| Situation | Status | Body | `receipt_id` |
|---|---|---|---|
| Unknown route | 404 | `{"error":"not_found"}` | not present |
| Known route, wrong method | 405 | `{"error":"method_not_allowed"}` | not present |
| `GET /counts?expected=x` with x not an integer, or negative | 400 | `{"error":"bad_expected"}` | not present |
| Envelope broken (400) or body over the cap (413) | 400 / 413 | `{"error":"bad_envelope"}` / `{"error":"too_large"}` | `null` (no receipt exists) |
| Request the standard library cannot read (malformed request line, unknown method such as `TRACE`) | 400 / 501 | `{"error":"bad_request"}` / `{"error":"not_implemented"}` | not present |
| `HEAD` or `OPTIONS` | 404 or 405 | the same JSON as for any other unknown route or wrong method (a `HEAD` reply has the headers and no body) | not present |
| Lock wait over | 503 | `{"error":"busy"}` | the receipt id, or `null` if the receipt was not yet written |
| Any other internal error | 500 | `{"error":"internal"}` | the receipt id, or `null` |
| Any 409 or `bad_decision` row (retry/resolve) | 409 / 400 | `{"error":"...","hint":"..."}` / `{"error":"bad_decision"}` | not present (these rows never carry `receipt_id`) |

State once: only the POST /leads rows carry `receipt_id`. The 409 and `bad_decision` rows never carry it. 503 and 500 carry the receipt number, or `null` if the receipt was not yet written. 400 `bad_envelope` and 413 `too_large` carry `null`.

Input rules that were tightened after review (each has a test in `tests/test_hardening.py`): (1) JSON nested so deeply that the parser gives up is a 400 `bad_envelope` (counted in `rejected_envelopes`), not a 500; for `/resolve` it is a 400 `bad_decision`. (2) The stored copy of the payload escapes every non-ASCII character (`ensure_ascii`), so a JSON escape for half a character (a lone surrogate) is stored as text; a name, email, phone, company or message that contains one cannot be stored and gives verdict `review` with reason `bad_field:<field>`. (3) An email whose lower-case form is longer than 254 characters (some letters become two when lower-cased) gives verdict `review`, reason `invalid_email`, not a 500. (4) The AI step can run twice when two requests drive the same new lead at the same moment (a cost, never a second email or CRM row; the label stored is the first one written). (5) A follow-up stuck in `sending` because the database stayed locked through all retries is repaired only by restarting the desk (the start-up sweep moves it to `pending` or `unknown`).

## Resolve check order (`POST /review/{item_id}/resolve`)
1. Body parse layer: `server.py` parses the JSON; `Desk.resolve(item_id, decision)` receives an already parsed `decision`. A body that is not JSON, or has no `decision`, or a `decision` that is not a string: 400 `{"error":"bad_decision"}` with NO item lookup (so even an unknown item id gives 400 here).
2. Item id grammar and existence: 404 `{"error":"not_found"}`. A malformed id such as `X1` is 404.
3. Item is an `R`, `D` or `O` item: 409 `{"error":"not_actionable","hint":"..."}` (the decision value is not looked at).
4. `decision` not one of `sent`, `not_sent`: 400 `{"error":"bad_decision"}`. (The server-side check of step 1 is a 400 before any lookup; this is step 4 inside Desk.)
5. Item is an `F` item whose state is not `unknown`: 409 `{"error":"not_unknown","hint":"..."}`.

Retry (`POST /review/{item_id}/retry`) uses steps 2 and 3 in the same order (malformed id 404; `R`/`D`/`O` 409 `not_actionable`), then the retry-specific 409 codes.
Exact `hint` text for 409 `not_actionable` (same text for retry and resolve), by item type: `R` item: `Send a corrected submission with a NEW request id.`; `D` item: `Informational only, no action needed.`; `O` item: `Send the same request id again, or restart the desk.`. 409 `not_unknown` (resolve) carries the hint `Only a follow-up in state unknown can be resolved.`. The retry codes `in_progress`, `unknown_needs_person` and `not_retryable` carry no `hint` (the table: `hint` only for `not_actionable` on retry).
`GET /counts?expected=` with an empty value (`expected=`), a non-integer or a negative number: 400 `{"error":"bad_expected"}`. No `expected` parameter at all: 200 with `expected_match` and `ok` as `null` where the table says so.

## Run commands
There is no build-system. Scripts set `PYTHONPATH=src` (and run from the repo root): `PYTHONPATH=src python -m lead_desk.server`, `PYTHONPATH=src:. python -m demo_only.fakes_server --outbox keyed --port 8766`, `PYTHONPATH=src:. python -m demo_only.burst ...`. (On Windows `;` separates the paths; the run scripts set it.) pytest sets the same paths itself (`pythonpath = ["src", "."]`) for its own process, but NOT for child processes: any test that starts a subprocess (`tests/crash_launcher.py`, the fakes server, `lead_desk.server`) passes `env["PYTHONPATH"]` (src and repo root joined with `os.pathsep`) to it. `schema.sql` is read with `importlib.resources` from the `lead_desk` package, so it is found relative to the package wherever `src` is on the path.

### Dev tools: which lock file for which OS
`requirements-dev.txt` is the authority: Linux x86_64, Python 3.12 (CI and containers). `requirements-dev-win.txt` is the Windows lock for the author's laptop (Python 3.13, made with `uv pip compile requirements-dev.in --generate-hashes --python-version 3.13 --python-platform windows --no-strip-extras`); it has the same pins plus `colorama`. Install with `pip install --require-hashes -r <that file>`. Both files are regenerated together when `requirements-dev.in` changes. Quality commands (all must pass): `ruff check .`, `ruff format --check .`, `mypy --platform linux`, `mypy --platform win32`, `bandit -ll -r src tools -c pyproject.toml`, `python scripts/check_schema.py`.

## Config environment names
`Config.fakes_url` is a read-only property built from `fakes_host` and `fakes_port`. Env names: `DESK_DB_PATH, DESK_BIND, DESK_PORT, DESK_ADAPTERS, DESK_FAKES_URL, DESK_FAKES_HOST, DESK_FAKES_PORT, DESK_REPLIES_PATH, DESK_SEND_TIMEOUT_SECONDS, DESK_SIZE_CAP_BYTES, DESK_STALL_SECONDS`. `DESK_FAKES_URL` wins over `DESK_FAKES_HOST` / `DESK_FAKES_PORT`; its scheme must be `http` (anything else raises `ValueError`), a path other than empty or `/` raises `ValueError`, a query, fragment and userinfo are ignored (only host and port are taken); an IPv6 host keeps its brackets.

## Demo files
`demo_only/replies.json`: one JSON object, key = the normalised email key of a canned lead, value = `"hot"`, `"warm"` or `"cold"`. The canned leads file is `demo_only/canned_leads.json`: a JSON array of lead payloads (the payload shape of the HTTP table, made-up data), one per canned person. `test_demo_adapters` checks every canned lead email has a `replies.json` entry. `canned_leads.json` entries are payloads only: they carry NO `source` / `source_ref`; the scripts and tests that post them build the envelope with `source` = `form` or `webhook` (the envelope values of the HTTP table) and `source_ref` = `canned-<i>` where `<i>` is the position in the array (starting at 1). `RecordedQualifier` loading rules (fail loud): a missing `replies.json` or malformed JSON makes the constructor raise (never a silent empty mapping); a key with no entry answers `warm`; an entry whose value is not `hot`, `warm` or `cold` raises a `KeyError`-class error that names the bad label. `demo_only/fakes.py`, `fakes_server.py` and `burst.py` hold the fake CRM, the fake outbox, the recorded AI step, the fake servers and the burst script.

## Server and reply flush
The server writes the reply, calls `wfile.flush()` and `connection.shutdown(SHUT_WR)`, and only then runs `desk.run_followup`, so a client that reads until close is not kept waiting for the follow-up. `allow_reuse_address = (os.name != "nt")`; on Windows `SO_EXCLUSIVEADDRUSE` is set in `server_bind` under `if sys.platform == "win32":`. Windows limit (a restart on the same port is not tested by an automated test; tests use port 0): a restart on the same fixed port can fail for about 2 minutes (TIME_WAIT) and the conflicting bind can raise `PermissionError` instead of `EADDRINUSE`; the code catches `OSError` broadly, tests use port 0, and the launcher's 5 second bind retry may not outlast TIME_WAIT on Windows.

## Follow-up drive: who makes which claim
One private method `Desk._send_claimed(lead_id)` does the send and the recording of its result (send with `send_key=lead_id`, record the result) AFTER a won claim. The crash points `D1` and `D2` are inside it. Exactly two paths claim, and neither calls the other:
* `run_followup(lead_id)` (also the start-up sweep for every `pending` follow-up, and `handle`): steps 1-2, then `self._claim(None, lead_id)`; if True, `self._send_claimed(lead_id)`.
* `retry(lead_id)` (HTTP Retry): its own `self._claim(None, lead_id)` whose UPDATE carries the state precondition `state IN ('pending','failed')`; if True, steps 1-2 then `self._send_claimed(lead_id)`; if False, it re-reads the state for the 409 code.
`_claim` always takes `None` today and opens its own transaction; a connection argument exists only for a caller that holds an open transaction-1 connection (`process` makes no claim). So `D1`/`D2` fire on first sends, Retry and the sweep, because all three reach `_send_claimed`. Writers of follow-up results: `_record_send_result(lead_id, state, last_error=None)` handles `sent`, `failed` and `unknown` for rows in `sending` only (`WHERE state='sending'`); `_fail_pending(lead_id, "internal:<exception class>")` handles `pending` -> `failed` (`WHERE state='pending'`). A row count of 0 is logged and ignored in both.

## Crash hook ownership
`lead_desk.hooks.FlagFileHooks(flag_path)` is the single shared hook for every subprocess crash. It reads a one-shot flag file (the path comes from config or the launcher, content = a point name), deletes it, prints "simulate crash" and calls `os._exit(137)`. `tests/crash_launcher.py` and `scripts/video_crash.py` contain no hook code: each only calls `lead_desk.server.main(hooks=FlagFileHooks(path))`. In-process tests use their own `Hooks` subclass that raises `SimulatedCrash`. Hook A fires only when this call created the receipt row; hook B fires only when this call committed transaction 2 (a replay never fires either).

## Further rules (2026-11-09)
* `Config.replies_path` defaults to `None` ("the loader supplies its own default"): `load_demo_adapters` then uses the `replies.json` that sits next to the demo folder's package, found from the package file, not from the working directory. `DESK_REPLIES_PATH` still sets it. `loader.py` is the only product module that names the demo folder (a test enforces it).
* A submission with no email (a phone-only lead) has no lead key: verdict `review`, reason `incomplete:email` (or `incomplete:name,email` when the name is also missing); it is never merged and never dropped.
* A held lead-book lock raises `OSError` from `lockfile.acquire`. A `RecordedQualifier` label that is not `hot`, `warm` or `cold` raises a `KeyError` that names the label, from `qualify` (a follow-up then ends `failed` with `internal:KeyError`).
* Fakes server flag `--crm keyed|blind` (default `keyed`) selects the CRM's mode; `--outbox` is unchanged.
* `python -m lead_desk.server` prints one line `desk listening on http://<host>:<port>` when it accepts requests. The port in it is the real one, so `DESK_PORT=0` (ephemeral) works; the subprocess tests still pick a free port themselves. Start-up order: lock file (exit 2, "another desk is using this database"), adapters (exit 1 if `/fake/info` cannot be read), bind (exit 2 on any `OSError`), `Desk.startup()` (schema and sweep), serve.
* `Desk.run_followup` leaves a follow-up that is not `pending` alone (a second drive of a `sent` follow-up changes nothing). An exception in steps 1-2 after Retry's own claim is written as `failed` / `internal:<class>` by `_record_send_result` (the row is `sending` then, not `pending`).
* Item existence for 404: `F<lead_id>` needs a follow-up row; `R<n>` a receipt with verdict `review`; `D<n>` a receipt with verdict `duplicate` and a non-empty `differing_fields`; `O<n>` an open receipt (any age). Anything else is 404.
* On `GET /review` the `reason` of a `duplicate_with_new_info` item is the JSON text of `differing_fields` (a string such as `["phone"]`), exactly what the view returns. The list is ordered by `since`, then `item_id`.
* Retry when the claim fails and the row is still `pending` or `failed` (the database stayed locked through the claim retries): 503 `{"error":"busy"}`.
* Lock-wait errors in the read and retry/resolve routes follow the same rule as `POST /leads`: busy gives 503 `{"error":"busy"}`, any other error 500 `{"error":"internal"}` (without `receipt_id` outside `POST /leads`).
* The server reads at most `size_cap_bytes + 1` bytes of a body; after an early reply (413) it drops up to `DRAIN_MAX_BYTES` unread request bytes so the reply is not lost to a connection reset. Each handler thread has a socket timeout of `REQUEST_TIMEOUT_SECONDS`.
* Adapter timeouts: on Windows a refused connect to a closed local port reports only after about 2 seconds (measured 2.03 s, 2026-11-09). A shorter send timeout turns "refused" into a connect timeout, which the table classes as ambiguous. The default `send_timeout_seconds` is 5.0, so the default is unaffected.

---

## HTTP table
All desk replies are JSON with `Content-Length` and `Connection: close`. `receipt_id` is a number, or `null` when no receipt exists. A replay returns the stored verdict's original status and body plus `"replayed": true` and `"payload_matches": true|false`. Unknown route: 404 `{"error":"not_found"}`; known route, wrong method: 405 `{"error":"method_not_allowed"}`.

| Request | Status | Body |
|---|---|---|
| `POST /leads` `{"source":"form\|webhook","source_ref":"<1-128 chars>","payload":{B.1}}` | 201 | `{"receipt_id":n,"verdict":"new","lead_id":"L...","replayed":false}` |
| | 200 | `{"receipt_id":n,"verdict":"duplicate","lead_id":"L...","differing_fields":["phone"],"replayed":false}` |
| | 202 | `{"receipt_id":n,"verdict":"review","reason":"incomplete:email","replayed":false}` |
| | 400 | `{"error":"bad_envelope","receipt_id":null}` (not JSON, missing or wrong `source`/`source_ref`/`payload`, no Content-Length) |
| | 413 | `{"error":"too_large","receipt_id":null}` (checked before storing) |
| | 503 | `{"error":"busy","receipt_id":n or null}` (lock wait over; the receipt, if it exists, stays open) |
| | 500 | `{"error":"internal","receipt_id":n or null}` (receipt stays open) |
| `GET /leads/{lead_id}` | 200 | `{"lead":{lead_id,receipt_id,source,name,email,phone,company,message,created_at},"followup":{"state","ai_label","attempts","last_error","sent_at"}}` |
| | 404 | `{"error":"not_found"}` |
| `GET /review` | 200 | `[{"item_id":"F<lead_id>\|R<receipt_id>\|D<receipt_id>\|O<receipt_id>","item_type":"followup\|receipt","kind":"failed\|unknown\|review\|duplicate_with_new_info\|stalled","reason":"...","lead_id":"L...\|null","since":epoch,"source":"form\|webhook"}]` |
| `POST /review/{item_id}/retry` | 200 | `{"item_id":"F...","state":"sent\|failed\|unknown"}` (the attempt has run) |
| | 404 | `{"error":"not_found"}` |
| | 409 | `{"error":"in_progress\|unknown_needs_person\|not_retryable\|not_actionable","hint":"..."}` (`hint` only for `not_actionable`) |
| `POST /review/{item_id}/resolve` `{"decision":"sent\|not_sent"}` | 200 | `{"item_id":"F...","state":"sent\|failed"}` |
| | 400 | `{"error":"bad_decision"}` |
| | 404 | `{"error":"not_found"}` |
| | 409 | `{"error":"not_unknown\|not_actionable","hint":"..."}` |
| `GET /counts?expected=N` | 200 | `{"received","new","duplicate","review","open","rejected_envelopes","pending_followups","expected_match":true\|false\|null,"ok":true\|false\|null}` |
| | 400 | `{"error":"bad_expected"}` (not an integer, or negative) |

Fakes server (separate process; default `127.0.0.1:8766`; started with `--outbox keyed|blind --port 8766`). Every reply includes `"mode":"keyed|blind"`.
* `POST /fake/outbox` `{"key","to","subject","body"}` -> keyed mode: 200 `{"status":"sent","mode":"keyed"}` the first time for a key and 200 `{"status":"already_sent","mode":"keyed"}` after; blind mode: always 200 `{"status":"sent","mode":"blind"}` and every post is stored. Bad body: 400 `{"error":"bad_body"}`.
* `GET /fake/outbox` -> `{"mode":"keyed|blind","count":n,"messages":[{"key","to","subject"}]}`.
* `POST /fake/crm` `{"lead_id","record":{...}}` -> 200 `{"status":"put"|"already_present","mode":"..."}` (keyed by `lead_id`; for the n8n-only runs the CRM runs in blind counting mode, `--crm blind`: every post is stored). `GET /fake/crm` -> `{"count":n,"rows":[{"lead_id","record"}]}`.
* `GET /fake/info` -> `{"outbox_capability":"keyed|blind","mode":"keyed|blind"}`.
* `POST /fake/control` `{"fail_next":"none|refuse|drop|record_then_drop|store_then_delay","delay_ms":int,"target":"outbox|crm"}` (`target` optional, default `outbox`; so that a slow CRM step and a slow mail step can both be reproduced; a `target` that is neither gives `bad_control`) -> 200 `{"status":"ok"}`; bad body 400 `{"error":"bad_control"}`. Applies to the next post to the TARGET only (outbox post or CRM post; the other target's control is untouched); the behaviours below are described for the outbox and apply the same to a CRM post (`refuse` 422 nothing stored, `drop` never arrived, `record_then_drop` stored and no reply, `store_then_delay`, `none` + `delay_ms` waits before storing): `refuse` answers 422 (nothing stored), `drop` closes the connection without recording ("never arrived"), `record_then_drop` stores the email and closes without replying ("sent, reply lost"), `store_then_delay` stores the email, waits `delay_ms`, then answers normally (the n8n test point called K2 in the README). With `fail_next:"none"`, `delay_ms` waits BEFORE storing and then answers normally (the n8n test point called K1 in the README, the timeout row of the error table, and `test_reply_does_not_wait_for_send`).
* `POST /fake/reset` -> 200 `{"status":"reset"}`.
Email the desk sends: subject `Thanks for getting in touch, {name}`; body `Hi {name}, we received your message. (FAKE EMAIL)`; recipient = the lead's email as typed. CRM record: `lead_id, name, email, company, source, ai_label`.
**Burst script:** `python -m demo_only.burst --url http://127.0.0.1:8765/leads --n 10 --email ada@example.test --ref-prefix run1 --source form [--expect N] [--wrap-n8n]`. Request ids are `<ref-prefix>-<i>` for i in 1..n; the same email in every hit; `--wrap-n8n` posts the n8n form-call shape instead of the desk envelope. Output lines: `SENT n=10`, `STATUS 201=1 200=9`, `RETRIES busy503=0 refused=0`, then `RESULT sent=10 expected=10` (or `MISMATCH sent=... expected=...`).
