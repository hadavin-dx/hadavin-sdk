"""Hygiene tests. Four tests live here; the mutation guards are in test_mutants.py.
CI runs all of them except test_hygiene_wordlist (the private word list is never committed or in CI)."""

from __future__ import annotations

import copy
import json
import os
import re
import shutil
import subprocess
import tomllib
from pathlib import Path

from support import REPO

from tools import hygiene

SRC = REPO / "src"
MIN_TERMS = 5  # a word list shorter than this is treated as missing
WORDLIST_ENV = "HYGIENE_WORDLIST"
GITLEAKS_ENV = "GITLEAKS_BIN"


def _git(cwd: Path, *args: str) -> str:
    p = subprocess.run(  # noqa: S603
        ["git", *args],  # noqa: S607
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    return p.stdout


def test_no_demo_only_outside_loader() -> None:
    """src/ may name demo_only only in loader.py; tests/, scripts/, conftest.py, README and docs may."""
    offenders = [
        str(p.relative_to(REPO))
        for p in sorted(SRC.rglob("*"))
        if p.is_file()
        and p.suffix in (".py", ".sql", ".md", ".txt", ".toml")
        and p.name != "loader.py"
        and "demo_only" in p.read_text(encoding="utf-8", errors="replace")
    ]
    assert not offenders, f"src/ files that name demo_only (only loader.py may): {offenders}"
    assert "demo_only" in (SRC / "lead_desk" / "loader.py").read_text(encoding="utf-8")  # the rule is not vacuous


def test_hygiene_scan_public(tmp_path: Path) -> None:
    """Patterns + exceptions pipeline with one canary per rule, on the tree; gitleaks on tree and history (--redact)."""
    patterns, exceptions, toml = REPO / "patterns.txt", REPO / "exceptions.txt", REPO / ".gitleaks.toml"
    for f in (patterns, exceptions, toml):
        assert f.is_file(), f"missing {f.name} (this test needs it)"
    # 1. canaries: a temp repo with one planted value per kind, plus values that must be allowed
    canary = tmp_path / "canary"
    canary.mkdir()
    _git(canary, "init", "-q")
    planted = "\n".join(f"{k}: {v}" for k, v in hygiene.CANARIES.items()) + "\n"
    (canary / "planted.txt").write_text(planted, encoding="utf-8")
    (canary / "allowed.txt").write_text("\n".join(f"x {v} y" for v in hygiene.ALLOWED) + "\n", encoding="utf-8")
    _git(canary, "add", ".")
    reported = hygiene.pipeline(canary, patterns, exceptions)
    matches = [ln.split(":", 2)[2].strip() for ln in reported if ln.startswith("planted.txt:")]
    for kind, value in hygiene.CANARIES.items():
        assert any(m and m in value for m in matches), f"canary not found, rule silently stopped matching: {kind}"
    assert not [ln for ln in reported if ln.startswith("allowed.txt:")], "an allowed value was reported"
    for pat in hygiene.read_lines(patterns):  # every rule in the file must have a canary that it matches
        assert any(re.search(pat, v) for v in hygiene.CANARIES.values()), f"rule without a canary: {pat}"
    # 2. the real tree
    left = hygiene.pipeline(REPO, patterns, exceptions)
    assert not left, "hardcoded literals found (file:line:match):\n" + "\n".join(left[:50])
    # 3. gitleaks (release binary; CI installs it with a checked SHA-256)
    exe = os.environ.get(GITLEAKS_ENV) or shutil.which("gitleaks")
    assert exe, f"gitleaks binary not found: put it on PATH or set {GITLEAKS_ENV}"
    ids = [r["id"] for r in tomllib.loads(toml.read_text(encoding="utf-8")).get("rules", [])]
    report = tmp_path / "canary-report.json"  # reports go outside the repo
    common = ["--no-banner", "--redact", "--ignore-gitleaks-allow", "--config", str(toml)]
    fmt = ["--report-format", "json", "--report-path", str(report)]
    subprocess.run([exe, "dir", *common, *fmt, str(canary)], check=False)  # noqa: S603
    found = {x["RuleID"] for x in json.loads(report.read_text(encoding="utf-8") or "[]")}
    assert set(ids) <= found, f"gitleaks custom rules that did not fire on their canary: {sorted(set(ids) - found)}"
    tree = tmp_path / "tree"  # the tracked files only: `dir` mode would also scan caches and virtual environments
    for rel in _git(REPO, "ls-files").splitlines():
        if (REPO / rel).is_file():
            (tree / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(REPO / rel, tree / rel)
    for sub, target in (("dir", tree), ("git", REPO)):
        p = subprocess.run([exe, sub, *common, "--exit-code", "1", str(target)], capture_output=True, check=False)  # noqa: S603
        assert p.returncode == 0, f"gitleaks {sub} reported findings (values are redacted)"


def _find_terms(terms: list[str], texts: dict[str, str]) -> list[tuple[int, str]]:
    """(term number, where) for every term variant found; the term itself is never returned (the list is private)."""
    hits = []
    for i, term in enumerate(terms):
        vs = hygiene.variants(term)
        for where, text in texts.items():
            low = text.lower()
            if any(v in low for v in vs):
                hits.append((i, where))
    return hits


def test_hygiene_wordlist() -> None:
    """Local only. FAILS (never skips) when the list is missing, too short or the planted canary is not found."""
    path = os.environ.get(WORDLIST_ENV)
    assert path, f"set {WORDLIST_ENV} to the private word list; this test fails instead of skipping"
    terms = [
        t.strip() for t in Path(path).read_text(encoding="utf-8").splitlines() if t.strip() and not t.startswith("#")
    ]
    assert len(terms) >= MIN_TERMS, f"word list has {len(terms)} terms, minimum is {MIN_TERMS}"
    canary_term = "zz-canary-" + "term-7q"  # planted: the scanner must find it (a scanner that finds nothing fails)
    planted = _find_terms([*terms, canary_term], {"planted": "x " + canary_term.upper() + " y"})
    assert (len(terms), "planted") in planted, "the canary term was not found: the scanner is broken"
    files = [f for f in _git(REPO, "ls-files").splitlines() if (REPO / f).is_file()]
    texts = {f: (REPO / f).read_text(encoding="utf-8", errors="replace") for f in files}
    texts["<git history>"] = _git(REPO, "log", "--all", "--format=fuller", "-p")
    hits = _find_terms(terms, texts)
    assert not hits, "word-list terms found (term number, where): " + ", ".join(f"#{i} in {w}" for i, w in hits[:30])


def test_scrub_canary() -> None:
    """tools/scrub_n8n_export.py keeps an allow-list of known-safe keys; canaries in unknown keys must go too."""
    from tools.scrub_n8n_export import scrub

    wf = {
        "id": "CANARY-wf-id",
        "name": "Lead desk",
        "active": False,
        "createdAt": "CANARY-created",
        "updatedAt": "CANARY-updated",
        "versionId": "CANARY-version",
        "zzUnknownTop": "CANARY-unknown-top",
        "meta": {"instanceId": "CANARY-instance", "zzUnknownMeta": "CANARY-meta"},
        "homeProject": {"id": "CANARY-proj", "name": "CANARY-account-name", "email": "canary@example.test"},
        "pinData": {"Webhook": [{"json": {"email": "CANARY-pin"}}]},
        "tags": [{"name": "CANARY-tag"}],
        "nodes": [
            {
                "id": "CANARY-node-id",
                "webhookId": "CANARY-webhook",
                "zzUnknownNodeKey": "CANARY-unknown-node",
                "name": "Webhook",
                "type": "n8n-nodes-base.webhook",
                "typeVersion": 2,
                "position": [0, 0],
                "parameters": {"path": "lead"},
            }
        ],
        "connections": {"Webhook": {"main": [[{"node": "Next", "type": "main", "index": 0}]]}},
    }
    before = copy.deepcopy(wf)
    out = scrub(wf)
    assert wf == before, "scrub must not change its input"
    assert "CANARY" not in json.dumps(out), "a planted value survived the scrub"
    assert [n["name"] for n in out["nodes"]] == ["Webhook"]
    assert out["nodes"][0]["type"] == "n8n-nodes-base.webhook"
    assert out["nodes"][0]["parameters"] == {"path": "lead"}
    assert out["connections"] == wf["connections"]
