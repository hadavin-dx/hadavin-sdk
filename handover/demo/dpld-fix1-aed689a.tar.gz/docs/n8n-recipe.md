# n8n recipe: the n8n side of the demo, node by node

Who this is for: someone who has used n8n a little and wants to rebuild the workflows the demo uses. Nothing here has been
imported into a real n8n by the author of this file unless a line says "checked". **Every step marked UNVERIFIED has not
been tried; treat it as a plan, not a fact.** Menu and field names in n8n change between versions; where a name below is from
memory it is marked.

Made-up data and fake servers only. Use no real credentials. Do not paste a password, an n8n licence key or a real e-mail
address into any workflow you export. Anything you export for sharing must first go through `tools/scrub_n8n_export.py`
(a small script that keeps only known-safe keys and removes ids, credentials, pinned data and personal fields):
`python -m tools.scrub_n8n_export workflow.json workflow.scrubbed.json`. After importing a scrubbed file, set the webhook path and
attach your own credentials; whether n8n accepts the placeholder node ids on import is UNVERIFIED: nobody has imported one yet.

## 0. Before you start

* n8n version the numbers in the README were measured with: see `versions.md`; regular mode (no queue), one process,
  SQLite inside n8n. The exact versions are recorded once, in `versions.md` (section "n8n (demo only)"). Use the same version, or
  say plainly in your own write-up that you used another one. UNVERIFIED that the recipe works on any other version.
* n8n asks you to create the first user account on first start. Use your own business e-mail in YOUR n8n only. A free registered licence key is
  optional and not needed for anything here (UNVERIFIED whether Data Tables and the Remove Duplicates node need no key).
  Never commit the e-mail, the password or the key anywhere.
* Start the fake servers and the desk first (README, "Run it"). From the same computer, n8n reaches them at the host and
  ports from the settings table in the README. **If n8n runs in Docker, `localhost` inside the container is the container, not
  your computer.** The desk listens on this computer only (`DESK_BIND`). Either run n8n directly with Node, or change the bind
  address on purpose and test it. UNVERIFIED which works on your set-up.
* Executions: leave n8n's concurrency at its default (unlimited) except for variant (d) below.

## 1. The desk workflow (n8n in front of the desk)

Goal: a web form submission and an email-style message, both arriving at n8n, both end up as one request to the desk.
n8n adds nothing clever. The desk decides what is new.

**Request id (do this first and write the answer down): UNVERIFIED which stable id n8n gives you.** The desk needs one id per
submission that stays the same when n8n re-sends it. Candidates: the form's own submission id, the email's message id, or n8n's
execution id (the execution id changes on a re-run, so it is the wrong choice for a retry). The example inputs below carry the id inside the
request body (`submission_id`, `message_id`), which is the stable choice.

Example inputs (made-up):

    form:    {"submission_id":"sub-0001","name":"Ada Example","email":"Ada@Example.test","phone":"555 0100","company":"Example Ltd","message":"Please call me."}
    webhook: {"message_id":"msg-0001","from_name":"Ada Example","from_email":"ada@example.test","subject":"Quote","body":"Please call me."}

Nodes for the **form door** (workflow "desk-form"):
1. **Webhook** node. HTTP method POST. Path: any word, for example `desk-form`. Respond: "When last node finishes" (name from memory;
   UNVERIFIED). Response data: "First entry JSON" (UNVERIFIED). Authentication: none (local demo only).
2. **Edit Fields (Set)** node. Mode: manual mapping. Create these fields (expressions use n8n's `$json.body` for the webhook body; UNVERIFIED):
   `source` = the text `form`; `source_ref` = `{{ $json.body.submission_id }}`; `payload` = an object with `name`, `email`, `phone`, `company`,
   `message` taken from the same names in `$json.body`.
3. **HTTP Request** node. Method POST. URL: the desk's `/leads` address (host and port from the README settings table). Send body: JSON,
   using the three fields `source`, `source_ref` and `payload`. Options: timeout a little above the desk's send timeout; Never Error: OFF, so a 400 or a 413 shows red in n8n (the demo wants that).
4. The Webhook node's "Respond: when last node finishes" now returns the desk's reply (verdict `new`, `duplicate` or `review`). UNVERIFIED that the reply passes through unchanged.

Nodes for the **email door** (workflow "desk-webhook"): the same three nodes with a different Webhook path (`desk-webhook`) and this mapping:
`source` = the text `webhook`; `source_ref` = `{{ $json.body.message_id }}`; `payload.name` = `from_name`; `payload.email` = `from_email`; `payload.message` = `body`.
(`subject` is ignored by the desk.)

Checks to run by hand, in this order, and write down pass or "not verified" for each:
1. Import or build works. 2. The form call reaches the desk (desk answers 201, verdict `new`). 3. The email call reaches the desk
(same lead: 200, verdict `duplicate`). 4. The id n8n gives is stable (send the same submission twice: second reply carries `"replayed": true`).
5. A request with no email shows 202 `review` and gets no follow-up. 6. A body that is not valid JSON, or one over the size cap, shows red (400, 413).
7. n8n's automatic re-send against a desk stopped halfway (retry on the workflow's HTTP node): UNVERIFIED how to set it; use "Retry On Fail" in the node settings (name from memory).

## 2. The n8n-only variants (scene 1: n8n without the desk)

Each variant is a copy of the desk workflow where the desk call is replaced by: **dedupe step, then POST to the fake CRM, then POST to the fake outbox.**
Request body for the fake servers is in `contract.md` (fakes server section). Both fake servers run in blind counting mode for these runs: start the fakes server with `--crm blind --outbox blind` (the CRM default is `keyed`, which would hide a second row; `--outbox keyed` is only for the keyed-mail case, which has not been run with n8n). Build ONE variant;
the README table shows all four.

* **(b) A database refuses a second row with the same email.** Needs a small Postgres (a throwaway container). Webhook -> **Postgres** node, operation
  "Execute Query": `INSERT INTO leads(email) VALUES ($1) ON CONFLICT (email) DO NOTHING RETURNING email;` with the query parameter set to the email from the
  body (a bound parameter, not text pasted into the query) -> **IF** node: "email is not empty", true branch only -> HTTP Request to the fake CRM -> HTTP Request to the fake outbox.
  **Without the IF node the Postgres node still passes one item on when no row came back, and the workflow sends every copy** (this happened in the author's first try).
  A duplicate caller gets HTTP 500 "No item to return was found"; a real build would add a branch that answers "duplicate".
* **(c) Data Table upsert.** Webhook -> **Data Table** node, operation Upsert on a table with one column `email`, match on email -> **IF** node comparing the row's `createdAt`
  and `updatedAt` (equal means the row is new) -> CRM -> outbox. The node gives no "was this inserted" flag; equality of the two times is a derived signal.
* **(a) Remove Duplicates node, default options** keyed on the email: shown only to document that it lets duplicates through under ten at once (2 of 20 runs). Do not use it that way.
* **(d)** is (a) with the environment variable `N8N_CONCURRENCY_PRODUCTION_LIMIT=1` set when n8n starts (one request at a time).

## 3. The "Proof" workflow (show the check inside n8n)

Purpose: viewers trust what they see in n8n, so the counts are shown on an n8n screen. The counts come from the fake servers' own counters, never from n8n's
own "success" mark: n8n's executions list says success for a duplicate caller that was answered with an error, so that list is not proof of "no double email".

Nodes (workflow "proof", manual start):
1. **Manual Trigger.**
2. **Edit Fields** / **Code** node that makes ten items, each the same lead with a different request id (`proof-1` to `proof-10`), same email, new email per run.
3. **HTTP Request** node posting each item to the n8n webhook of the variant (or straight to the desk's `/leads` for the desk scene). **UNVERIFIED whether this node can send the
   ten requests at the same moment.** Options to test: the node's Batching option (batch size 10, interval 0; name from memory), or ten parallel branches, or a sub-workflow
   called ten times without waiting. The author has not tried any of these. **Test that they really overlap** (the fake server's log shows ten requests arriving within a few
   milliseconds of each other). **Fallback if none overlap:** fire the burst from the burst script (`demo_only/burst.py`, see `contract.md`) and show only the n8n side in the video.
4. **Wait** node (a few seconds, longer than the fake servers' delay).
5. Two **HTTP Request** nodes, GET `/fake/crm` and GET `/fake/outbox` on the fake server.
6. **Edit Fields** node: `emails` = outbox `count`; `crm_rows` = CRM `count`; `expected` = 1; `result` = `{{ $json.emails == 1 && $json.crm_rows == 1 ? "PASS" : "MISMATCH" }}` (expression syntax from memory; UNVERIFIED).
   The output item on screen reads, for example, "emails: 1, CRM rows: 1, expected 1".

### The K3 scene (n8n killed between the two steps)

1. Reset the fake servers. Arm the delay on the CRM step of the fake server, so that the kill lands after the "have I seen this lead" step has written its row and before the email request is sent: `POST /fake/control` with `{"fail_next":"none","delay_ms":3000,"target":"crm"}` (`target` is `crm` or `outbox`; default `outbox`; it applies to the next post to that target only; see `contract.md`). The measurements in the README used this same delay, on the CRM step (the kill point called K3 there), in the order seen-check, CRM, email. They were taken by an AI agent that the author directed, with an earlier copy of the fakes server; the `target` control was added to this copy afterwards, so the scene as written here has not been repeated yet.
2. Start the proof run. While the fake server reports a request inside the delay, kill the n8n process abruptly (task manager "end process tree", or `kill -9` on Linux). This is like a power cut.
3. Restart n8n. Show the executions list: one entry marked "crashed".
4. Show the fake counters: 1 CRM row, 0 emails. Press n8n's retry on the crashed entry: it reports success and the email count stays 0 (this is what was measured by calling the retry through n8n's API, not by pressing the button: UNVERIFIED for the button).
5. Caption text to use : "Killed abruptly, like a power cut, between the two steps: 1 CRM row, 0 emails. We slow our fake server a little so the gap is wide enough to hit; in real life it is milliseconds."
   Caption the variant and n8n version, for example "n8n <version from versions.md>, variant (b): the database refuses a second row with the same email".

## 4. Exporting for sharing

n8n's export contains ids, an instance id and sometimes credential names. Run the scrub script first and read the result line by line before publishing anything.
Webhook paths and ids are removed by the script; after importing a scrubbed file you must set the webhook path again by hand. No real credentials exist in these workflows; keep it that way.
