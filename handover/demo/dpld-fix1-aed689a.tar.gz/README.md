# duplicate-proof-lead-desk

Send the same lead twice, in parallel, or around a crash. n8n with a database insert already gave one email in our test.
In a crash between "marked seen" and "email sent" that setup lost the lead: n8n listed the crashed run, and its retry
(called through n8n's programming interface, not by pressing the button) reported success but sent no email. We slowed our
fake CRM a little so the kill could land in that gap; in real life the gap is milliseconds long. This desk writes each
request down first, so after its own crash there is one email, or the follow-up is listed as UNKNOWN for a person to check.
A mail system that cannot recognise a repeat is the case where a person must look. Same lead means same email address
(trimmed and lower-cased, nothing more). Shown by the tests below, against fake systems.

"Duplicate-proof" means the promises in the table below, for this fake setup. It is not a guarantee for any real CRM or mail system.

Who wrote this: the author directed an AI agent that wrote most of the code and ran the n8n measurements. A person has not
re-run the n8n measurements. Everything here is one laptop and made-up data.

## Words used here

* **Lead**: a person who asked to be contacted. **Desk**: the small program in `src/lead_desk` that receives each request.
* **Lead book**: the desk's SQLite file. **Receipt**: the desk's first note about a request, written before anything else happens.
* **Follow-up**: the one email (plus one CRM row) the desk sends for a new lead. **Fake CRM, fake outbox**: small programs
  in `demo_only/` that only count what arrives; every number below comes from them.
* **Keyed mail system**: a mail system that recognises a repeat of the same send key. **Blind mail system**: one that does not.
* **UNKNOWN**: the follow-up may or may not have been sent; the desk will not guess and will not resend; a person checks.
* **Crash points** A, A2, B, D1, D2: five named moments in the desk's work where the test stops it on purpose (see `contract.md`).
* **K1, K2, K3** (the n8n tests): n8n is killed abruptly, like a power cut, at one of three moments. The n8n steps in these tests ran in
  this order: "have I seen this lead" check, then the CRM request, then the email request. **K3**: killed while the CRM request is in flight
  (we slow the fake CRM by 3 seconds), before the email request is sent. **K1**: killed while the email request is in flight (the fake outbox
  waits 3 seconds before storing). **K2**: killed after the fake outbox stored the email but before it answered.

**Not claimed**
* "Never silently lost" and "never sent twice" in general.
* The same person with two email addresses is two leads. "Same email" means the address with spaces trimmed and letters lower-cased
  and nothing more: `ada+sales@example.test` and `a.da@example.test` are different leads. Two people sharing one address are one lead.
* A real mail system or CRM was not tested. The keyed mail system is a simulation; a real provider may remember a send key for a
  shorter or longer time. The AI step is a recorded fake; nothing is said about real AI behaviour.
* The desk assumes the follow-up is the only thing that sends mail for a lead's send key.
* A crash is simulated inside the program for all five crash points, and a real process kill was done only for point D2.
  Power loss was not tested.
* 100-request and 10,000-request loads were not run. The desk is for one laptop and one process. There is no login; it listens on this computer only.
* Mostly run on one system: Windows with Python 3.13 (see "What has been run" below).
* n8n crashing before the request reaches the desk.
* Other n8n versions or set-ups: the n8n measurements are one pattern, one laptop, made-up data, measured by an AI agent.
* A person answering "not sent" wrongly for an UNKNOWN follow-up on a mail system that cannot recognise repeats (then a
  second email can go). UNKNOWN items stay unseen unless someone opens the review list.
* A follow-up stuck in `sending` because the database stayed locked through all retries is repaired only by restarting the desk.
* Exactly-once delivery, production fitness, demand, any customer result, a legal opinion. The licence text has not been reviewed by a lawyer.

This is a demo with made-up data and fake systems only. No real customer data, no secrets and no live model calls are used.

## What each promise rests on

There are 32 test functions (42 test cases when the parametrised ones are expanded): 21 desk tests, 4 hygiene tests, 2 mutation guards and 5 edge-case tests.
Result column: from the full run described under "What has been run".

| # | Promise, in plain words | Tests | Result |
|---|---|---|---|
| P1 | (a) A second submission with a different request id and the same email is recorded as a duplicate with the NAMES of the fields that differ; no second CRM row, no second email. (b) The same request id sent again gets the original answer marked `replayed` and changes nothing. n8n with a database insert gave the same result in our test. | (a) `test_cross_source_dupe`, `test_dupe_diff_first_untouched`, `test_write_once_triggers`; (b) `test_replay_same_source_ref`, `test_concurrent_same_source_ref` | passed |
| P2 | A duplicate never reaches the AI step: the fake AI's call counter does not go up for it. | `test_dedupe_before_ai` | passed |
| P3 | A submission with no name, no email, an invalid email or a wrongly typed field goes to the review list with a reason and gets no follow-up. | `test_incomplete_to_review` | passed |
| P4 | Stopped at each of the five named points and restarted, in both mail-system modes: one lead line, and in the keyed mode exactly one email. Blind mode: points A, A2, B one email; D1 no email and an UNKNOWN flag; D2 one email and an UNKNOWN flag. Those are the tested cases (five points, two modes); the stop is simulated inside the program, and the one real process kill is at D2. Exception: a wrong "not sent" answer by a person can cause a second email on a blind system. | `test_crash_resume_each_point` (5 points, keyed and blind), `test_crash_d2_subprocess` (a real process kill) | passed |
| P5 | Ten requests with different request ids and the same email, fired at once straight at the desk by a script: one new lead, nine duplicates, one email; the counts match the number the script says it sent. A 100-request run, if done, is an observation, not a promise. n8n with a database insert gave the same result in our test. | `test_ten_parallel`, `test_reconcile_counts` | passed |
| P6 | On a blind mail system, a send that may or may not have happened is marked UNKNOWN, listed for a person and never resent by the desk; Retry is refused for it. Retry pressed twice at once on a failed follow-up gives one email, also on a blind system. | `test_unknown_blind`, `test_failed_retry`, `test_retry_twice_concurrent` | passed |

Also tested, not a headline promise: odd input and requests (`tests/test_hardening.py`: half-character escapes, deeply nested JSON, `HEAD`,
`OPTIONS` and malformed requests get a JSON answer, an email that grows when lower-cased, two drives of one new lead at once).

"Mutation check": two protections are removed one at a time, on the test side only, and the named test must fail with the named symptom.
`test_mutant_no_unique_key` removes the database rule that two leads cannot share an email and the lookup; the duplicate test must fail
with "leads == 1" and "got 2". `test_mutant_no_claim` removes the check that only one retry may take a follow-up; the retry test must fail
with "emails == 1" and "got 2". This shows the tests notice these two faults; it is not proof that the code is correct.

## What has been run

* **Windows, Python 3.13.3, 2026-11-09, on the author's laptop:** ruff check, ruff format check, mypy (Windows and Linux settings), bandit,
  the schema self-check and the full test suite twice: 41 of 42 test cases passed each time. The one that does not pass is
  `test_hygiene_wordlist`, which needs a private word list that is not published (it fails on purpose instead of skipping).
  gitleaks 8.30.1 ran on this computer, inside `test_hygiene_scan_public`, on the tracked files and the history.
* On the version before the last fixes: the four concurrency tests (`test_concurrent_same_source_ref`, `test_retry_twice_concurrent`,
  `test_ten_parallel`, `test_reconcile_counts`) were repeated 10 times each on Windows and passed every time; the full suite was run twice in a
  Linux container (`python:3.12-slim`, Python 3.12.16) and 35 of 37 test cases passed (the two failures: no `git` program in that container
  image for the hygiene scan, and the private word list). The Linux run was not repeated on this version.
* **Not run:** the GitHub checks on a pull request (this repository has not been pushed anywhere, so `lint.yml` and CodeQL have never run),
  gitleaks inside GitHub's runner, the run scripts (`scripts/start_all.*`, `reset.*`, `feed.py`, `video_crash.py`) on any system, the
  steps for Linux or macOS, importing the n8n recipe into a fresh n8n, and any video. `SECURITY.md` asks for private reporting; that
  GitHub setting has to be switched on by the author once the repository is published.

## What we measured with n8n alone (and how)

Before building the desk, we measured whether n8n alone does the job. Method: n8n 2.46.6 on Node 24.22.2 (`versions.md`), regular mode, one
process, on one laptop; a script sent ten requests at once (different request ids, one email address, a new address per run) to
an n8n webhook; fake CRM and fake outbox servers counted what arrived (blind counting, no deduplication on their side; started with
`--crm blind --outbox blind`). The pass rule was written down (and its checksum recorded) before the counts were read.
20 runs per variant for the ten-at-once test, 5 runs per kill point. These runs were done by an AI agent; a person has not repeated them.
No video of them exists yet.

Table: n8n 2.46.6, Node 24.22.2.

| n8n variant | Ten at once, 20 runs, exactly 1 email and 1 CRM row each | Replay after 5 s | Killed during the email request (K1, K2), 5 runs each |
|---|---|---|---|
| (a) Remove Duplicates node, default settings | NO: 18 runs gave 1 and 1; one run gave 3 and 3, one gave 8 and 8 | added nothing | one K1 run ended with 4 and 4 (already 4 before the kill) |
| (b) a database refuses a second row with the same email | 20 of 20 | added nothing | 1 and 1 at most |
| (c) a Data Table upsert plus a check on its created/updated times | 20 of 20 | added nothing | 1 and 1 at most |
| (d) same as (a) with n8n told to run one request at a time | 20 of 20 (the requests never overlapped, by design) | added nothing | 1 and 1 at most |

* **Variant (a), n8n's Remove Duplicates node with default settings, let duplicates through in 2 of 20 runs.** Do not use it that way.
* **K3** (killed while the CRM request is in flight, before the email request): in all 20 runs of all four variants the result was 1 CRM row
  and 0 emails. n8n's executions list showed the crashed run. n8n's retry, called through its programming interface (not the button), showed
  "success" and sent no email. The lead is lost until a person notices. The real gap is milliseconds long; the fake CRM adds a 3 second delay so the kill can land in it.
* A duplicate caller receives an error reply (HTTP 500 "No item to return was found") in every variant, so a real workflow needs a
  branch that answers "duplicate" cleanly. Whether n8n's own list calls such a run "success" is UNVERIFIED.
* **(e) A fix inside n8n: a status column plus a scheduled re-send job**, measured on a blind mail system, 5 runs per kill point, n8n 2.46.6.
  No lead was lost. But a second email went out in 10 of the 15 crash runs: all 10 runs killed while the email request was in flight or
  just after the email was stored, and none of the 5 runs killed later, while the CRM request was in flight. In 2 of the 5 runs at each of those two
  first points there was also a second CRM row (two re-send runs overlapped; the cause is probable, not verified). The re-send job was a first
  try and is untuned: it runs every 15 seconds, takes no "claim" on a row before sending, and has no limit on overlapping runs. A better-built
  n8n pattern was not tested. Also not tested: a keyed mail system, n8n's retry button, the case where n8n dies before the email request
  leaves n8n (in these runs the fake mail server had already received the first email), other intervals, queue mode. In this variant the
  steps ran in a different order (email, then status update, then CRM), so the K1, K2, K3 names above do not apply to it.
* We tested the simplest patterns only. Other n8n versions and set-ups are not covered.

n8n's licence (Sustainable Use License) allows running it locally for our own demo; it is not shipped in this repository.
The step-by-step recipe to rebuild the n8n side is in `docs/n8n-recipe.md`. Every step the author could not check is marked UNVERIFIED there.

## What the checks do not cover

The scan for hardcoded literals is a safety net, not a guarantee. A value of these kinds can pass it, so read changes by eye: `.in` host names,
compressed IPv6 addresses (for example `fe80::1`), internal host names with a top-level domain that is not in the list (for example `db.internal`,
`server.local`), UNC paths (`\\server\share`), and bare port numbers. Numbers and ports are NOT checked by that scan; they live in
`src/lead_desk/config.py` and `src/lead_desk/constants.py`. Base64-encoded private words are not covered by the word-list check.

## Run it (made-up data, fakes only)

Python 3.12 or newer, standard library only at run time. Install the development tools from the lock file for your system
(hashes are checked): `python -m pip install --require-hashes -r requirements-dev.txt` (Linux, Python 3.12) or
`-r requirements-dev-win.txt` (Windows, Python 3.13). The two files hold the same versions.

Linux (from the repository root; these steps have not been run, see "What has been run"):

    scripts/start_all.sh keyed          # or: blind   (starts the fake servers and the desk; logs go under ./data)
    PYTHONPATH=src python scripts/feed.py --source form --index 1
    PYTHONPATH=src python scripts/feed.py --source webhook --index 1
    scripts/reset.sh                    # stops what start_all started and deletes the lead book
    PYTHONPATH=src python -m pytest -q  # the tests

Windows PowerShell (from the repository root; the run scripts have not been run, the tests have):

    powershell -NoProfile -File scripts\start_all.ps1 keyed
    $env:PYTHONPATH = "src"; python scripts\feed.py --source form --index 1
    powershell -NoProfile -File scripts\reset.ps1

The desk alone: `PYTHONPATH=src python -m lead_desk.server`. The crash scene: `PYTHONPATH=src python scripts/video_crash.py`, then write
a point name (for example `D2`) into the flag file it prints, and the next time the desk reaches that point it ends at once.
On Windows set `PYTHONPATH` with `;` between entries when two are needed (`src;.`). The tests set the path for their own processes.

The checks that are set up to run on every pull request (`.github/workflows/lint.yml`, not yet run on GitHub): ruff, mypy, bandit, a schema check,
gitleaks on the files and the history, a scan for hardcoded addresses, links, absolute paths, e-mail addresses and long tokens, and all tests
except `test_hygiene_wordlist`, which needs a private word list that is never published and is run only on the author's computer. `.env` files
are never used: the demo needs no secrets.

## Settings

Every setting has a default in `Config` (`src/lead_desk/config.py`) and an environment variable. A bad value stops the start with an error.

| Setting | Environment variable | Default | Meaning |
|---|---|---|---|
| `db_path` | `DESK_DB_PATH` | `./data/desk.sqlite3` | the lead book |
| `bind` | `DESK_BIND` | `127.0.0.1` | address the desk listens on (this computer only; there is no login) |
| `port` | `DESK_PORT` | `8765` | desk port (0 = pick a free one, used by tests) |
| `adapters` | `DESK_ADAPTERS` | `demo` | which sender, CRM and AI step to use; only the fake ones exist here |
| `fakes_host`, `fakes_port` | `DESK_FAKES_HOST`, `DESK_FAKES_PORT` | `127.0.0.1`, `8766` | where the fake CRM and outbox listen |
| (both above) | `DESK_FAKES_URL` | built from the two above | one `http` address with host and port; wins over the two above |
| `replies_path` | `DESK_REPLIES_PATH` | none (the loader uses the `replies.json` inside `demo_only/`) | the recorded AI replies |
| `send_timeout_seconds` | `DESK_SEND_TIMEOUT_SECONDS` | `5.0` | wait per network step, also for the CRM call |
| `size_cap_bytes` | `DESK_SIZE_CAP_BYTES` | `65536` | largest request body accepted (larger gets 413) |
| `stall_seconds` | `DESK_STALL_SECONDS` | `120` | after this long an unfinished item shows as `stalled` on the review list |

Fixed in code, not settings: SQLite busy wait, listen queue length and lock retries (`constants.py`).

## Layout

`src/lead_desk` the desk. `demo_only/` everything that exists only for demos and tests (fake servers, recorded AI replies, burst script,
canned leads); the desk reaches it only through `src/lead_desk/loader.py`. `tests/` the tests. `scripts/` run and demo helpers.
`docs/n8n-recipe.md` the n8n side. `contract.md` the exact HTTP replies and rules the code and tests must agree on. `versions.md` tool versions and licences.

## Licence and status

All rights reserved; published for viewing only (see `LICENSE`). Not reviewed by a lawyer. Pull requests are limited to the author.
See `SECURITY.md` to report a problem. This README is one laptop, made-up data, and measured by an AI agent working for the author;
treat every number as that and nothing more.
