"""HTTP layer. Standard library only.

`python -m lead_desk.server` reads its settings from the environment (config.Config.from_env), takes the lock file,
binds, starts the desk (schema and sweep) and serves until stopped. It prints one line `desk listening on
http://<host>:<port>` once it accepts requests: the port is the real one, so DESK_PORT=0 (ephemeral) can be learned
from that line."""

from __future__ import annotations

import json
import logging
import os
import socket
import sys
import threading
from collections.abc import Callable
from dataclasses import replace
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, cast
from urllib.parse import parse_qs, unquote, urlsplit

from lead_desk import db, lockfile
from lead_desk.adapters import FakesUnreachable
from lead_desk.config import Config
from lead_desk.constants import (
    DRAIN_MAX_BYTES,
    EXIT_ADAPTERS_UNREACHABLE,
    EXIT_ANOTHER_DESK,
    HTTP_BAD_REQUEST,
    HTTP_BUSY,
    HTTP_INTERNAL_ERROR,
    HTTP_METHOD_NOT_ALLOWED,
    HTTP_NOT_FOUND,
    HTTP_TOO_LARGE,
    LISTEN_QUEUE,
    REQUEST_TIMEOUT_SECONDS,
    SOURCE_REF_MAX,
    SOURCE_REF_MIN,
    SOURCES,
)
from lead_desk.desk import Desk, Reply
from lead_desk.hooks import Hooks
from lead_desk.loader import load_demo_adapters

log = logging.getLogger("lead_desk")


class _Server(ThreadingHTTPServer):
    allow_reuse_address = os.name != "nt"  # on Windows SO_REUSEADDR would allow a second listener on the same port
    request_queue_size = LISTEN_QUEUE
    desk: Desk
    config: Config

    def server_bind(self) -> None:
        if sys.platform == "win32":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def _route(method: str, path: str) -> tuple[str, str | None] | int:
    """(route name, path argument) for a known route and method; else 405 or 404 (a status int)."""
    parts = [unquote(p) for p in path.strip("/").split("/")] if path != "/" else []
    match parts:
        case ["leads"]:
            name, arg, allowed = "post_lead", None, "POST"
        case ["leads", ref] if ref:
            name, arg, allowed = "get_lead", ref, "GET"
        case ["review"]:
            name, arg, allowed = "review", None, "GET"
        case ["review", item, ("retry" | "resolve") as action] if item:
            name, arg, allowed = action, item, "POST"
        case ["counts"]:
            name, arg, allowed = "counts", None, "GET"
        case _:
            return HTTP_NOT_FOUND
    return (name, arg) if method == allowed else HTTP_METHOD_NOT_ALLOWED


class _Handler(BaseHTTPRequestHandler):
    timeout = REQUEST_TIMEOUT_SECONDS
    server_version = "lead-desk"

    @property
    def _desk(self) -> Desk:
        return cast(_Server, self.server).desk

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return None  # no request log: it would carry addresses

    # -- reply helpers
    def _send(self, status: int, obj: Any) -> None:
        raw = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Connection", "close")
        self.end_headers()
        if getattr(self, "command", None) != "HEAD":
            self.wfile.write(raw)
        self.close_connection = True

    def send_error(self, code: int, message: str | None = None, explain: str | None = None) -> None:
        """The standard library answers a malformed request line or an unknown method with an HTML page; answer in
        JSON like every other reply."""
        try:
            name = HTTPStatus(code).phrase.lower().replace(" ", "_")
        except ValueError:
            name = "error"
        self._send(code, {"error": name})

    def _flush_and_half_close(self) -> None:
        """The reply is complete for the client now; the follow-up must not keep it waiting."""
        try:
            self.wfile.flush()
            self.connection.shutdown(socket.SHUT_WR)
        except OSError:
            pass

    def _drain(self, remaining: int) -> None:
        """Read and drop request bytes we did not need, so closing does not reset the connection under the reply."""
        try:
            left = min(max(remaining, 0), DRAIN_MAX_BYTES)
            while left > 0:
                chunk = self.rfile.read(min(left, 65536))  # noqa: PLR2004
                if not chunk:
                    break
                left -= len(chunk)
        except OSError:
            pass

    def _content_length(self) -> int | None:
        raw = self.headers.get("Content-Length")
        if raw is None or not (raw.isascii() and raw.isdecimal()):
            return None
        return int(raw)

    # -- dispatch
    def _dispatch(self, method: str) -> None:
        desk = self._desk
        try:
            parts = urlsplit(self.path)
            routed = _route(method, parts.path)
            if isinstance(routed, int):
                self._skip_body()
                self._send(routed, {"error": "not_found" if routed == HTTP_NOT_FOUND else "method_not_allowed"})
                return
            name, arg = routed
            follow: str | None = None
            if name == "post_lead":
                follow = self._post_lead()
            elif name == "get_lead":
                self._send_reply(desk.lead(str(arg)))
            elif name == "review":
                self._send_reply(desk.review())
            elif name == "counts":
                self._counts(parts.query)
            elif name == "retry":
                self._skip_body()
                self._send_reply(desk.retry(str(arg)))
            else:
                self._resolve(str(arg))
            self._flush_and_half_close()
            if follow is not None:
                desk.run_followup(follow)
        except Exception as e:
            log.warning("handler failed: %s", type(e).__name__)
            busy = db.is_busy(e)
            try:
                self._send(HTTP_BUSY if busy else HTTP_INTERNAL_ERROR, {"error": "busy" if busy else "internal"})
                self._flush_and_half_close()
            except OSError:
                pass
        finally:
            desk.close()  # this request thread's connection

    def _send_reply(self, reply: Reply) -> None:
        self._send(reply.status, reply.body)

    def _skip_body(self) -> None:
        n = self._content_length()
        if n:
            self._drain(n)

    def _counts(self, query: str) -> None:
        q = parse_qs(query, keep_blank_values=True)
        expected: int | None = None
        if "expected" in q:
            raw = q["expected"][0]
            if not (raw.isascii() and raw.isdecimal()):  # empty, not an integer, or negative
                self._send(HTTP_BAD_REQUEST, {"error": "bad_expected"})
                return
            expected = int(raw)
        self._send_reply(self._desk.counts(expected))

    def _resolve(self, item_id: str) -> None:
        n = self._content_length() or 0
        raw = self.rfile.read(min(n, DRAIN_MAX_BYTES)) if n else b""
        decision: Any = None
        try:
            obj = json.loads(raw.decode("utf-8"))
            decision = obj.get("decision") if isinstance(obj, dict) else None
        except (ValueError, RecursionError):
            decision = None
        if not isinstance(decision, str):  # before any lookup: even an unknown item id gives 400 here
            self._send(HTTP_BAD_REQUEST, {"error": "bad_decision"})
            return
        self._send_reply(self._desk.resolve(item_id, decision))

    def _reject_envelope(self, status: int, error: str) -> None:
        self._desk.note_rejected_envelope()
        self._send(status, {"error": error, "receipt_id": None})

    def _post_lead(self) -> str | None:
        """Envelope check (no database), then desk.process. Returns the lead id whose follow-up the caller runs."""
        desk, cap = self._desk, self._desk.config.size_cap_bytes
        n = self._content_length()
        if n is None:
            self._reject_envelope(HTTP_BAD_REQUEST, "bad_envelope")
            return None
        raw = self.rfile.read(min(n, cap + 1))
        if len(raw) > cap or n > cap:
            self._reject_envelope(HTTP_TOO_LARGE, "too_large")
            self._flush_and_half_close()
            self._drain(n - len(raw))
            return None
        try:
            env = json.loads(raw.decode("utf-8"))
        except (ValueError, RecursionError):  # not JSON, or nested so deeply that the parser gives up
            env = None
        ref = env.get("source_ref") if isinstance(env, dict) else None
        if not (
            isinstance(env, dict)
            and env.get("source") in SOURCES
            and isinstance(ref, str)
            and SOURCE_REF_MIN <= len(ref) <= SOURCE_REF_MAX
            and isinstance(env.get("payload"), dict)
        ):
            self._reject_envelope(HTTP_BAD_REQUEST, "bad_envelope")
            return None
        reply = desk.process(env["source"], ref, env["payload"])
        self._send_reply(reply)
        return reply.drive_lead_id

    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def do_PUT(self) -> None:
        self._dispatch("PUT")

    def do_DELETE(self) -> None:
        self._dispatch("DELETE")

    def do_PATCH(self) -> None:
        self._dispatch("PATCH")

    def do_HEAD(self) -> None:
        self._dispatch("HEAD")

    def do_OPTIONS(self) -> None:
        self._dispatch("OPTIONS")


def make_server(desk: Desk, config: Config) -> ThreadingHTTPServer:
    """ThreadingHTTPServer subclass: allow_reuse_address = (os.name != "nt"), SO_EXCLUSIVEADDRUSE set in
    server_bind on Windows (`sys.platform == "win32"`), request_queue_size = constants.LISTEN_QUEUE.

    Handler order per request: read bytes and enforce the cap, parse JSON and the envelope, call desk.process,
    write the reply with Content-Length and Connection: close, then wfile.flush() and
    connection.shutdown(SHUT_WR) BEFORE desk.run_followup, so a client that reads until close is not kept waiting
    for the follow-up. For POST /review/{id}/resolve the handler parses the body and answers 400 bad_decision
    BEFORE any item lookup when the body is not JSON or `decision` is missing or not a string.

    Windows limit (UNVERIFIED, decided by the restart test): a restart on the same fixed port may fail while the
    old connections sit in TIME_WAIT, and the conflicting bind may raise PermissionError instead of
    EADDRINUSE; both are OSError, which callers catch broadly."""
    server = _Server((config.bind, config.port), _Handler)
    server.desk, server.config = desk, config
    return server


def serve_in_thread(desk: Desk, port: int = 0) -> tuple[str, Callable[[], None]]:
    """Returns (base_url, stop). Does NOT call desk.startup(). A bind failure raises OSError (any subclass)."""
    cfg = replace(desk.config, port=port)
    server = make_server(desk, cfg)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def stop() -> None:
        server.shutdown()
        server.server_close()
        thread.join(timeout=REQUEST_TIMEOUT_SECONDS)

    host, bound = server.server_address[0], server.server_address[1]
    return f"http://{host!s}:{bound}", stop


def main(hooks: Hooks | None = None) -> None:
    """python -m lead_desk.server: lock file, bind, adapters, startup (schema and sweep), serve. Exit code 2 if
    another desk holds the lock or the port is taken (OSError, not only EADDRINUSE); exit code 1 if the sender
    cannot be reached. `hooks` goes to the Desk (tests/crash_launcher.py and scripts/video_crash.py pass
    `FlagFileHooks(path)`)."""
    config = Config.from_env()
    config.db_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        lock = lockfile.acquire(config.db_path)
    except OSError:
        print("another desk is using this database", flush=True)
        sys.exit(EXIT_ANOTHER_DESK)
    try:
        crm, outbox, qualifier = load_demo_adapters(config)
    except FakesUnreachable:
        print("cannot read /fake/info from the sender", flush=True)
        sys.exit(EXIT_ADAPTERS_UNREACHABLE)
    desk = Desk(config, crm, outbox, qualifier, hooks=hooks)
    try:
        server = make_server(desk, config)
    except OSError as e:
        print(f"cannot bind {config.bind}:{config.port}: {type(e).__name__}", flush=True)
        sys.exit(EXIT_ANOTHER_DESK)
    try:
        desk.startup()
        host, port = server.server_address[0], server.server_address[1]
        print(f"desk listening on http://{host!s}:{port}", flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        desk.close()
        lock.close()


if __name__ == "__main__":
    main()
