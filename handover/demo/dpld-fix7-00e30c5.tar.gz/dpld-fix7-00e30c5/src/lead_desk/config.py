"""The one validated home for ports and defaults."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlsplit

from lead_desk.constants import ADAPTER_CHOICES, PORT_MAX


@dataclass(frozen=True)
class Config:
    db_path: Path = Path("./data/desk.sqlite3")
    bind: str = "127.0.0.1"
    port: int = 8765  # 0 = ephemeral (tests)
    adapters: str = "demo"  # selects the demo adapters through loader.py
    fakes_host: str = "127.0.0.1"
    fakes_port: int = 8766
    replies_path: Path | None = None  # None = the loader supplies its own default
    send_timeout_seconds: float = 5.0  # per network operation; also used for the CRM call
    size_cap_bytes: int = 65536
    stall_seconds: int = 120

    @property
    def fakes_url(self) -> str:
        """Built from host and port; there is no URL literal."""
        return f"http://{self.fakes_host}:{self.fakes_port}"

    def __post_init__(self) -> None:
        if not 0 <= self.port <= PORT_MAX:
            raise ValueError("port out of range")
        if not 1 <= self.fakes_port <= PORT_MAX:
            raise ValueError("fakes_port out of range")
        if self.adapters not in ADAPTER_CHOICES:
            raise ValueError("adapters must be one of " + ", ".join(ADAPTER_CHOICES))
        if not self.bind or not self.fakes_host:
            raise ValueError("bind and fakes_host must not be empty")
        if self.send_timeout_seconds <= 0:
            raise ValueError("send_timeout_seconds must be positive")
        if self.size_cap_bytes < 1:
            raise ValueError("size_cap_bytes must be positive")
        if self.stall_seconds < 0:
            raise ValueError("stall_seconds must not be negative")

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> Config:
        """Read DESK_DB_PATH, DESK_BIND, DESK_PORT, DESK_ADAPTERS, DESK_FAKES_URL (split into host and port),
        DESK_FAKES_HOST, DESK_FAKES_PORT, DESK_REPLIES_PATH, DESK_SEND_TIMEOUT_SECONDS, DESK_SIZE_CAP_BYTES,
        DESK_STALL_SECONDS. Missing names keep the defaults above. Bad values raise ValueError.
        Precedence: DESK_FAKES_URL wins over DESK_FAKES_HOST / DESK_FAKES_PORT when both are set. The URL scheme
        must be http (anything else raises ValueError). A non-empty URL path other than "/" raises ValueError (it
        would be silently dropped otherwise). A query, a fragment and userinfo (`user:pw@`) are ignored: only the
        host and the port are taken. An IPv6 host keeps its brackets in fakes_host."""
        e = os.environ if env is None else env
        kw: dict[str, Any] = {}
        if "DESK_DB_PATH" in e:
            kw["db_path"] = Path(e["DESK_DB_PATH"])
        if "DESK_BIND" in e:
            kw["bind"] = e["DESK_BIND"]
        if "DESK_PORT" in e:
            kw["port"] = int(e["DESK_PORT"])
        if "DESK_ADAPTERS" in e:
            kw["adapters"] = e["DESK_ADAPTERS"]
        if "DESK_FAKES_HOST" in e:
            kw["fakes_host"] = e["DESK_FAKES_HOST"]
        if "DESK_FAKES_PORT" in e:
            kw["fakes_port"] = int(e["DESK_FAKES_PORT"])
        if "DESK_FAKES_URL" in e:  # applied after HOST/PORT below, so it takes precedence
            parts = urlsplit(e["DESK_FAKES_URL"])
            if parts.scheme != "http":
                raise ValueError("DESK_FAKES_URL must use http")
            if parts.path not in ("", "/"):
                raise ValueError("DESK_FAKES_URL must not have a path")
            if parts.hostname is None or parts.port is None:
                raise ValueError("DESK_FAKES_URL needs a host and a port")
            kw["fakes_host"] = f"[{parts.hostname}]" if ":" in parts.hostname else parts.hostname
            kw["fakes_port"] = parts.port
        if "DESK_REPLIES_PATH" in e:
            kw["replies_path"] = Path(e["DESK_REPLIES_PATH"])
        if "DESK_SEND_TIMEOUT_SECONDS" in e:
            kw["send_timeout_seconds"] = float(e["DESK_SEND_TIMEOUT_SECONDS"])
        if "DESK_SIZE_CAP_BYTES" in e:
            kw["size_cap_bytes"] = int(e["DESK_SIZE_CAP_BYTES"])
        if "DESK_STALL_SECONDS" in e:
            kw["stall_seconds"] = int(e["DESK_STALL_SECONDS"])
        return cls(**kw)
