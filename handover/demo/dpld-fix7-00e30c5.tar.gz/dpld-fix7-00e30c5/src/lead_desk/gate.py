"""Fair write gate, in-flight limit and the background-repair constants (standard library only).

Why: SQLite's own busy wait is not fair (a waiting writer sleeps and polls, so a late writer can win again and again).
Under 100+ simultaneous requests that starved some writers until the 5 s wait ran out. The gate puts every writer of
this process in one first-come-first-served line BEFORE it asks SQLite for the write lock, so inside one desk process
SQLite itself is never contended. Another process (a second desk is refused by the lock file; a tool holding the file)
still gets the ordinary SQLite busy wait."""

from __future__ import annotations

import collections
import threading
from pathlib import Path
from typing import Final

from lead_desk.constants import BUSY_WAIT_SECONDS

# -- limits (names, not settings; one place)
INFLIGHT_MAX: Final = 32  # Desk.process calls running at once; more wait, then get 503 busy (no receipt written)
INFLIGHT_WAIT_SECONDS: Final = BUSY_WAIT_SECONDS  # how long a request waits for a place before 503 busy
DRIVE_MAX: Final = 8  # follow-up drives running at once (they have their own places: they cannot crowd out requests)
DRIVE_WAIT_SECONDS: Final = BUSY_WAIT_SECONDS  # a drive that finds no place in this time is left to the reaper
GATE_WAIT_SECONDS: Final = BUSY_WAIT_SECONDS  # how long a writer waits in the gate line before "database is locked"
WRITE_DEADLINE_SECONDS: Final = GATE_WAIT_SECONDS + BUSY_WAIT_SECONDS  # all tries of ONE write together (one deadline)
REQUEST_DEADLINE_SECONDS: Final = 3 * BUSY_WAIT_SECONDS  # one request, its inflight wait and all its writes together

# -- background reaper
REAPER_INTERVAL_SECONDS: Final = 1.0  # pause between two reaper passes
REAPER_PASS_SECONDS: Final = 10.0  # real seconds one pass may spend driving follow-ups (the rest waits for the next)
DECIDE_FAIL_LIMIT: Final = 3  # consecutive non-busy decision failures of one receipt, then it gets verdict review
# a `sending` row is stuck after send timeout + this many busy waits. The result write after a send is bounded by
# WRITE_DEADLINE_SECONDS plus one more SQLite busy wait (a lock held by another process): 3 busy waits. The grace is one
# more than that, so a live drive that is still writing its result is never taken for a stuck one.
SENDING_GRACE_BUSY_WAITS: Final = 4
PENDING_GRACE_SECONDS: Final = 2  # a fresh `pending` row is left to the request that made it for this long

# -- automatic retry of a try that failed in a way that can be tried again (see Desk._send_claimed / _after_claim)
SEND_MAX_ATTEMPTS: Final = 5  # tries in total (the first drive counts), then the follow-up becomes `failed`
OUTBOX_REFRESH_SECONDS: Final = 30  # the reaper reads the sender's mode at most this often
SEND_BACKOFF_SECONDS: Final = (1, 2, 4, 8)  # pause after try 1, 2, 3, 4 (the last value repeats if the cap is raised)


def backoff_after(attempt: int) -> int:
    """Seconds to wait after the given try (1-based) before the next automatic try."""
    return SEND_BACKOFF_SECONDS[min(max(attempt, 1), len(SEND_BACKOFF_SECONDS)) - 1]


class GateTimeout(Exception):
    """The gate line did not move within the wait."""


class FairGate:
    """FIFO ticket lock: waiters are served strictly in arrival order. Not re-entrant. Two lines: a writer that asks
    with low=True (a follow-up drive, the reaper) is served only when no normal writer (a request) is waiting."""

    def __init__(self) -> None:
        self._mutex = threading.Lock()
        self._held = False
        self._waiters: collections.deque[threading.Event] = collections.deque()
        self._low: collections.deque[threading.Event] = collections.deque()

    def acquire(self, timeout: float, low: bool = False) -> None:
        with self._mutex:
            if not self._held and not self._waiters and not self._low:
                self._held = True
                return
            ticket = threading.Event()
            line = self._low if low else self._waiters
            line.append(ticket)
        try:
            if ticket.wait(max(timeout, 0.0)):
                return  # the releaser handed the gate over: _held stays True
        except BaseException:
            self._leave(ticket, line)  # an interrupt inside the wait must not leave the ticket in the line
            raise
        if self._leave(ticket, line):
            return
        raise GateTimeout

    def _leave(self, ticket: threading.Event, line: collections.deque[threading.Event]) -> bool:
        """Take the ticket out of its line. True when the gate was handed to it just before (it now holds the gate)."""
        with self._mutex:
            if ticket.is_set():
                return True
            line.remove(ticket)
            return False

    def release(self) -> None:
        with self._mutex:
            if self._waiters:
                self._waiters.popleft().set()  # hand over directly: no barging by a late arrival
            elif self._low:
                self._low.popleft().set()
            else:
                self._held = False


class FairSemaphore:
    """Counting semaphore with first-come-first-served hand-off (threading.BoundedSemaphore lets a late arrival take a
    freed place ahead of old waiters, so old waiters starve until their wait runs out). acquire(timeout=) -> bool."""

    def __init__(self, places: int) -> None:
        self._mutex = threading.Lock()
        self._free = places
        self._max = places
        self._waiters: collections.deque[threading.Event] = collections.deque()

    def acquire(self, timeout: float | None = None) -> bool:
        with self._mutex:
            if self._free > 0 and not self._waiters:
                self._free -= 1
                return True
            ticket = threading.Event()
            self._waiters.append(ticket)
        try:
            if ticket.wait(timeout):
                return True  # the releaser handed its place over
        except BaseException:
            self._leave(ticket)
            raise
        return self._leave(ticket)

    def _leave(self, ticket: threading.Event) -> bool:
        with self._mutex:
            if ticket.is_set():
                return True
            self._waiters.remove(ticket)
            return False

    def release(self) -> None:
        with self._mutex:
            if self._waiters:
                self._waiters.popleft().set()
            elif self._free < self._max:
                self._free += 1
            else:
                raise ValueError("released too many times")


_GATES: dict[str, FairGate] = {}
_GATES_LOCK = threading.Lock()


def gate_for(db_path: Path | str) -> FairGate:
    """The write gate of one lead book: every Desk on the same resolved path shares one line, desks on different
    books do not wait for each other. A private in-memory book (empty path or ':memory:') gets its own gate each time.
    The gate is NOT re-entrant: code holding it must never ask for it again (Desk._write is never nested)."""
    text = str(db_path)
    if text in ("", ":memory:"):
        return FairGate()
    key = str(Path(text).resolve())
    with _GATES_LOCK:
        found = _GATES.get(key)
        if found is None:
            found = _GATES[key] = FairGate()
        return found
