"""Named values that are not settings. Ports and defaults live in config.Config, not here."""

from __future__ import annotations

from typing import Final

# HTTP status codes the desk and the fakes server use
HTTP_OK: Final = 200
HTTP_CREATED: Final = 201
HTTP_ACCEPTED: Final = 202
HTTP_BAD_REQUEST: Final = 400
HTTP_NOT_FOUND: Final = 404
HTTP_METHOD_NOT_ALLOWED: Final = 405
HTTP_REQUEST_TIMEOUT: Final = 408
HTTP_CONFLICT: Final = 409
HTTP_TOO_LARGE: Final = 413
HTTP_UNPROCESSABLE: Final = 422
HTTP_TOO_MANY_REQUESTS: Final = 429
HTTP_INTERNAL_ERROR: Final = 500
HTTP_BUSY: Final = 503

# Process exit codes
EXIT_OK: Final = 0
EXIT_ANOTHER_DESK: Final = 2  # another desk holds the lock file, or the port bind failed
EXIT_SIMULATED_KILL: Final = 137  # scripts/video_crash.py: os._exit(137) at the chosen crash point

# Field limits
SOURCE_REF_MIN: Final = 1
SOURCE_REF_MAX: Final = 128
NAME_MAX: Final = 200
EMAIL_MAX: Final = 254
EMAIL_KEY_MIN: Final = 3
PHONE_MAX: Final = 40
COMPANY_MAX: Final = 200
MESSAGE_MAX: Final = 2000

# SQLite and server rules
BUSY_WAIT_SECONDS: Final = 5.0  # sqlite3.connect(timeout=...): the one busy-wait setting
LISTEN_QUEUE: Final = 1024  # request_queue_size (listen backlog); the operating system may cap it lower
LOCK_RETRIES: Final = 3  # lock-timeout retries for the claim and the result record
BIND_RETRY_SECONDS: Final = 5.0  # launcher retries the bind this long
SCHEMA_VERSION: Final = 1  # PRAGMA user_version after schema.sql
LEAD_ID_PREFIX: Final = "L"
LEAD_ID_HEX_CHARS: Final = 12
SQLITE_BUSY: Final = 5  # sqlite_errorcode & 0xFF
SQLITE_LOCKED: Final = 6

# Burst script retries
BURST_MAX_RETRIES: Final = 5
BURST_BACKOFF_SECONDS: Final = 0.1

# Names used in more than one module
SOURCES: Final = ("form", "webhook")
VERDICTS: Final = ("new", "duplicate", "review")
FOLLOWUP_STATES: Final = ("pending", "sending", "sent", "failed", "unknown")
AI_LABELS: Final = ("hot", "warm", "cold")

# Config validation
PORT_MAX: Final = 65535
ADAPTER_CHOICES: Final = ("demo",)

# HTTP layer
REQUEST_TIMEOUT_SECONDS: Final = 30.0  # socket timeout of one request handler; frees a thread held by a stalled client
DRAIN_MAX_BYTES: Final = (
    1_048_576  # unread request bytes read and dropped after an early reply, so the reply is not lost to a reset
)
EXIT_ADAPTERS_UNREACHABLE: Final = 1  # start-up cannot reach the sender (/fake/info)
MAX_DIGITS: Final = 18  # longest Content-Length or item number taken as a number; longer is over every limit
REPLY_MAX_BYTES: Final = (
    1_048_576  # an adapter reply longer than this is refused unread (the fakes answer a few hundred bytes)
)
