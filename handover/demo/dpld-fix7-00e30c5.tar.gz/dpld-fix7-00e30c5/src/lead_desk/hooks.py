"""Crash hooks. The base class is a no-op in production."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Final

from lead_desk.constants import EXIT_SIMULATED_KILL

HOOK_POINTS: Final = ("A", "A2", "B", "D1", "D2")


class Hooks:
    def crash_point(self, name: str, conn: sqlite3.Connection | None) -> None:
        """No-op. In-process tests subclass it; names are HOOK_POINTS."""
        return None


class FlagFileHooks(Hooks):
    """The ONE shared crash hook for subprocess tests and the video. Reads the one-shot flag file `flag_path`
    (content = a point name from HOOK_POINTS; the path comes from the launcher, never from here). When
    crash_point(name, conn) is called and the file names `name`: delete the file, print "simulate crash" and call
    os._exit(137). Otherwise do nothing."""

    def __init__(self, flag_path: Path) -> None:
        self.flag_path = Path(flag_path)

    def crash_point(self, name: str, conn: sqlite3.Connection | None) -> None:
        try:
            wanted = self.flag_path.read_text(encoding="utf-8").strip()
        except OSError:
            return
        if wanted != name:
            return
        try:
            self.flag_path.unlink()
        except OSError:
            return  # another thread took the one-shot flag first
        print("simulate crash", flush=True)
        os._exit(EXIT_SIMULATED_KILL)
