"""The importable contract: protocols and exceptions."""

from __future__ import annotations

from typing import Literal, Mapping, Protocol


class Crm(Protocol):
    def put(self, lead_id: str, record: Mapping[str, str]) -> Literal["PUT", "ALREADY_PRESENT"]:
        """Idempotent by lead_id."""
        ...


class Outbox(Protocol):
    @property
    def capability(self) -> Literal["keyed", "blind"]: ...

    def send(
        self, send_key: str, to: str, subject: str, body: str, timeout: float
    ) -> Literal["SENT", "ALREADY_SENT"]: ...


class Qualifier(Protocol):
    def qualify(self, lead_id: str, email_key: str) -> Literal["hot", "warm", "cold"]: ...


class SendRefused(Exception): ...


class SendUnreachable(Exception): ...


class SendAmbiguous(Exception): ...


class OutboxModeMismatch(SendRefused): ...


class SimulatedCrash(BaseException): ...  # BaseException on purpose: no `except Exception` may swallow it
