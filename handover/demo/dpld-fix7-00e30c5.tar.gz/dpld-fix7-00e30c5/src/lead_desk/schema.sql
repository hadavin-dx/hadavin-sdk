-- Applied by db.init_schema: WAL is set first outside any transaction; this text runs inside
-- "BEGIN IMMEDIATE; ... PRAGMA user_version=1; COMMIT;".
-- Per-connection pragmas (foreign_keys, recursive_triggers, synchronous) are set by db.connect, not here.
CREATE TABLE IF NOT EXISTS receipts (
  receipt_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL CHECK (source IN ('form','webhook')),
  source_ref TEXT NOT NULL CHECK (length(source_ref) BETWEEN 1 AND 128),
  received_at INTEGER NOT NULL,
  payload TEXT NOT NULL,                  -- canonical JSON text of the request's payload object, never changes
  attempts INTEGER NOT NULL DEFAULT 1,    -- how many times this request id arrived
  outcome TEXT CHECK (outcome IN ('new','duplicate','review')),   -- NULL = open; this is the "verdict"
  outcome_lead_id TEXT,
  outcome_reason TEXT,
  differing_fields TEXT,                  -- JSON array of field NAMES, always set with a duplicate verdict (may be '[]')
  decided_at INTEGER,
  payload_conflict INTEGER NOT NULL DEFAULT 0,   -- 1 = the request id came again with a different payload (the first answer stands)
  UNIQUE (source, source_ref)
);
CREATE TRIGGER IF NOT EXISTS receipts_immutable
  BEFORE UPDATE OF receipt_id, source, source_ref, received_at, payload ON receipts
  BEGIN SELECT RAISE(ABORT,'receipt fields never change'); END;
CREATE TRIGGER IF NOT EXISTS receipts_outcome_once
  BEFORE UPDATE OF outcome, outcome_lead_id, outcome_reason, differing_fields, decided_at ON receipts
  WHEN OLD.outcome IS NOT NULL
  BEGIN SELECT RAISE(ABORT,'a verdict is written once'); END;     -- the first write (OLD.outcome NULL) passes; one UPDATE sets all five columns
CREATE TRIGGER IF NOT EXISTS receipts_no_delete
  BEFORE DELETE ON receipts
  BEGIN SELECT RAISE(ABORT,'receipts are never deleted'); END;

CREATE TABLE IF NOT EXISTS leads (
  lead_id TEXT NOT NULL PRIMARY KEY,             -- 'L' || 12 random hex characters
  receipt_id INTEGER NOT NULL UNIQUE REFERENCES receipts(receipt_id),
  source TEXT NOT NULL,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 200),
  email TEXT NOT NULL,                    -- as typed, trimmed
  email_key TEXT NOT NULL CHECK (length(email_key) BETWEEN 3 AND 254),   -- trim + lower case
  phone TEXT, company TEXT, message TEXT, -- NULL when empty
  created_at INTEGER NOT NULL
);
-- mutation-seam: unique_email_key
CREATE UNIQUE INDEX IF NOT EXISTS leads_email_key_uq ON leads(email_key);
-- end mutation-seam
CREATE TRIGGER IF NOT EXISTS leads_no_update BEFORE UPDATE ON leads
  BEGIN SELECT RAISE(ABORT,'lead lines are write-once'); END;
CREATE TRIGGER IF NOT EXISTS leads_no_delete BEFORE DELETE ON leads
  BEGIN SELECT RAISE(ABORT,'lead lines are write-once'); END;

CREATE TABLE IF NOT EXISTS followups (
  lead_id TEXT NOT NULL PRIMARY KEY REFERENCES leads(lead_id),
  state TEXT NOT NULL CHECK (state IN ('pending','sending','sent','failed','unknown')),
  ai_label TEXT CHECK (ai_label IN ('hot','warm','cold')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  updated_at INTEGER NOT NULL,
  sent_at INTEGER,
  crm_done INTEGER NOT NULL DEFAULT 0,    -- 0 = not asked, 2 = a put was started (intent mark, written first), 1 = the CRM row was put
  auto_attempts INTEGER NOT NULL DEFAULT 0,  -- automatic tries since the last person-started Retry (cap in gate.py)
  ambiguous_prior INTEGER NOT NULL DEFAULT 0, -- 1 = an earlier send may have left (crash or unclear end): never send again blind
  send_started INTEGER NOT NULL DEFAULT 0    -- 1 = written just BEFORE outbox.send; a claim clears it; 0 on a `sending` row = nothing was sent
);
CREATE TRIGGER IF NOT EXISTS followups_sent_final BEFORE UPDATE ON followups
  WHEN OLD.state = 'sent'
  BEGIN SELECT RAISE(ABORT,'a sent follow-up is final'); END;

CREATE INDEX IF NOT EXISTS receipts_open_ix ON receipts(received_at) WHERE outcome IS NULL;
CREATE INDEX IF NOT EXISTS followups_active_ix ON followups(updated_at) WHERE state IN ('pending','sending');

DROP VIEW IF EXISTS review_items;
CREATE VIEW review_items AS      -- the static part of the "review list"; 7 columns in every branch
  SELECT 'R' || receipt_id AS item_id, 'receipt' AS item_type, 'review' AS kind, outcome_reason AS reason,
         NULL AS lead_id, received_at AS since, source
    FROM receipts WHERE outcome = 'review'
  UNION ALL
  SELECT 'D' || receipt_id, 'receipt',
         CASE WHEN outcome = 'duplicate' AND differing_fields <> '[]' THEN 'duplicate_with_new_info'
              ELSE 'replay_payload_differs' END,
         CASE WHEN outcome = 'duplicate' AND differing_fields <> '[]' THEN differing_fields
              ELSE 'same request id, different payload' END,
         outcome_lead_id, received_at, source
    FROM receipts WHERE (outcome = 'duplicate' AND differing_fields <> '[]') OR payload_conflict = 1
  UNION ALL
  SELECT 'F' || f.lead_id, 'followup', f.state, f.last_error, f.lead_id, f.updated_at, l.source
    FROM followups f JOIN leads l USING (lead_id) WHERE f.state IN ('failed','unknown');
