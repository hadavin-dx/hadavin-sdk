"""The desk API. Standard library only.

One SQLite connection per thread (threading.local); every write is BEGIN IMMEDIATE; no network call is made while a
transaction is open. Logs carry exception class names only (no addresses, no names)."""

from __future__ import annotations

import json
import logging
import secrets
import sqlite3
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypeVar, cast

from lead_desk import db, identity
from lead_desk.config import Config
from lead_desk.constants import (
    AI_LABELS,
    BUSY_WAIT_SECONDS,
    HTTP_ACCEPTED,
    HTTP_BAD_REQUEST,
    HTTP_BUSY,
    HTTP_CONFLICT,
    HTTP_CREATED,
    HTTP_INTERNAL_ERROR,
    HTTP_NOT_FOUND,
    HTTP_OK,
    LEAD_ID_HEX_CHARS,
    LEAD_ID_PREFIX,
    LOCK_RETRIES,
    MAX_DIGITS,
    SOURCE_REF_MAX,
    SOURCE_REF_MIN,
    SOURCES,
)
from lead_desk.contract import (
    Crm,
    Outbox,
    OutboxModeMismatch,
    Qualifier,
    SendRefused,
    SendUnreachable,
)
from lead_desk.gate import (
    DECIDE_FAIL_LIMIT,
    DRIVE_MAX,
    DRIVE_WAIT_SECONDS,
    GATE_WAIT_SECONDS,
    INFLIGHT_MAX,
    INFLIGHT_WAIT_SECONDS,
    OUTBOX_REFRESH_SECONDS,
    PENDING_GRACE_SECONDS,
    REAPER_INTERVAL_SECONDS,
    REAPER_PASS_SECONDS,
    REQUEST_DEADLINE_SECONDS,
    SEND_MAX_ATTEMPTS,
    SENDING_GRACE_BUSY_WAITS,
    WRITE_DEADLINE_SECONDS,
    FairSemaphore,
    GateTimeout,
    backoff_after,
    gate_for,
)
from lead_desk.hooks import Hooks

log = logging.getLogger("lead_desk")
_T = TypeVar("_T")


class _GateBusy(sqlite3.OperationalError):
    """The write gate line did not move within the wait. It is a lock answer like any other (db.is_busy is true), but
    it is NOT tried again at once: a retry would queue at the tail of the line and wait just as long again."""


class _IncompleteCheck(Exception):
    """A payload that passed identity.check_payload came back without a required field."""


# What the decision step treats as "this payload cannot be stored": it gets verdict review, never an open receipt.
_UNSTORABLE = (
    sqlite3.IntegrityError,
    sqlite3.DataError,
    OverflowError,
    RecursionError,  # a stored payload nested so deeply that json.loads gives up
    json.JSONDecodeError,
    UnicodeError,  # a lone surrogate that slipped past the checks
    _IncompleteCheck,
)
CRM_NOT_ASKED, CRM_STARTED, CRM_DONE = 0, 2, 1  # followups.crm_done values (2 = intent mark, written first)
_RETRYABLE = ("refused", "unreachable", "ambiguous")  # send results that go back to `pending` until the cap
_CLAIM_SQL = {  # the only two claims there are, as whole statements (nothing is built from text)
    ("pending",): (
        "UPDATE followups SET state='sending', attempts=attempts+1, send_started=0,"
        " auto_attempts=CASE WHEN state='failed' THEN 1 ELSE auto_attempts+1 END, updated_at=?"
        " WHERE lead_id=? AND state = 'pending'"
    ),
    ("pending", "failed"): (
        "UPDATE followups SET state='sending', attempts=attempts+1, send_started=0,"
        " auto_attempts=CASE WHEN state='failed' THEN 1 ELSE auto_attempts+1 END, updated_at=?"
        " WHERE lead_id=? AND state IN ('pending','failed')"
    ),
}

HINTS = {
    "R": "Send a corrected submission with a NEW request id.",
    "D": "Informational only, no action needed.",
    "O": "Send the same request id again, or restart the desk.",
}
HINT_INTERNAL_ERROR = (
    "The desk itself could not decide this receipt (a fault on the desk side, not in the request). A person must "
    "look at the desk log. Sending a new request id is not the fix."
)
HINT_NOT_UNKNOWN = "Only a follow-up in state unknown can be resolved."
HINT_CRM_UNCONFIRMED = (
    "The CRM may or may not hold this lead. Look in the CRM, then answer crm_present (the row is there: Retry goes "
    "straight to the email) or not_sent (the row is not there: Retry asks the CRM again). sent is refused here: no "
    "email was ever tried."
)
HINT_EMAIL_UNKNOWN = (
    "The CRM row is already done; what is unclear is the email. Look at the sender, then answer sent (it left) or "
    "not_sent (it did not). crm_present is refused here."
)
_RESOLVE_DECISIONS = ("sent", "not_sent", "crm_present")
_RECEIPT_KEYS = (
    "receipt_id",
    "source",
    "source_ref",
    "payload",
    "attempts",
    "outcome",
    "outcome_lead_id",
    "outcome_reason",
    "differing_fields",
)
_RECEIPT_BY_ID = (
    "SELECT receipt_id, source, source_ref, payload, attempts, outcome, outcome_lead_id, outcome_reason,"
    " differing_fields FROM receipts WHERE receipt_id=?"
)
_ITEM_EXISTS = {
    "R": "SELECT 1 FROM receipts WHERE receipt_id=? AND outcome = 'review'",
    "D": "SELECT 1 FROM receipts WHERE receipt_id=?"
    " AND ((outcome = 'duplicate' AND differing_fields <> '[]') OR payload_conflict = 1)",
    "O": "SELECT 1 FROM receipts WHERE receipt_id=? AND outcome IS NULL",
}
_REVIEW_SQL = """
SELECT item_id, item_type, kind, reason, lead_id, since, source FROM (
  SELECT item_id, item_type, kind, reason, lead_id, since, source FROM review_items
  UNION ALL
  SELECT 'O' || receipt_id, 'receipt', 'stalled', 'open receipt', NULL, received_at, source
    FROM receipts WHERE outcome IS NULL AND received_at < :before
  UNION ALL
  SELECT 'F' || f.lead_id, 'followup', 'stalled', f.state, f.lead_id, f.updated_at, l.source
    FROM followups f JOIN leads l USING (lead_id) WHERE f.state IN ('pending','sending') AND f.updated_at < :before
) ORDER BY since, item_id
"""
_COUNTS_SQL = """
SELECT (SELECT count(*) FROM receipts),
       (SELECT count(*) FROM receipts WHERE outcome = 'new'),
       (SELECT count(*) FROM receipts WHERE outcome = 'duplicate'),
       (SELECT count(*) FROM receipts WHERE outcome = 'review'),
       (SELECT count(*) FROM receipts WHERE outcome IS NULL),
       (SELECT count(*) FROM followups WHERE state IN ('pending','sending')),
       (SELECT count(*) FROM followups WHERE state = 'failed'),
       (SELECT count(*) FROM followups WHERE state = 'unknown'),
       (SELECT count(*) FROM followups WHERE state = 'sending')
"""


def default_now() -> int:
    return int(time.time())


@dataclass
class Reply:
    status: int
    body: Any  # exactly the rows of the HTTP table in contract.md (a dict, or a list for GET /review)
    drive_lead_id: str | None = None  # set when the caller must now run the follow-up


class Desk:
    def __init__(
        self,
        config: Config,
        crm: Crm,
        outbox: Outbox,
        qualifier: Qualifier,
        hooks: Hooks | None = None,
        now: Callable[[], int] = default_now,
        schema_sql: str | None = None,  # test-only mutation seam
    ) -> None:
        self.config = config
        self.crm = crm
        self.outbox = outbox
        self.qualifier = qualifier
        self.hooks = hooks if hooks is not None else Hooks()
        self._now = now
        self._schema_sql = schema_sql
        self._local = threading.local()
        self._rejected = 0
        self._rejected_lock = threading.Lock()
        self._inflight = FairSemaphore(INFLIGHT_MAX)
        self._drives = FairSemaphore(DRIVE_MAX)
        db_text = str(config.db_path)
        # resolved ONCE here: a later chdir cannot send a new thread's connection to another file
        self._db_path: Path | str = db_text if db_text in ("", ":memory:") else Path(db_text).resolve()
        self._gate = gate_for(self._db_path)  # one write line per lead book (not re-entrant, see gate.py)
        self._decide_failures: dict[int, int] = {}  # receipt id -> consecutive non-busy decide failures (in memory)
        self._decide_lock = threading.Lock()
        self._crm_refresh_failed = False
        self._seen_open: dict[int, int] = {}  # open receipt id -> desk time the reaper first saw it open
        self._poked: set[int] = set()  # receipts left open by a busy answer: the reaper decides them at its next pass
        self._refreshed_at: int | None = None  # clock time of the last capability read
        self._used = (
            False  # set by the first call that serves, drives, claims, retries or resolves; startup() refuses after it
        )
        self._started = threading.Event()  # set when startup() has finished its quick repairs
        self._background = False  # start_background() was called: pending follow-ups are driven by the reaper
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- plumbing
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = db.connect(self._db_path)
            self._local.conn = conn
        return cast(sqlite3.Connection, conn)

    @contextmanager
    def _write(self, conn: sqlite3.Connection) -> Iterator[None]:
        """BEGIN IMMEDIATE ... COMMIT; any exception (a simulated crash too) rolls back first. The writer first
        waits its turn in the process-wide fair gate (gate.py); a wait that runs out is the same "database is locked"
        error as an SQLite busy timeout, so every caller treats it as busy."""
        wait = GATE_WAIT_SECONDS
        for deadline in (getattr(self._local, "call_deadline", None), getattr(self._local, "req_deadline", None)):
            if deadline is not None:
                wait = min(wait, deadline - time.monotonic())
        try:
            self._gate.acquire(wait, low=bool(getattr(self._local, "low", False)))
        except GateTimeout:
            raise _GateBusy("database is locked (write gate wait ran out)") from None
        try:
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield
                conn.execute("COMMIT")
            except BaseException:
                if conn.in_transaction:
                    conn.rollback()
                raise
        finally:
            self._gate.release()

    def _locked_retry(self, fn: Callable[[], _T]) -> _T:
        """Run fn up to LOCK_RETRIES times while the database stays locked (each try already waited the busy time).
        All tries of one call share ONE deadline (WRITE_DEADLINE_SECONDS, and the request's own deadline if there is
        one). A gate wait that ran out is not tried again: the line has not moved, and a new ticket would go to its
        tail."""
        self._local.call_deadline = time.monotonic() + WRITE_DEADLINE_SECONDS
        try:
            for attempt in range(LOCK_RETRIES):
                try:
                    return fn()
                except sqlite3.OperationalError as e:
                    if not db.is_busy(e) or isinstance(e, _GateBusy) or attempt == LOCK_RETRIES - 1:
                        raise
                    if time.monotonic() >= self._local.call_deadline:
                        raise
            raise RuntimeError("unreachable")
        finally:
            self._local.call_deadline = None

    def _error_reply(self, exc: Exception, receipt_id: int | None, with_receipt: bool = True) -> Reply:
        busy = db.is_busy(exc)
        log.warning("request failed: %s", type(exc).__name__)
        body: dict[str, Any] = {"error": "busy" if busy else "internal"}
        if with_receipt:
            body["receipt_id"] = receipt_id
        return Reply(HTTP_BUSY if busy else HTTP_INTERNAL_ERROR, body)

    def close(self) -> None:
        """Closes the calling thread's connection (the next use opens a new one)."""
        conn = getattr(self._local, "conn", None)
        self._local.conn = None
        if conn is not None:
            conn.close()

    def note_rejected_envelope(self) -> None:
        with self._rejected_lock:
            self._rejected += 1

    # -- start-up
    def _refresh_outbox(self) -> bool:
        """Read the sender's capability again when the adapter can (HttpOutbox.refresh). False when it could not."""
        self._refresh_crm()
        refresh = getattr(self.outbox, "refresh", None)
        if refresh is None:
            return True
        self._refreshed_at = self._now()
        try:
            refresh()
        except Exception as e:  # the cached capability stays; sends fail visibly if the sender is really down
            log.warning("outbox capability not re-read: %s", type(e).__name__)
            return False
        return True

    def _refresh_crm(self) -> None:
        """Read the CRM's mode again when the adapter can (HttpCrm.refresh). A failure keeps the cached value."""
        refresh = getattr(self.crm, "refresh", None)
        if refresh is None:
            return
        try:
            refresh()
        except Exception as e:
            if not self._crm_refresh_failed:  # said once per change of state, not on every pass
                log.warning("crm capability not re-read: %s", type(e).__name__)
            self._crm_refresh_failed = True
            self._forget_crm_capability()
        else:
            self._crm_refresh_failed = False

    def _forget_crm_capability(self) -> None:
        """A failed re-read must not leave an old "keyed" in force: the adapter drops it (None counts as not keyed)."""
        forget = getattr(self.crm, "forget_capability", None)
        if forget is not None:
            forget()

    def _requeue_sending(self, older_than: int | None, mode_known: bool = True) -> None:
        """The `sending` rows of the transition table: keyed -> pending, blind -> unknown (a blind sender cannot say
        whether the email left). A row whose send never started (crm_done not 1, or no `send_started` mark) never
        reached the send, so it goes back to pending (or failed at the cap) whatever the sender is: the CRM rule decides
        at the next drive. Only a row whose send may have started needs the sender's mode; with mode_known False
        (the mode could not be read) the other rows are left alone.
        older_than=None: every `sending` row (start-up); else only rows not touched since that time (the reaper)."""
        keyed = self.outbox.capability == "keyed"
        conn = self._conn()
        now = self._now()

        def attempt() -> None:
            with self._write(conn):
                # a row that has used up its automatic tries is not put back for ever: keyed -> failed (a person's
                # Retry can still start it again), blind -> unknown as before
                conn.execute(
                    "UPDATE followups SET state=CASE"
                    " WHEN (crm_done <> 1 OR send_started = 0) AND auto_attempts >= ? THEN 'failed'"
                    " WHEN crm_done <> 1 OR send_started = 0 THEN 'pending'"
                    " WHEN NOT ? THEN 'unknown' WHEN auto_attempts >= ? THEN 'failed' ELSE 'pending' END,"
                    " last_error='crash_while_sending',"
                    " ambiguous_prior=CASE WHEN crm_done = 1 AND send_started = 1 THEN 1 ELSE ambiguous_prior END,"
                    " updated_at=?"
                    " WHERE state='sending' AND (? IS NULL OR updated_at <= ?)"
                    " AND (? OR crm_done <> 1 OR send_started = 0)",
                    (
                        SEND_MAX_ATTEMPTS,
                        int(keyed),
                        SEND_MAX_ATTEMPTS,
                        now,
                        older_than,
                        older_than,
                        int(mode_known),
                    ),
                )

        self._locked_retry(attempt)

    def startup(self) -> None:
        """init_schema, then the start-up sweep; call once, before the desk serves or drives anything (RuntimeError
        otherwise). Without start_background() it also drives every pending follow-up before it returns; with
        start_background() called first, that driving is left to the reaper thread so serving starts at once."""
        if self._used:
            raise RuntimeError("startup() must be called once, before the desk serves or drives anything")
        self._used = True
        conn = self._conn()
        db.init_schema(conn, self._schema_sql)
        refreshed = self._refresh_outbox()
        # (1) finish every OPEN receipt from its stored payload
        open_ids = conn.execute("SELECT receipt_id FROM receipts WHERE outcome IS NULL ORDER BY receipt_id").fetchall()
        for (rid,) in open_ids:  # fetched first: _decide commits while this loop runs
            try:
                self._decide(int(rid))
            except Exception as e:  # the receipt stays open and shows as stalled
                log.warning("sweep: receipt left open: %s", type(e).__name__)
        # (2) the two `sending` rows of the transition table
        self._requeue_sending(None, refreshed)  # rows that never reached the send need no mode
        if not refreshed:  # the sender's mode is not known: guessing could send twice, so the reaper decides once read
            log.warning("start-up: sending rows left for the reaper (sender capability not read)")
        self._started.set()
        # (3) drive every pending follow-up; run_followup catches its own errors
        if not self._background:
            for (lead_id,) in conn.execute(
                "SELECT lead_id FROM followups WHERE state='pending' ORDER BY lead_id"
            ).fetchall():
                self.run_followup(lead_id)

    # -- background reaper
    def start_background(self, interval: float = REAPER_INTERVAL_SECONDS) -> None:
        """Start the reaper thread (daemon, stoppable with stop_background). Call it BEFORE startup(): the thread
        waits for startup() to finish its quick repairs, then every `interval` seconds runs reap_once()."""
        if self._thread is not None:
            return
        self._background = True
        self._stop.clear()
        self._thread = threading.Thread(target=self._reaper_loop, args=(interval,), name="desk-reaper", daemon=True)
        self._thread.start()

    def stop_background(self, timeout: float = BUSY_WAIT_SECONDS * 2) -> None:
        """Ask the reaper to stop and wait for it (bounded)."""
        self._stop.set()
        thread, self._thread = self._thread, None
        if thread is not None:
            thread.join(timeout=timeout)

    def _reaper_loop(self, interval: float) -> None:
        self._local.low = True  # repairs queue behind requests for the write gate
        try:
            while not self._started.wait(0.05):
                if self._stop.is_set():
                    return
            while not self._stop.is_set():
                try:
                    self.reap_once()
                except Exception as e:  # never let the thread die: the next pass tries again
                    log.warning("reaper pass failed: %s", type(e).__name__)
                if self._stop.wait(interval):
                    break
        finally:
            self.close()

    def reap_once(self) -> dict[str, int]:
        """One repair pass (the reaper calls it; tests call it directly). Returns counts of what it did.
        (1) open receipts older than stall_seconds get their verdict from the stored payload;
        (2) `sending` rows older than send timeout + 3 busy waits get the start-up rule (keyed -> pending, blind ->
            unknown), after the sender's capability is read again (not done when it cannot be read). The capability is
            read again at most every OUTBOX_REFRESH_SECONDS, or at once while such a stuck row exists;
        (3) pending follow-ups that are due (fresh ones after a short grace, automatic retries after their backoff)
            are driven, as many as fit in REAPER_PASS_SECONDS of real time per pass."""
        self._used = True
        conn = self._conn()
        done = {"receipts": 0, "requeued": 0, "driven": 0, "unknown": 0}
        now = self._now()
        self._restamp_future(conn, now)
        with self._decide_lock:
            poked = sorted(self._poked)  # a busy answer left these open: they do not wait for stall_seconds
        stalled = [
            int(r[0])
            for r in conn.execute(
                "SELECT receipt_id FROM receipts WHERE outcome IS NULL AND received_at <= ? ORDER BY receipt_id",
                (now - self.config.stall_seconds,),
            ).fetchall()
        ] + self._stalled_by_own_clock(conn, now)
        for rid in sorted(set(poked) | set(stalled)):
            try:
                _, here = self._decide(int(rid))
                done["receipts"] += int(here)
            except Exception as e:
                log.warning("reaper: receipt left open: %s", type(e).__name__)
        stuck_before = now - int(self.config.send_timeout_seconds + SENDING_GRACE_BUSY_WAITS * BUSY_WAIT_SECONDS)
        n_sending = conn.execute(
            "SELECT count(*) FROM followups WHERE state='sending' AND updated_at <= ?",
            (stuck_before,),
        ).fetchone()[0]
        refreshed = True
        if n_sending or self._refreshed_at is None or now - self._refreshed_at >= OUTBOX_REFRESH_SECONDS:
            refreshed = self._refresh_outbox()  # a stuck row needs the current mode; otherwise only now and then
        if n_sending and not refreshed:
            log.warning("reaper: sending rows that may have sent left as they were (sender capability not read)")
        if n_sending:
            try:
                self._requeue_sending(stuck_before, refreshed)
                done["requeued"] = int(n_sending)
            except Exception as e:
                log.warning("reaper: sending rows left as they were: %s", type(e).__name__)
        due = []
        for lead_id, tries, updated_at, ambiguous in conn.execute(
            "SELECT lead_id, auto_attempts, updated_at, ambiguous_prior FROM followups"
            " WHERE state IN ('pending','sending') AND state='pending' ORDER BY updated_at, lead_id"
        ).fetchall():
            wait = PENDING_GRACE_SECONDS if tries == 0 else backoff_after(int(tries))
            if updated_at + wait <= now:
                due.append((str(lead_id), bool(ambiguous)))
        started = time.monotonic()  # real time, not the desk clock: the budget bounds how long THIS pass may run
        for lead_id, ambiguous_prior in due:
            if self._stop.is_set() or time.monotonic() - started >= REAPER_PASS_SECONDS:
                break  # the rest is still due and comes first in the next pass
            if ambiguous_prior and self.outbox.capability == "blind":
                self._pending_to_unknown(lead_id)  # the sender became blind: do not send again blindly
                done["unknown"] += 1
                continue
            self.run_followup(lead_id)
            done["driven"] += 1
        return done

    def _restamp_future(self, conn: sqlite3.Connection, now: int) -> None:
        """After the clock was set back, a follow-up row stamped with a later time would look "fresh" until the clock
        catches up, and recovery would wait that long. Such a stamp is set to now (it then ages normally)."""

        def attempt() -> None:
            with self._write(conn):
                conn.execute(
                    "UPDATE followups SET updated_at=? WHERE state IN ('pending','sending') AND updated_at > ?",
                    (now, now),
                )

        if conn.execute(
            "SELECT 1 FROM followups WHERE state IN ('pending','sending') AND updated_at > ? LIMIT 1", (now,)
        ).fetchone():
            try:
                self._locked_retry(attempt)
            except sqlite3.OperationalError as e:
                if not db.is_busy(e):
                    raise

    def _stalled_by_own_clock(self, conn: sqlite3.Connection, now: int) -> list[int]:
        """Open receipts stamped in the future (clock set back; the stamp cannot be changed) count their age from the
        first pass of the reaper that saw them open."""
        open_rows = conn.execute("SELECT receipt_id, received_at FROM receipts WHERE outcome IS NULL").fetchall()
        live = {int(r[0]) for r in open_rows}
        for rid in [r for r in self._seen_open if r not in live]:
            del self._seen_open[rid]
        out = []
        for rid, at in open_rows:
            first = self._seen_open.setdefault(int(rid), now)
            if at > now and first <= now - self.config.stall_seconds:
                out.append(int(rid))
        return out

    def _pending_to_unknown(self, lead_id: str) -> None:
        conn = self._conn()

        def attempt() -> None:
            with self._write(conn):
                conn.execute(
                    "UPDATE followups SET state='unknown', last_error='ambiguous_prior', updated_at=?"
                    " WHERE lead_id=? AND state='pending'",
                    (self._now(), lead_id),
                )

        try:
            self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            if not db.is_busy(e):
                raise

    # -- receipts and decisions
    def _receipt(self, conn: sqlite3.Connection, receipt_id: int) -> dict[str, Any] | None:
        row = conn.execute(_RECEIPT_BY_ID, (receipt_id,)).fetchone()
        return None if row is None else dict(zip(_RECEIPT_KEYS, row, strict=True))

    def _lookup_email_key(self, conn: sqlite3.Connection, email_key: str) -> str | None:
        """Called as self._lookup_email_key(conn, key): positional, via self, no inlining, no cached reference."""
        row = conn.execute("SELECT lead_id FROM leads WHERE email_key=?", (email_key,)).fetchone()
        return None if row is None else str(row[0])

    def _decide(self, receipt_id: int) -> tuple[dict[str, Any], bool]:
        """Transaction 2, retried while the database stays locked. Returns (receipt as stored afterwards, True when
        THIS call wrote the verdict). Safety net: a payload that passed the checks but still cannot be stored (the
        database refuses it with an integrity, value or overflow error that is not a lock) gets the verdict
        `review`, reason `internal_unstorable`, so no receipt stays open for ever."""
        try:
            result = self._locked_retry(lambda: self._decide_once(receipt_id))
        except _UNSTORABLE as e:
            log.warning("payload could not be stored: %s", type(e).__name__)
            result = self._locked_retry(lambda: self._decide_unstorable(receipt_id))
        except Exception as e:
            if db.is_busy(e):
                raise  # a lock is not the receipt's fault: it keeps being tried
            with self._decide_lock:
                failures = self._decide_failures.get(receipt_id, 0) + 1
                self._decide_failures[receipt_id] = failures
            if failures < DECIDE_FAIL_LIMIT:
                raise
            # the same plain error again and again: a person must look, and the reaper must stop trying
            log.warning(
                "receipt %d: decision failed %d times (%s): verdict review", receipt_id, failures, type(e).__name__
            )
            result = self._locked_retry(lambda: self._decide_unstorable(receipt_id, "internal_error"))
        with self._decide_lock:
            self._decide_failures.pop(receipt_id, None)
            self._poked.discard(receipt_id)
        return result

    def _decide_unstorable(self, receipt_id: int, reason: str = "internal_unstorable") -> tuple[dict[str, Any], bool]:
        conn = self._conn()
        with self._write(conn):
            rec = self._receipt(conn, receipt_id)
            if rec is None:
                raise LookupError("receipt vanished")
            if rec["outcome"] is not None:
                return rec, False
            conn.execute(
                "UPDATE receipts SET outcome='review', outcome_reason=?, decided_at=? WHERE receipt_id=?",
                (reason, self._now(), receipt_id),
            )
        stored = self._receipt(conn, receipt_id)
        if stored is None:
            raise LookupError("receipt vanished")
        return stored, True

    def _decide_once(self, receipt_id: int) -> tuple[dict[str, Any], bool]:
        conn = self._conn()
        with self._write(conn):
            rec = self._receipt(conn, receipt_id)
            if rec is None:
                raise LookupError("receipt vanished")
            if rec["outcome"] is not None:  # another request or a restart finished it: nothing to write
                return rec, False
            now = self._now()
            chk = identity.check_payload(json.loads(rec["payload"]))
            if chk.kind == "review":
                conn.execute(
                    "UPDATE receipts SET outcome='review', outcome_reason=?, decided_at=? WHERE receipt_id=?",
                    (chk.reason, now, receipt_id),
                )
            else:
                if chk.email_key is None or chk.email is None or chk.name is None:
                    raise _IncompleteCheck("checked payload is incomplete")
                existing = self._lookup_email_key(conn, chk.email_key)
                if existing is not None:
                    row = conn.execute(
                        "SELECT name, phone, company, message FROM leads WHERE lead_id=?", (existing,)
                    ).fetchone()
                    stored = dict(zip(("name", "phone", "company", "message"), row, strict=True))
                    diff = identity.diff_fields(
                        stored, {"name": chk.name, "phone": chk.phone, "company": chk.company, "message": chk.message}
                    )
                    conn.execute(
                        "UPDATE receipts SET outcome='duplicate', outcome_lead_id=?, differing_fields=?, decided_at=?"
                        " WHERE receipt_id=?",
                        (existing, json.dumps(diff), now, receipt_id),
                    )
                else:
                    lead_id = LEAD_ID_PREFIX + secrets.token_hex(LEAD_ID_HEX_CHARS // 2)
                    conn.execute(
                        "INSERT INTO leads(lead_id, receipt_id, source, name, email, email_key, phone, company,"
                        " message, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (lead_id, receipt_id, rec["source"], chk.name, chk.email, chk.email_key, chk.phone,
                         chk.company, chk.message, now),
                    )  # fmt: skip
                    conn.execute(
                        "INSERT INTO followups(lead_id, state, ai_label, attempts, last_error, updated_at, sent_at)"
                        " VALUES(?, 'pending', NULL, 0, NULL, ?, NULL)",
                        (lead_id, now),
                    )
                    conn.execute(
                        "UPDATE receipts SET outcome='new', outcome_lead_id=?, decided_at=? WHERE receipt_id=?",
                        (lead_id, now, receipt_id),
                    )
            self.hooks.crash_point("A2", conn)
        stored_rec = self._receipt(conn, receipt_id)
        if stored_rec is None:
            raise LookupError("receipt vanished")
        return stored_rec, True

    def _verdict_reply(self, rec: dict[str, Any], replayed: bool, payload_matches: bool | None) -> Reply:
        body: dict[str, Any] = {"receipt_id": rec["receipt_id"]}
        outcome = rec["outcome"]
        drive: str | None = None
        if outcome == "new":
            status = HTTP_CREATED
            body.update(verdict="new", lead_id=rec["outcome_lead_id"])
            if not replayed:
                drive = rec["outcome_lead_id"]
            elif self._pending_and_due(rec["outcome_lead_id"]):
                drive = rec["outcome_lead_id"]  # a replay of `new` drives a pending follow-up, but only once it is due
        elif outcome == "duplicate":
            status = HTTP_OK
            body.update(
                verdict="duplicate",
                lead_id=rec["outcome_lead_id"],
                differing_fields=json.loads(rec["differing_fields"]),
            )
        else:
            status = HTTP_ACCEPTED
            body.update(verdict="review", reason=rec["outcome_reason"])
        body["replayed"] = replayed
        if replayed:
            body["payload_matches"] = payload_matches
        return Reply(status, body, drive)

    @staticmethod
    def _envelope_ok(source: object, source_ref: object) -> bool:
        """The envelope rules the desk itself keeps (server.py checks the same before it calls process): a known
        source, a source_ref of 1 to 128 characters with no control character (NUL included) and no lone surrogate."""
        return (
            source in SOURCES
            and isinstance(source_ref, str)
            and SOURCE_REF_MIN <= len(source_ref) <= SOURCE_REF_MAX
            and not identity.has_control_char(source_ref)
            and identity.encodable(source_ref)
        )

    def process(self, source: str, source_ref: str, payload: object) -> Reply:
        """Receipt and decision (envelope already checked); decision only; never raises (503/500 are Replies).

        A bad envelope (source_ref with a control character or outside 1..128 characters, unknown source) is
        answered 400 bad_envelope with receipt_id null and no receipt. At most INFLIGHT_MAX calls run at once; one
        that finds no place within INFLIGHT_WAIT_SECONDS is answered 503 busy with receipt_id null BEFORE any receipt
        is written, so the client can safely send it again.

        Crash-point placement (crash_point(name, conn); each hook is one-shot: it fires once, then clears):
        "A"  right after transaction 1 commits (conn = that connection, no transaction open). It fires ONLY when
             THIS call created the receipt row; a replay that finds an existing receipt (open or with a verdict)
             never fires "A".
        "A2" in transaction 2 after all writes and before COMMIT (conn has the open transaction).
        "B"  at the end of process, after transaction 2 commits and before the Reply is returned (conn = that
             connection). It fires ONLY when THIS call committed transaction 2; a replay that finds a stored
             verdict never fires "B".
        process never claims a follow-up (it makes no `_claim` call); it only creates the follow-up in `pending`
        inside transaction 2."""
        self._used = True
        if not self._envelope_ok(source, source_ref):
            self.note_rejected_envelope()
            return Reply(HTTP_BAD_REQUEST, {"error": "bad_envelope", "receipt_id": None})
        self._local.req_deadline = time.monotonic() + REQUEST_DEADLINE_SECONDS  # ONE deadline for this whole request
        try:
            if not self._inflight.acquire(timeout=INFLIGHT_WAIT_SECONDS):
                return Reply(HTTP_BUSY, {"error": "busy", "receipt_id": None})
            try:
                return self._process(source, source_ref, payload)
            finally:
                self._inflight.release()
        finally:
            self._local.req_deadline = None

    def _process(self, source: str, source_ref: str, payload: object) -> Reply:
        rid: int | None = None
        try:
            conn = self._conn()
            try:
                canon = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
            except (RecursionError, TypeError, ValueError, OverflowError):
                # nested so deeply, or holding something JSON cannot write (a set, a date, mixed-type keys, a 4301-digit
                # number): not a request the desk can store, the same answer as the server's
                self.note_rejected_envelope()
                return Reply(HTTP_BAD_REQUEST, {"error": "bad_envelope", "receipt_id": None})

            def receive() -> tuple[int, bool]:
                with self._write(conn):  # transaction 1: the receipt, before anything else happens
                    conn.execute(
                        "INSERT INTO receipts(source, source_ref, received_at, payload) VALUES(?,?,?,?)"
                        " ON CONFLICT(source, source_ref) DO UPDATE SET attempts = attempts + 1",
                        (source, source_ref, self._now(), canon),
                    )
                    found = conn.execute(
                        "SELECT receipt_id, attempts FROM receipts WHERE source=? AND source_ref=?",
                        (source, source_ref),
                    ).fetchone()
                    return int(found[0]), found[1] == 1  # (receipt id, this call created the row)

            rid, created = self._locked_retry(receive)
            rec = self._receipt(conn, rid)
            if rec is None:
                raise LookupError("receipt vanished")
            matches = rec["payload"] == canon
            if created:
                self.hooks.crash_point("A", conn)
            elif not matches:
                self._note_payload_conflict(rid)
            if rec["outcome"] is not None:
                return self._verdict_reply(rec, True, matches)
            rec, decided_here = self._decide(rid)
            if not decided_here:
                return self._verdict_reply(rec, True, matches)
            self.hooks.crash_point("B", conn)
            return self._verdict_reply(rec, False, None)
        except Exception as e:
            if rid is not None and db.is_busy(e):
                with (
                    self._decide_lock
                ):  # the 503 is final for this client, but the receipt must not wait for stall_seconds
                    self._poked.add(rid)
            return self._error_reply(e, rid)

    def _note_payload_conflict(self, receipt_id: int) -> None:
        """A request id came again with a different payload: the first answer stands, but the difference must not
        vanish. Marks the receipt so the review list shows an informational D item that names it."""
        conn = self._conn()

        def attempt() -> None:
            with self._write(conn):
                conn.execute("UPDATE receipts SET payload_conflict=1 WHERE receipt_id=?", (receipt_id,))

        try:
            self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            if not db.is_busy(e):
                raise
            log.warning("payload conflict not recorded: database stayed locked")

    # -- follow-up
    def _followup_state(self, lead_id: str) -> str | None:
        row = self._conn().execute("SELECT state FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
        return None if row is None else str(row[0])

    def _pending_and_due(self, lead_id: str) -> bool:
        """True for a `pending` follow-up that may be driven now: one with no automatic try yet (its first drive), or
        one whose backoff after the last try is over. A client that sends the same request again and again therefore
        cannot burn the try cap: after the first drive each further replay waits for the backoff."""
        row = (
            self._conn()
            .execute("SELECT state, auto_attempts, updated_at FROM followups WHERE lead_id=?", (lead_id,))
            .fetchone()
        )
        if row is None or row[0] != "pending":
            return False
        return bool(row[1] == 0 or row[2] + backoff_after(int(row[1])) <= self._now())

    def _label_step(self, lead_id: str) -> str:
        """Follow-up step 1: the AI label, asked for once; the label stored first wins. No CRM call here."""
        conn = self._conn()
        row = conn.execute(
            "SELECT l.email_key, f.ai_label FROM leads l JOIN followups f USING (lead_id) WHERE l.lead_id=?",
            (lead_id,),
        ).fetchone()
        if row is None:
            raise LookupError("no such lead")
        email_key, label = row
        if label is None:
            label = self.qualifier.qualify(lead_id, email_key)
            if label not in AI_LABELS:  # None or anything else would reach the CRM as text and leave the label empty
                raise ValueError("the AI step answered no valid label")

            def store() -> None:
                with self._write(conn):
                    conn.execute(
                        "UPDATE followups SET ai_label=? WHERE lead_id=? AND ai_label IS NULL", (label, lead_id)
                    )

            self._locked_retry(store)
            label = conn.execute("SELECT ai_label FROM followups WHERE lead_id=?", (lead_id,)).fetchone()[0]
            if label not in AI_LABELS:
                raise LookupError("label not stored")
        return str(label)

    def _crm_step(self, lead_id: str, token: int) -> bool:
        """Follow-up step 2, run ONLY by the thread that won the claim: the CRM row, once per lead. Returns True when
        the follow-up may go on to the send, False when this call already recorded the result (or lost the claim).

        `crm_done` is an intent mark: 0 = not asked, 2 = a put was started (written BEFORE the put), 1 = the put
        came back. A leftover 2 means a put may have reached the CRM without the desk learning it. A CRM that says it
        is keyed (an attribute `capability == "keyed"`) is simply asked again, which is harmless. Any other CRM (no
        such attribute counts as not keyed: the desk cannot know) must not be asked again, so the follow-up goes to
        `unknown` / `crm_unconfirmed` and a person looks. A put that fails in a way that proves nothing was stored
        (the exception has `nothing_stored` true) resets the mark to 0; any other failure of a not-keyed CRM is just
        as unclear as a leftover 2 and also ends `unknown`."""
        conn = self._conn()
        row = conn.execute(
            "SELECT l.name, l.email, l.company, l.source, f.ai_label, f.crm_done"
            " FROM leads l JOIN followups f USING (lead_id) WHERE l.lead_id=?",
            (lead_id,),
        ).fetchone()
        if row is None:
            raise LookupError("no such lead")
        name, email, company, source, label, crm_done = row
        if crm_done == CRM_DONE:
            return True
        if crm_done == CRM_STARTED:
            self._refresh_crm()  # a CRM restarted in another mode must not be judged by an old answer
        keyed = getattr(self.crm, "capability", None) == "keyed"
        if crm_done == CRM_STARTED and not keyed:
            self._record_send_result(lead_id, "unknown", token, "crm_unconfirmed")
            return False
        if label is None:
            label = self._label_step(lead_id)
        if not self._mark_crm(
            lead_id, CRM_STARTED, token
        ):  # also moves updated_at, so the reaper counts from this stage
            log.warning("crm step: the follow-up is no longer ours, nothing was asked")
            return False
        try:
            self.crm.put(
                lead_id,
                {
                    "lead_id": lead_id,
                    "name": name,
                    "email": email,
                    "company": company or "",
                    "source": source,
                    "ai_label": label,
                },
            )
        except Exception as e:
            if getattr(e, "nothing_stored", False):
                self._mark_crm(
                    lead_id, CRM_NOT_ASKED, token, best_effort=True
                )  # a failed write leaves 2: the safe side
                raise
            if keyed:
                raise  # asking again is harmless; the mark stays 2
            log.warning("crm put ended unclear on a CRM that is not keyed: %s", type(e).__name__)
            self._record_send_result(lead_id, "unknown", token, "crm_unconfirmed")
            return False
        try:
            return self._mark_crm(lead_id, CRM_DONE, token)  # retried; False = no longer ours
        except sqlite3.OperationalError as e:
            if not db.is_busy(e):
                raise
            # the put came back but the mark cannot be written: do NOT go on to the send. The row stays `sending`;
            # the reaper puts it back flagged ambiguous_prior and the leftover 2 is judged on the next drive.
            log.warning("crm_done=1 not recorded: database stayed locked; row left for the reaper")
            return False

    def _mark_crm(self, lead_id: str, value: int, token: int, best_effort: bool = False) -> bool:
        """Write crm_done=value for the row this thread claimed: state `sending` AND attempts equal to the claim's
        `token` (the attempts value the claim wrote), so a drive that stalled and was put back cannot write into a
        later drive's claim. A lock that stays held raises, except for the best-effort reset to 0 after a proven
        failed put (the leftover 2 is then judged on the next drive). Returns False when the row is no longer ours."""
        conn = self._conn()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET crm_done=?, updated_at=? WHERE state='sending' AND lead_id=? AND attempts=?",
                    (value, self._now(), lead_id, token),
                ).rowcount

        try:
            return self._locked_retry(attempt) == 1
        except sqlite3.OperationalError as e:
            if best_effort and db.is_busy(e):
                log.warning("crm_done=%d not recorded: database stayed locked", value)
                return True
            raise

    def _touch(self, lead_id: str, token: int, send_started: bool = False) -> bool:
        """Move updated_at of the claimed row (state `sending`, attempts == token) to now, so the reaper's stuck-time
        counts from the last stage. With send_started the same UPDATE also writes the intent mark `send_started=1`
        (BEFORE outbox.send). False when the row is no longer ours (put back, or claimed again) or when the lock stayed
        held: a write that could not be made is not ours to rely on, and the send must not go on without its mark."""
        conn = self._conn()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET updated_at=?, send_started=CASE WHEN ? THEN 1 ELSE send_started END"
                    " WHERE state='sending' AND lead_id=? AND attempts=?",
                    (self._now(), int(send_started), lead_id, token),
                ).rowcount

        try:
            return self._locked_retry(attempt) == 1
        except sqlite3.OperationalError as e:
            if not db.is_busy(e):
                raise
            log.warning("sending row not refreshed: database stayed locked")
            return False

    def run_followup(self, lead_id: str) -> None:
        """Follow-up steps 1-5 for one lead, as a fresh drive: step 1 (the label), then the claim (step 3) as
        `self._claim(None, lead_id, ("pending",))` (an automatic driver never takes a `failed` row) and, only if the
        claim returned True, steps 2, 4 and 5 (`_after_claim`: the CRM row once, then `_send_claimed`). A lost claim
        (False) returns quietly. Catches Exception, logs the class name only; an exception in step 1 counts as one
        automatic try (`_defer_pending`: back to waiting with a backoff, `failed` only at the cap), except a database
        that stayed locked: the follow-up then stays pending and the reaper drives it later. A follow-up that is not
        `pending` is left alone (nothing to drive). D1 and D2 live in `_send_claimed`."""
        self._used = True
        # With the reaper running, a drive that finds no place leaves its row to the reaper. Without a reaper nobody
        # else would drive it, so it waits for a place (every place is held by a drive that ends on its own timeouts).
        if not self._drives.acquire(timeout=DRIVE_WAIT_SECONDS if self._background else None):
            log.warning("follow-up not driven now: all drive places are taken; the reaper drives it later")
            return
        was_low = bool(getattr(self._local, "low", False))
        self._local.low = True  # a drive queues behind requests for the write gate, so it cannot starve them
        try:
            self._run_followup(lead_id)
        finally:
            self._local.low = was_low
            self._drives.release()

    def _run_followup(self, lead_id: str) -> None:
        try:
            state0 = (
                self._conn()
                .execute("SELECT state, auto_attempts FROM followups WHERE lead_id=?", (lead_id,))
                .fetchone()
            )
            if state0 is None or state0[0] != "pending":
                return
            try:
                self._label_step(lead_id)
            except Exception as e:
                log.warning("follow-up step 1 failed: %s", type(e).__name__)
                if not db.is_busy(e):
                    self._defer_pending(lead_id, f"internal:{type(e).__name__}", int(state0[1]))
                return
            if self._claim(None, lead_id, ("pending",)):
                self._after_claim(lead_id, auto=True)
        except Exception as e:
            log.warning("follow-up failed: %s", type(e).__name__)

    def _after_claim(self, lead_id: str, auto: bool) -> None:
        """Steps 2, 4 and 5 for a follow-up this thread has just claimed. An exception in step 1 or 2 (the AI step
        or the CRM was down, or answered something odd) means nothing was sent: it counts as one automatic try, the
        row goes back to `pending` (`internal:<class>`) and `failed` only at the cap, so Retry stays possible."""
        token = self._take_token(lead_id)
        try:
            if not self._touch(lead_id, token):  # BEFORE the AI step, which can be slow: the reaper counts from here
                log.warning("follow-up skipped: it is no longer ours")
                return
            self._label_step(lead_id)
            if not self._crm_step(lead_id, token):
                return
        except Exception as e:
            log.warning("follow-up steps 1-2 failed after the claim: %s", type(e).__name__)
            self._abort_unsent(lead_id, token, e)
            return
        self._send_claimed(lead_id, auto, token)

    def _abort_unsent(self, lead_id: str, token: int, exc: Exception) -> None:
        """Nothing was sent. A database that stayed locked is not the follow-up's fault: the try is given back and the
        row goes to `pending` if the write can be made now (else it stays `sending` and the reaper puts it back);
        nothing is recorded as an error. Any other error is one used-up automatic try (`internal:<class>`)."""
        if not db.is_busy(exc):
            self._record_send_result(lead_id, self._pending_or_failed(lead_id), token, f"internal:{type(exc).__name__}")
            return
        conn = self._conn()
        try:
            with self._write(conn):
                conn.execute(
                    "UPDATE followups SET state='pending', auto_attempts=MAX(auto_attempts-1, 0), updated_at=?"
                    " WHERE state='sending' AND lead_id=? AND attempts=? AND send_started=0",
                    (self._now(), lead_id, token),
                )
        except sqlite3.OperationalError as e:
            if not db.is_busy(e):
                raise
            log.warning("claim not given back: database stayed locked; the reaper puts the row back")

    def handle(self, source: str, source_ref: str, payload: object) -> Reply:
        """process, then run_followup if reply.drive_lead_id is set (tests use this)."""
        reply = self.process(source, source_ref, payload)
        if reply.drive_lead_id is not None:
            self.run_followup(reply.drive_lead_id)
        return reply

    def _claim(
        self, conn_or_none: sqlite3.Connection | None, lead_id: str, from_states: tuple[str, ...] = ("pending",)
    ) -> bool:
        """Owns its transaction; the UPDATE of step 3; True when exactly one row changed. Never leaves a
        transaction open. A lock that stays held through LOCK_RETRIES tries gives False (the item stays pending and
        shows as stalled). `from_states` is ("pending",) for every automatic driver (run_followup, the reaper, the
        start-up sweep) and ("pending", "failed") only for a person's Retry: an automatic driver can never take a
        `failed` row, so it can never start the automatic-try count again. Claiming a `failed` row starts the count
        again at 1 (this try); claiming a `pending` row counts one more automatic try."""
        self._used = True
        sql = _CLAIM_SQL.get(tuple(from_states))
        if sql is None:
            raise ValueError("a claim takes ('pending',) or ('pending', 'failed')")
        conn = self._conn() if conn_or_none is None else conn_or_none

        def attempt() -> bool:
            self._local.token = None
            with self._write(conn):
                if conn.execute(sql, (self._now(), lead_id)).rowcount != 1:
                    return False
                got = conn.execute("SELECT attempts FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
                self._local.token = (lead_id, int(got[0]))  # the ownership token: this claim's attempts value
                return True

        try:
            return self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            self._local.token = None  # a COMMIT that failed after the token was set must not leave it behind
            if db.is_busy(e):
                log.warning("claim gave up: database stayed locked")
                return False
            raise
        except BaseException:
            self._local.token = None
            raise

    def _take_token(self, lead_id: str) -> int:
        """The attempts value THIS thread's last claim of `lead_id` wrote (read in the claim's own transaction). If
        none is recorded (a replaced _claim in a test), the current value is read: no protection, but no crash."""
        held = getattr(self._local, "token", None)
        self._local.token = None
        if held is not None and held[0] == lead_id:
            return int(held[1])
        row = self._conn().execute("SELECT attempts FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
        return 0 if row is None else int(row[0])

    def _auto_attempts(self, lead_id: str) -> int:
        row = self._conn().execute("SELECT auto_attempts FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
        return 0 if row is None else int(row[0])

    def _pending_or_failed(self, lead_id: str) -> Literal["pending", "failed"]:
        """`pending` (wait, try again) while fewer than SEND_MAX_ATTEMPTS automatic tries were made, else `failed`."""
        return "pending" if self._auto_attempts(lead_id) < SEND_MAX_ATTEMPTS else "failed"

    def _send_claimed(self, lead_id: str, auto: bool, token: int) -> None:
        """Follow-up steps 4-5 for a follow-up this thread has just claimed (state `sending`). Private; calls no claim.
        Crash points (conn=None for both; one-shot): "D1" after the claim committed and before outbox.send;
        "D2" after outbox.send returns and before the result is recorded. Send uses send_key=lead_id.

        Results: a reply that came with the wrong mode is `unknown`. A refusal, an unreachable sender, or (keyed
        sender only, where sending again is safe) an unclear end puts the row back to `pending` with the error until
        SEND_MAX_ATTEMPTS automatic tries were made, then `failed`; the reaper tries again after a backoff (gate.py).
        An unclear end on a blind sender is `unknown` at once (the email may have left; a person decides). A row
        flagged `ambiguous_prior` (an earlier send may have left) is never sent blind: if the sender is blind now it
        becomes `unknown`. A person's Retry also runs with auto=True (its count starts again at the claim)."""
        self.hooks.crash_point("D1", None)
        state: Literal["sent", "failed", "unknown", "pending"]
        err: str | None = None
        try:
            row = (
                self._conn()
                .execute(
                    "SELECT l.name, l.email, f.ambiguous_prior FROM leads l JOIN followups f USING (lead_id)"
                    " WHERE l.lead_id=?",
                    (lead_id,),
                )
                .fetchone()
            )
            name, email, ambiguous_prior = row
            if ambiguous_prior:
                # the sender may have been restarted in the other mode since the cached read; an earlier send may have
                # left, so a mode that could not be read is not good enough to send again
                if not self._refresh_outbox():
                    self._record_send_result(lead_id, self._pending_or_failed(lead_id), token, "unreachable")
                    return
                if self.outbox.capability == "blind":
                    self._record_send_result(lead_id, "unknown", token, "ambiguous_prior")
                    return
            # the intent mark goes in BEFORE the send: a row without it never sent anything
            if not self._touch(lead_id, token, send_started=True):  # not ours (taken back, or the mark was not written)
                log.warning("send skipped: the follow-up is no longer ours")
                return
        except Exception as e:  # before the send: nothing left
            log.warning("follow-up failed before the send: %s", type(e).__name__)
            self._abort_unsent(lead_id, token, e)
            return
        try:
            self.outbox.send(
                lead_id,
                email,
                f"Thanks for getting in touch, {name}",
                f"Hi {name}, we received your message. (FAKE EMAIL)",
                self.config.send_timeout_seconds,
            )
            state = "sent"
        except OutboxModeMismatch:
            state, err = "unknown", "mode_mismatch"  # the sender answered 2xx: the email is stored, in the wrong mode
            self._refresh_outbox()  # the sender's mode changed: read it now, not at the next 30 s mark
        except SendRefused:
            state, err = "failed", "refused"
        except SendUnreachable:
            state, err = "failed", "unreachable"
        except Exception as e:  # SendAmbiguous or anything unexpected: the email may have left
            log.warning("send ended unclear: %s", type(e).__name__)
            err = "ambiguous"
            state = "failed" if self.outbox.capability == "keyed" else "unknown"
        if auto and state == "failed" and err in _RETRYABLE:
            state = self._pending_or_failed(lead_id)
        self.hooks.crash_point("D2", None)
        self._record_send_result(lead_id, state, token, err, ambiguous=err == "ambiguous")

    def _defer_pending(self, lead_id: str, last_error: str, token: int) -> None:
        """Internal writer for a `pending` row whose step 1 failed (nothing was sent): one more automatic try is
        used up, the row stays `pending` (the reaper tries again after a backoff) and becomes `failed` only when the
        cap is reached: UPDATE ... WHERE lead_id=? AND state='pending' AND auto_attempts=<token>
        (the automatic-try count read when this drive started, so a second drive that also failed step 1 cannot add
        a second try); a row count of 0 is logged and ignored."""
        conn = self._conn()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET auto_attempts=auto_attempts+1, last_error=?, updated_at=?,"
                    " state=CASE WHEN auto_attempts+1 >= ? THEN 'failed' ELSE 'pending' END"
                    " WHERE lead_id=? AND state='pending' AND auto_attempts=?",
                    (last_error, self._now(), SEND_MAX_ATTEMPTS, lead_id, token),
                ).rowcount

        self._finish_update(attempt, "defer_pending")

    def _record_send_result(
        self,
        lead_id: str,
        state: Literal["sent", "failed", "unknown", "pending"],
        token: int,
        last_error: str | None = None,
        ambiguous: bool = False,
    ) -> None:
        """Internal (not part of the HTTP or test API). Follow-up step 5 for the claimed row ONLY: UPDATE ...
        WHERE lead_id=? AND attempts=<token> AND state='sending'; a row count of 0 (put back, or claimed again by
        another drive) is logged and ignored. A `sent` result clears
        last_error and sets sent_at. `ambiguous` marks the row `ambiguous_prior` (an email may have left)."""
        conn = self._conn()
        now = self._now()

        def attempt() -> int:
            with self._write(conn):
                return conn.execute(
                    "UPDATE followups SET state=?, last_error=?, updated_at=?, sent_at=?,"
                    " ambiguous_prior=CASE WHEN ? THEN 1 ELSE ambiguous_prior END"
                    " WHERE lead_id=? AND attempts=? AND state='sending'",
                    (
                        state,
                        None if state == "sent" else last_error,
                        now,
                        now if state == "sent" else None,
                        int(ambiguous),
                        lead_id,
                        token,
                    ),
                ).rowcount

        self._finish_update(attempt, "record_send_result")

    def _finish_update(self, attempt: Callable[[], int], what: str) -> None:
        try:
            changed = self._locked_retry(attempt)
        except sqlite3.OperationalError as e:
            if db.is_busy(e):
                log.warning("%s: database stayed locked; the row stays as it was and shows as stalled", what)
                return
            raise
        if changed != 1:
            log.warning("%s: expected one row, changed %d", what, changed)

    # -- review items, retry, resolve
    def _find_item(self, item_id: str) -> str | None:
        """'F', 'R', 'D' or 'O' when the item exists, else None (also for a malformed id)."""
        if not item_id[1:] or item_id[0] not in "FRDO":
            return None
        kind, ref = item_id[0], item_id[1:]
        if not identity.encodable(ref) or identity.has_control_char(ref):
            return None
        conn = self._conn()
        if kind == "F":
            found = conn.execute("SELECT 1 FROM followups WHERE lead_id=?", (ref,)).fetchone()
        elif not (ref.isascii() and ref.isdecimal()) or len(ref) > MAX_DIGITS or ref[0] == "0":
            # not a number, one no receipt id can reach (also keeps int() clear of its digit limit), or written with
            # a leading zero (R0012 would be the same item as R12: every item has exactly one id)
            return None
        else:
            found = conn.execute(_ITEM_EXISTS[kind], (int(ref),)).fetchone()
        return kind if found else None

    def _not_actionable(self, kind: str, item_id: str = "") -> Reply:
        hint = HINTS[kind]
        if kind == "R" and item_id[1:].isdecimal():
            row = self._conn().execute("SELECT outcome_reason FROM receipts WHERE receipt_id=?", (int(item_id[1:]),))
            found = row.fetchone()
            if found is not None and found[0] == "internal_error":
                hint = HINT_INTERNAL_ERROR
        return Reply(HTTP_CONFLICT, {"error": "not_actionable", "hint": hint})

    def retry(self, item_id: str) -> Reply:
        """Check order: item id grammar and existence (404), then the 409 rows of contract.md. Reads no state
        first. For an F item it makes its OWN claim `self._claim(None, lead_id)` (state IN
        ('pending','failed')), and if that returns True it runs `_after_claim` (steps 1-2, then the send). It answers
        409 in_progress, never 200, when the row is still `sending` afterwards. It does NOT call
        run_followup and run_followup does not call it. If the claim returns False it re-reads the state to
        choose the 409 code. An exception in steps 1-2 after the claim records `failed` / `internal:<class>`
        (nothing was sent, so Retry stays possible)."""
        self._used = True
        try:
            kind = self._find_item(item_id)
            if kind is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if kind != "F":
                return self._not_actionable(kind, item_id)
            lead_id = item_id[1:]
            if self._claim(None, lead_id, ("pending", "failed")):  # a failed row: the automatic count starts again
                self._after_claim(lead_id, auto=True)  # a Retry gets a fresh automatic count
                state_now = self._followup_state(lead_id)
                if state_now == "sending":  # the result could not be recorded: never answer 200 with `sending`
                    return Reply(HTTP_CONFLICT, {"error": "in_progress"})
                return Reply(HTTP_OK, {"item_id": item_id, "state": state_now})
            state = self._followup_state(lead_id)
            code = {"sending": "in_progress", "unknown": "unknown_needs_person", "sent": "not_retryable"}.get(
                str(state)
            )
            if state is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if code is None:  # pending or failed, yet the claim failed: the database stayed locked
                return Reply(HTTP_BUSY, {"error": "busy"})
            return Reply(HTTP_CONFLICT, {"error": code})
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    def resolve(self, item_id: str, decision: str) -> Reply:
        """Check order is frozen (contract.md, "Resolve check order", numbered paragraphs 2 to 5; paragraph 1 is
        the server). Here, in this order: (1) item id grammar and existence -> 404; (2) R, D or O item -> 409
        not_actionable (decision not looked at); (3) decision not in {"sent", "not_sent", "crm_present"} -> 400
        bad_decision;
        (4) F item whose state is not `unknown` -> 409 not_unknown; an unknown item that this answer does not fit
        (crm_present for a row that is not `crm_unconfirmed`, or sent for one that is) -> 409 wrong_decision.
        `crm_present` (only for last_error crm_unconfirmed) sets crm_done=1 and state `failed`, so Retry goes
        straight to the email. `not_sent` also clears the marks `ambiguous_prior`
        and a leftover `crm_done=2`, so a Retry afterwards is not stopped by them again."""
        self._used = True
        try:
            kind = self._find_item(item_id)
            if kind is None:
                return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
            if kind != "F":
                return self._not_actionable(kind, item_id)
            if decision not in _RESOLVE_DECISIONS:
                return Reply(HTTP_BAD_REQUEST, {"error": "bad_decision"})
            lead_id = item_id[1:]
            new_state, note = {
                "sent": ("sent", "person: sent"),
                "not_sent": ("failed", "person: not sent"),
                "crm_present": ("failed", "person: crm row present"),
            }[decision]
            undo = int(decision == "not_sent")  # the person looked and decided nothing went out: forget both marks
            present = int(decision == "crm_present")  # the person saw the CRM row: the CRM step is done
            conn = self._conn()
            now = self._now()
            # crm_present fits only a row whose CRM step is open (crm_done 2: a put may have reached the CRM);
            # sent fits only a row whose CRM step is finished (crm_done 1: only then did an email attempt follow)
            as_sent = int(decision == "sent")

            def attempt() -> int:
                with self._write(conn):
                    return conn.execute(
                        "UPDATE followups SET state=?, last_error=?, updated_at=?, sent_at=?,"
                        " ambiguous_prior=CASE WHEN ? THEN 0 ELSE ambiguous_prior END,"
                        " crm_done=CASE WHEN ? AND crm_done=2 AND last_error IS 'crm_unconfirmed' THEN 0"
                        " WHEN ? THEN 1 ELSE crm_done END"
                        " WHERE lead_id=? AND state='unknown'"
                        " AND (? = 0 OR crm_done = 2)"
                        " AND (? = 0 OR crm_done = 1)",
                        (
                            new_state,
                            note,
                            now,
                            now if new_state == "sent" else None,
                            undo,
                            undo,
                            present,
                            lead_id,
                            present,
                            as_sent,
                        ),
                    ).rowcount

            if self._locked_retry(attempt) != 1:
                row = conn.execute("SELECT state, crm_done FROM followups WHERE lead_id=?", (lead_id,)).fetchone()
                if row is not None and row[0] == "unknown":  # the row waits, but not for this answer
                    hint = HINT_CRM_UNCONFIRMED if row[1] in (CRM_NOT_ASKED, CRM_STARTED) else HINT_EMAIL_UNKNOWN
                    return Reply(HTTP_CONFLICT, {"error": "wrong_decision", "hint": hint})
                return Reply(HTTP_CONFLICT, {"error": "not_unknown", "hint": HINT_NOT_UNKNOWN})
            return Reply(HTTP_OK, {"item_id": item_id, "state": new_state})
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    # -- reads
    def review(self) -> Reply:
        try:
            return self._review()
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    def _review(self) -> Reply:
        before = self._now() - self.config.stall_seconds
        rows = self._conn().execute(_REVIEW_SQL, {"before": before}).fetchall()
        keys = ("item_id", "item_type", "kind", "reason", "lead_id", "since", "source")
        items = [dict(zip(keys, r, strict=True)) for r in rows]
        for item in items:  # a hint only where the person needs one (keeps the item shape of the other rows)
            if item["kind"] == "unknown" and item["reason"] == "crm_unconfirmed":
                item["hint"] = HINT_CRM_UNCONFIRMED + " not_sent: an extra CRM row may need deleting by hand."
            elif item["item_type"] == "receipt" and item["reason"] == "internal_error":
                item["hint"] = HINT_INTERNAL_ERROR
        return Reply(HTTP_OK, items)

    def lead(self, lead_id: str) -> Reply:
        try:
            return self._lead(lead_id)
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    def _lead(self, lead_id: str) -> Reply:
        conn = self._conn()
        if not identity.encodable(lead_id) or identity.has_control_char(lead_id):
            return Reply(HTTP_NOT_FOUND, {"error": "not_found"})  # no lead id can contain such text
        row = conn.execute(
            "SELECT l.lead_id, l.receipt_id, l.source, l.name, l.email, l.phone, l.company, l.message, l.created_at,"
            " f.state, ai_label, f.attempts, f.last_error, f.sent_at"
            " FROM leads l JOIN followups f USING (lead_id) WHERE l.lead_id=?",
            (lead_id,),
        ).fetchone()
        if row is None:
            return Reply(HTTP_NOT_FOUND, {"error": "not_found"})
        lead_keys = ("lead_id", "receipt_id", "source", "name", "email", "phone", "company", "message", "created_at")
        fu_keys = ("state", "ai_label", "attempts", "last_error", "sent_at")
        nl = len(lead_keys)
        return Reply(
            HTTP_OK,
            {
                "lead": dict(zip(lead_keys, row[:nl], strict=True)),
                "followup": dict(zip(fu_keys, row[nl:], strict=True)),
            },
        )

    def counts(self, expected: int | None) -> Reply:
        """expected=None when the query has no `expected`; server.py answers 400 bad_expected for a bad value."""
        try:
            return self._counts(expected)
        except Exception as e:
            return self._error_reply(e, None, with_receipt=False)

    def _counts(self, expected: int | None) -> Reply:
        received, new, dup, review, open_, pending, failed, unknown, sending = (
            self._conn().execute(_COUNTS_SQL).fetchone()
        )
        with self._rejected_lock:
            rejected = self._rejected
        match = None if expected is None else received == expected
        ok = (
            None
            if expected is None
            else (open_ == 0 and rejected == 0 and match is True and pending == 0 and failed == 0 and unknown == 0)
        )
        return Reply(
            HTTP_OK,
            {
                "received": received,
                "new": new,
                "duplicate": dup,
                "review": review,
                "open": open_,
                "rejected_envelopes": rejected,
                "pending_followups": pending,
                "failed_followups": failed,
                "unknown_followups": unknown,
                "sending_followups": sending,
                "expected_match": match,
                "ok": ok,
            },
        )
