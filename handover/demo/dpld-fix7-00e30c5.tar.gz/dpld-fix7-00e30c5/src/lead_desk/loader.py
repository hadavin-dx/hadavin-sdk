"""The ONLY file in src/ that may name demo_only."""

from __future__ import annotations

import importlib
from pathlib import Path

from lead_desk.adapters import HttpCrm, HttpOutbox
from lead_desk.config import Config
from lead_desk.contract import Crm, Outbox, Qualifier


def load_demo_adapters(config: Config) -> tuple[Crm, Outbox, Qualifier]:
    """Build HttpCrm and HttpOutbox on config.fakes_url and a RecordedQualifier on config.replies_path
    (None = the replies.json that sits next to the demo_only package). HttpOutbox raises FakesUnreachable when
    /fake/info cannot be read; the Qualifier raises when the replies file is missing or broken."""
    fakes = importlib.import_module("demo_only.fakes")  # dynamic: src is type-checked without the demo folder
    replies = config.replies_path or Path(str(fakes.__file__)).resolve().parent / "replies.json"
    crm = HttpCrm(config.fakes_url, config.send_timeout_seconds)
    outbox = HttpOutbox(config.fakes_url, config.send_timeout_seconds)
    qualifier: Qualifier = fakes.RecordedQualifier(replies)
    return crm, outbox, qualifier
