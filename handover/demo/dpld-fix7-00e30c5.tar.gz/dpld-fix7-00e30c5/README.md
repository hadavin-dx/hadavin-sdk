# duplicate-proof-lead-desk

This demo asks one question: when the same sales lead arrives twice, in parallel, or around a crash, does the customer get
exactly one follow-up email and exactly one CRM record? We tried it first with n8n alone, then with a small program in
front of the database (the "desk"). All of it ran against fake systems on one laptop, with made-up data.

Who wrote this: the author directed an AI agent that wrote most of the code and ran the n8n measurements. A person has not
re-run the n8n measurements. Every number below comes from that one laptop; treat it as that and nothing more.

## Words used here

* **Lead**: a person who asked to be contacted. **Same lead** means the same email address, trimmed of spaces and lower-cased, nothing more.
* **CRM**: the customer-record system where a lead is stored as a row. **Fake CRM, fake outbox**: small programs in `demo_only/`
  that only count what arrives; every number below comes from them. **Follow-up**: the one email (plus one CRM row) sent for a new lead.
* **n8n**: a workflow tool where steps are drawn as boxes and joined with lines. **Webhook**: a web address that starts a workflow
  when something is posted to it. **Retry On Fail**: an n8n box setting that repeats a step that failed.
* **n8n's built-in remote control**: the web interface n8n offers to other programs (its REST interface). Where this README says "called through
  n8n's built-in remote control", a program pressed the button's equivalent; the on-screen button itself was not pressed.
* **Request id**: a label the sender puts on each submission (`submission_id`, `message_id`). Sending the same label twice means "this is a repeat".
* **Desk**: the small program in `src/lead_desk` that receives each request. **Lead book**: the desk's SQLite database file. **Receipt**: the
  desk's first note about a request, written before anything else happens.
* **Verdict**: the desk's answer is `new` (first time this email is seen), `duplicate` (this email was seen before, under another request id) or `review` (the lead is incomplete and a person must look). A request the desk refuses (bad or too large) gets an error status instead of a verdict.
  **Replayed**: the same request id was sent again, so the desk returned its stored answer and changed nothing.
* **HTTP status**: the number a web server sends back (200 means answered, 400 bad request, 413 too large, 500 server error).
* **Keyed mail system**: a mail system that recognises a repeat of the same send key. **Blind mail system**: one that does not.
* **UNKNOWN**: the follow-up may or may not have been sent; the desk will not guess and will not resend; a person checks.
* **Crash points** A, A2, B, D1, D2: five named moments in the desk's work where the test stops it on purpose (see `contract.md`).
* **K1, K2, K3** (the n8n kill tests): n8n is killed abruptly, like a power cut, at one of three moments. The n8n steps ran in this
  order: "have I seen this lead" check, then the CRM request, then the email request. **K3**: killed while the CRM request is in flight
  (we slow the fake CRM by 3 seconds so the kill can land in that gap; in real life the gap is milliseconds), before the email request is sent.
  **K1**: killed while the email request is in flight (the fake outbox waits 3 seconds before storing). **K2**: killed after the fake outbox stored the email but before it answered.
* **Code checkers** used in the repository: ruff (style), mypy (types), bandit and CodeQL (known insecure patterns), gitleaks (secrets and
  other leaked values). **Postgres**: a database server. **Docker**: a way to run programs in isolated containers.

## What we found, in short

* n8n with a database insert (variant (b) below) gave one email and one CRM row in all 20 ten-at-once runs of our test. Two other n8n
  patterns did too (c and d), and one (the Remove Duplicates node on default settings) did not (2 of 20 runs let duplicates through).
* If n8n is killed between the CRM request and the email request (K3), the lead is in the CRM but the email is never sent. n8n lists the
  crashed run, and its retry, called through its built-in remote control, reported success but sent no email. In these tests that happened in every one of the 80 K3 runs.
* The desk writes each request down first, so after its own crash there is one email, or the follow-up is listed as UNKNOWN for a person to check.
* "Duplicate-proof" means the promises in the table below, for this fake setup. It is not a guarantee for any real CRM or mail system.

## Not claimed

* "Never silently lost" and "never sent twice" in general. Exactly-once delivery, production fitness, demand, any customer result, a legal opinion.
  The licence text has not been reviewed by a lawyer.
* The same person with two email addresses is two leads: `ada+sales@example.test` and `a.da@example.test` are different leads.
  Two people sharing one address are one lead.
* A real mail system or CRM was not tested. The keyed mail system is a simulation; a real provider may remember a send key for a
  shorter or longer time. The AI step is a recorded fake; nothing is said about real AI behaviour.
* The desk assumes the follow-up is the only thing that sends mail for a lead's send key.
* A crash is simulated inside the program for all five crash points, and a real process kill was done only for point D2. Power loss was not tested.
* Loads of 10,000 requests were not run, and none of the burst figures in "Load and limits" were measured on a second Windows machine. The desk is for one laptop and one process. There is no login; it listens on this computer only.
* Mostly run on one system: Windows with Python 3.13 (see "What has been run").
* n8n crashing before the request reaches the desk. Other n8n versions or set-ups: the n8n measurements are one pattern, one laptop, made-up data, measured by an AI agent.
* A person answering "not sent" wrongly for an UNKNOWN follow-up on a mail system that cannot recognise repeats (then a second email can go).
  UNKNOWN items stay unseen unless someone opens the review list.
* A follow-up stuck in `sending` because the database stayed locked through all retries is repaired only by restarting the desk.
* No penetration test of the desk was done.

This is a demo with made-up data and fake systems only. No real customer data, no secrets and no live model calls are used.

## Load and limits

* Burst test: many connections open at the same moment, all for the same lead (the same email under different request ids). A run on Linux (not this machine) with 10 and with 100 simultaneous connections lost nothing. With 500 and with 1000, the desk as it was then (a waiting line of 64 connections) never received 147 of 500 and 424 of 1000: the connections were reset before the desk read them. A sender that does not retry loses those requests. The desk's own counts matched what it received.
* The waiting line is now 1024 connections (`LISTEN_QUEUE` in `src/lead_desk/constants.py`); the operating system may allow fewer. On the Windows machine used here (Python 3.13, one desk process, fake mail system and CRM) the measured results of the new version were: 150 at once, all answered (3 of 3 runs); 300 at once, a plain stand-alone web server on this machine had 3 to 99 connections refused by the operating system itself in 10 of 13 runs, which no setting of the desk changes, so the desk test for 300 passes only because its sender retries a refused connection with the same request id; 500 at once, 6 of 7 runs fully answered and 1 run had 296 refused; 1000 at once, 5 of 7 runs fully answered and 2 runs had 438 and 56 refused. So beyond about 150 simultaneous connections on this machine a sender that cannot retry may see "connection refused" for part of the burst, and nothing in the desk records it, because the desk never saw it.
* Of the connections the desk did receive in the 500 and 1000 bursts, some were answered 503 `busy` (database lock wait over; measured 4 to 93 of 500 and 231 of 1000). A 503 means the request may have left an open receipt; send the same request id again. The desk answered every received connection with JSON, and in these bursts never sent more than one email for the lead.
* A request body shorter than the Content-Length it announced: the desk answers 408 after the handler's socket timeout (30 seconds) if the sender keeps the connection open, or 400 if the sender closes it; both are counted as rejected. A Content-Length over the size cap, however long the number, is answered 413 straight away. Two different Content-Length values in one request are answered 400. A request target that cannot be parsed is answered 400.

## What each promise rests on

There are 35 test functions (45 test cases when the parametrised ones are expanded): 21 desk tests, 7 hygiene tests, 2 mutation guards and 5 edge-case tests.
Result column: from the runs described under "What has been run".

| # | Promise, in plain words | Tests | Result |
|---|---|---|---|
| P1 | (a) A second submission with a different request id and the same email is recorded as a duplicate with the NAMES of the fields that differ; no second CRM row, no second email. (b) The same request id sent again gets the original answer marked `replayed` and changes nothing. | (a) `test_cross_source_dupe`, `test_dupe_diff_first_untouched`, `test_write_once_triggers`; (b) `test_replay_same_source_ref`, `test_concurrent_same_source_ref` | passed |
| P2 | A duplicate never reaches the AI step: the fake AI's call counter does not go up for it. | `test_dedupe_before_ai` | passed |
| P3 | A submission with no name, no email, an invalid email or a wrongly typed field goes to the review list with a reason and gets no follow-up. | `test_incomplete_to_review` | passed |
| P4 | Stopped at each of the five named points and restarted, in both mail-system modes: one lead line, and in the keyed mode exactly one email. Blind mode: points A, A2, B one email; D1 no email and an UNKNOWN flag; D2 one email and an UNKNOWN flag. Those are the tested cases (five points, two modes); the stop is simulated inside the program, and the one real process kill is at D2. Exception: a wrong "not sent" answer by a person can cause a second email on a blind system. | `test_crash_resume_each_point` (5 points, keyed and blind), `test_crash_d2_subprocess` (a real process kill) | passed |
| P5 | Ten requests with different request ids and the same email, fired at once straight at the desk by a script: one new lead, nine duplicates, one email; the counts match the number the script says it sent. A 100-request run was not run. | `test_ten_parallel`, `test_reconcile_counts` | passed |
| P6 | On a blind mail system, a send that may or may not have happened is marked UNKNOWN, listed for a person and never resent by the desk; Retry is refused for it. Retry pressed twice at once on a failed follow-up gives one email, also on a blind system. | `test_unknown_blind`, `test_failed_retry`, `test_retry_twice_concurrent` | passed |

The promises P1 to P6 are about the desk. What n8n did is reported separately below. Also tested, not a headline promise: odd input and
requests (`tests/test_hardening.py`: half-character escapes, deeply nested JSON, `HEAD`, `OPTIONS` and malformed requests get a JSON
answer, an email that grows when lower-cased, two drives of one new lead at once).

"Mutation check": two protections are removed one at a time, on the test side only, and the named test must fail with the named symptom.
`test_mutant_no_unique_key` removes the database rule that two leads cannot share an email and the lookup; the duplicate test must fail
with "leads == 1" and "got 2". `test_mutant_no_claim` removes the check that only one retry may take a follow-up; the retry test must fail
with "emails == 1" and "got 2". This shows the tests notice these two faults; it is not proof that the code is correct.

## What has been run

* **Windows, Python 3.13.3, 2026-11-09, on the author's laptop (an AI agent ran the commands):** ruff check, ruff format check, mypy (Windows and Linux settings), bandit,
  the schema self-check and the full test suite. The full suite was run several times at different points while the code was being fixed;
  the final runs, on the state described here, passed every test case except `test_hygiene_wordlist`, which needs a private word list that is
  not published (it fails on purpose instead of skipping, and was run separately with the list in place). gitleaks 8.30.1 ran on this computer
  inside `test_hygiene_scan_public`, on the tracked files and the history.
* Earlier, on a state before the last round of fixes: the four concurrency tests (`test_concurrent_same_source_ref`,
  `test_retry_twice_concurrent`, `test_ten_parallel`, `test_reconcile_counts`) were repeated 10 times each on Windows and passed every time,
  and the full suite was run in a Linux container (`python:3.12-slim`, Python 3.12.16) where 35 of 37 test cases passed (the two failures:
  no `git` program in that container image for the hygiene scan, and the private word list).
* The raw logs of the n8n measurements are not published here; only the summary tables below are. The raw outputs of the local runs are kept by the author.
* **Run scripts:** `start_all.ps1`, `feed.py` and `reset.ps1` were run end to end on Windows by an independent trial (a second AI agent following this
  README as a stranger). `start_all.sh` and `reset.sh` were run in a Linux container (from sources with LF line endings). **Never run:** anything on
  macOS, `video_crash.py` outside the tests' own crash run, the checks in `.github/workflows/` on GitHub's own runners (see the repository's
  Actions tab for what GitHub itself reports), and any video.
  `SECURITY.md` asks for private reporting; that GitHub setting has to be switched on by the author.

## What we measured with n8n alone (and how)

Before building the desk, we measured whether n8n alone does the job. Method: n8n 2.46.6 on Node 24.22.2 (`versions.md`), regular mode, one
process, on one laptop; a script sent ten requests at once (different request ids, one email address, a new address per run) to
an n8n webhook; fake CRM and fake outbox servers counted what arrived (blind counting, no deduplication on their side; started with
`--crm blind --outbox blind`). The pass rule was written down (and its checksum recorded) before the counts were read.
20 runs per variant for the ten-at-once test, 5 runs per kill point. These runs were done by an AI agent; a person has not repeated them. No video of them exists.

Table: n8n 2.46.6, Node 24.22.2.

| n8n variant | Ten at once, 20 runs, exactly 1 email and 1 CRM row each | Same ten again 5 s later, with new request ids | Killed during the email request (K1, K2), 5 runs each |
|---|---|---|---|
| (a) Remove Duplicates node, default settings | NO: 18 runs gave 1 and 1; one run gave 3 and 3, one gave 8 and 8 | added nothing | one K1 run ended with 4 and 4 (already 4 before the kill) |
| (b) a database refuses a second row with the same email | 20 of 20 | added nothing | 1 and 1 at most |
| (c) a Data Table upsert plus a check on its created/updated times | 20 of 20 | added nothing | 1 and 1 at most |
| (d) same as (a) with n8n told to run one request at a time | 20 of 20 (the requests never overlapped, by design) | added nothing | 1 and 1 at most |

* **Variant (a), n8n's Remove Duplicates node with default settings, let duplicates through in 2 of 20 runs.** Do not use it that way.
* The "same ten again" column used NEW request ids with the same email, so what stopped the second submission was the email check, not the request id.
  Sending the same request id twice through n8n (the case P1(b) covers for the desk) was NOT tested in n8n.
* **K3** (killed while the CRM request is in flight, before the email request): in all 20 runs of all four variants the result was 1 CRM row
  and 0 emails: the lead is in the CRM but never got its email. n8n's executions list showed the crashed run. n8n's retry, called through
  its built-in remote control (not the on-screen button), showed "success" and sent no email. A person must notice.
* In variants (a) to (d) a duplicate caller receives an error reply (HTTP 500 "No item to return was found"), so a real workflow needs a
  branch that answers "duplicate" cleanly. Variant (e) answered 200 to its callers. Whether n8n's own list calls an errored run "success" was not checked.
* **(e) A fix inside n8n: a status column plus a scheduled re-send job**, measured on a blind mail system, 5 runs per kill point, n8n 2.46.6.
  In these 15 runs no lead was lost. But a second email went out in 10 of the 15 crash runs: all 10 runs killed while the email request was in flight or
  just after the email was stored, and none of the 5 runs killed later, while the CRM request was in flight. In 2 of the 5 runs at each of those two
  first points there was also a second CRM row (two re-send runs overlapped; the cause is probable, not verified). The re-send job was a first
  try and is untuned: it runs every 15 seconds, takes no "claim" on a row before sending, and has no limit on overlapping runs. A better-built
  n8n pattern was not tested. Also not tested: a keyed mail system, n8n's retry button, the case where n8n dies before the email request
  leaves n8n (in these runs the fake mail server had already received the first email), other intervals, queue mode. In this variant the
  steps ran in a different order (email, then status update, then CRM), so the K1, K2, K3 names above do not apply to it.
* "One email" in this section means "in these tests"; it is not a claim of exactly-once delivery. We tested the simplest patterns only.
  The Postgres and Docker versions used for variant (b) were not recorded.

n8n's licence (Sustainable Use License) allows running it locally for our own demo; it is not shipped in this repository.

## What happens with the desk behind n8n (checked on 2026-11-09 with real n8n workflows)

The three workflows in `n8n/` (`desk-form`, `desk-webhook`, `proof`) were built in n8n 2.46.6 through its built-in remote control and run
against the desk and the fake servers by the AI agent. The step-by-step recipe is `docs/n8n-recipe.md`. Findings, in plain words:

* **n8n answers 200 whenever the desk answered**, even when the desk said 201 (new) or 202 (review). The verdict (`new`, `duplicate`,
  `review`) is only in the reply body, so a caller must read the body, not the status number.
* **A desk refusal shows as an n8n error.** If the desk answers 400 (bad request) or 413 (too large), the caller gets HTTP 500 from n8n
  (`Error in workflow`). Because the sending box has Retry On Fail on (3 tries, 1 second apart), n8n repeats such a refused request 3 times, so the
  desk counts each refused call 3 times (2 refused calls were counted as 6). The workflow files were not changed for this.
* **Restart tolerance is short, about 2 seconds.** With the desk restarted at once, the second try succeeded (1 lead, 1 CRM row, 1 email, twice). With the desk down for 3 seconds,
  all three tries were used up in about 2 seconds and the call failed with 500. For longer outages raise the number of tries or the wait.
* **Ten at once through the `proof` workflow:** 1 email and 1 CRM row, in each of three runs; the desk stored all ten
  requests within the same second (the stored time has a resolution of one second, so this shows "together", not milliseconds).
* The workflows import with placeholder node ids and must be switched on by hand (the import call ignores the `active` flag).
* **Not checked here:** importing through the n8n screen ("Import from file"); the K3 scene with the desk in place; running the workflows
  without the free registered n8n community licence the author activated; n8n in Docker; keyed mail mode with n8n; other n8n versions;
  millisecond overlap of the ten requests.

## What the checks do not cover

The scan for hardcoded literals is a safety net, not a guarantee. Read changes by eye for: compressed IPv6 addresses (for example `fe80::1`),
host names that end in a word not in the scan's list, UNC paths (`\\server\share`), and bare port numbers. Numbers and ports are NOT checked by that
scan; they live in `src/lead_desk/config.py` and `src/lead_desk/constants.py`. Base64-encoded private words are not covered by the word-list check.

## Run it (made-up data, fakes only)

You may download and run this on your own computer for evaluation and testing, as the Licence section below says; nothing else is allowed.
Python 3.12 or newer is needed; the desk uses the standard library only. The tests need the development tools, installed from a lock file
into a virtual environment (a private folder of Python packages) so that nothing else on your computer changes. The desk listens on port 8765
and the fake CRM and outbox on port 8766, both on this computer only; `start_all` prints them.

Windows PowerShell (Python 3.13 matches the lock file; from the repository root):

    python -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install --require-hashes -r requirements-dev-win.txt     # only needed for the tests
    powershell -NoProfile -File scripts\start_all.ps1 keyed                # or: blind. Starts the fake servers and the desk
    $env:PYTHONPATH = "src"
    python scriptseed.py --source form --index 1       # a web-form lead: verdict new
    python scriptseed.py --source form --index 1       # the same request id again: replayed true, nothing changes
    python scriptseed.py --source webhook --index 1    # the same person through the email door: verdict duplicate
    Invoke-WebRequest http://127.0.0.1:8765/counts | Select-Object -ExpandProperty Content   # received 2, new 1, duplicate 1
    Invoke-WebRequest http://127.0.0.1:8766/fake/outbox | Select-Object -ExpandProperty Content   # 1 email
    Invoke-WebRequest http://127.0.0.1:8766/fake/crm | Select-Object -ExpandProperty Content      # 1 CRM row
    powershell -NoProfile -File scripts
eset.ps1        # stops what start_all started and deletes the lead book

Linux and macOS (Python 3.12 matches the lock file; from the repository root):

    python3 -m venv .venv && . .venv/bin/activate
    python -m pip install --require-hashes -r requirements-dev.txt         # only needed for the tests
    scripts/start_all.sh keyed          # or: blind   (logs go under ./data)
    export PYTHONPATH=src
    python scripts/feed.py --source form --index 1
    python scripts/feed.py --source form --index 1
    python scripts/feed.py --source webhook --index 1
    curl http://127.0.0.1:8765/counts ; curl http://127.0.0.1:8766/fake/outbox ; curl http://127.0.0.1:8766/fake/crm
    scripts/reset.sh                    # stops what start_all started and deletes the lead book
    python -m pytest -q                 # the tests

**Is it running?** The desk answers 404 `{"error":"not_found"}` for `/` and `/health` on purpose: it has no such pages. `/counts` is the check: if it
answers 200 with numbers, the desk is up. If it times out or is refused, look at `data/desk.err.log`, run the reset script and start again.
The first send of a request id answers 201 with verdict `new`; the same id again also answers 201 with `"replayed": true` and changes nothing.

The desk alone: `PYTHONPATH=src python -m lead_desk.server`. The crash scene: `PYTHONPATH=src python scripts/video_crash.py`, then write
a point name (for example `D2`) into the flag file it prints, and the next time the desk reaches that point it ends at once.
On Windows set `PYTHONPATH` with `;` between entries when two are needed (`src;.`). The tests set the path for their own processes.

The checks defined in `.github/workflows/lint.yml`: ruff, mypy, bandit, a schema check, gitleaks on the files and the history, a scan for
hardcoded addresses, links, absolute paths, e-mail addresses and long tokens, and all tests except `test_hygiene_wordlist`, which needs a
private word list that is never published and is run only on the author's computer. `.env` files are never used: the demo needs no secrets.

## Settings

Every setting has a default in `Config` (`src/lead_desk/config.py`) and an environment variable. A bad value stops the start with an error.

| Setting | Environment variable | Default | Meaning |
|---|---|---|---|
| `db_path` | `DESK_DB_PATH` | `./data/desk.sqlite3` | the lead book |
| `bind` | `DESK_BIND` | `127.0.0.1` | address the desk listens on (this computer only; there is no login) |
| `port` | `DESK_PORT` | `8765` | desk port (0 = pick a free one, used by tests) |
| `adapters` | `DESK_ADAPTERS` | `demo` | which sender, CRM and AI step to use; only the fake ones exist here |
| `fakes_host`, `fakes_port` | `DESK_FAKES_HOST`, `DESK_FAKES_PORT` | `127.0.0.1`, `8766` | where the fake CRM and outbox listen |
| (both above) | `DESK_FAKES_URL` | built from the two above | one `http` address with host and port; wins over the two above |
| `replies_path` | `DESK_REPLIES_PATH` | none (the loader uses the `replies.json` inside `demo_only/`) | the recorded AI replies |
| `send_timeout_seconds` | `DESK_SEND_TIMEOUT_SECONDS` | `5.0` | wait per network step, also for the CRM call |
| `size_cap_bytes` | `DESK_SIZE_CAP_BYTES` | `65536` | largest request body accepted (larger gets 413) |
| `stall_seconds` | `DESK_STALL_SECONDS` | `120` | after this long an unfinished item shows as `stalled` on the review list |

Fixed in code, not settings: SQLite busy wait, listen queue length and lock retries (`constants.py`).

## Layout

`src/lead_desk` the desk. `demo_only/` everything that exists only for demos and tests (fake servers, recorded AI replies, burst script,
canned leads); the desk reaches it only through `src/lead_desk/loader.py`. `tests/` the tests. `scripts/` run and demo helpers.
`n8n/` the three n8n workflows. `docs/n8n-recipe.md` the n8n side. `contract.md` the exact HTTP replies and rules the code and tests must agree on.
`versions.md` tool versions and licences.

## Licence

Copyright (c) 2026 Veera Rakesh Kethari (Hadavin). All rights reserved, with one grant: anyone may download and run this software on their
own computer, for evaluation and testing only. Not allowed: copying or handing it on, changing it, commercial use, or offering it as a service
or to third parties. No warranty. The author may record and publish demo videos. The full text is in `LICENSE`; it has not been reviewed by a lawyer.
The author does not accept outside contributions (pull requests). See `SECURITY.md` to report a problem.
