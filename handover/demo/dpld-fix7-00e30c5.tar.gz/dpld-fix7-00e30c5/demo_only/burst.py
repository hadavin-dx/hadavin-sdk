"""Burst script (described in contract.md, paragraph "Burst script"). Demo-only code.
Run: python -m demo_only.burst --url http://127.0.0.1:8765/leads --n 10 --email ada@example.test
     --ref-prefix run1 --source form [--expect N] [--wrap-n8n]
Output: SENT n=10 / STATUS 201=1 200=9 / RETRIES busy503=0 refused=0 / RESULT sent=10 expected=10 (or MISMATCH ...)."""

from __future__ import annotations

import argparse
import json
import threading
import time
import urllib.error
import urllib.request
from collections import Counter

from lead_desk.constants import (
    BURST_BACKOFF_SECONDS,
    BURST_MAX_RETRIES,
    HTTP_ACCEPTED,
    HTTP_BUSY,
    HTTP_CREATED,
    HTTP_OK,
    SOURCES,
)

REQUEST_TIMEOUT_SECONDS = 60.0
NAME = "Ada Example"


def build_body(source: str, ref: str, email: str, wrap_n8n: bool) -> bytes:
    """The desk envelope, or (wrap_n8n) the n8n input shape."""
    if not wrap_n8n:
        payload = {"name": NAME, "email": email, "phone": "555 0100", "message": "Please call me."}
        return json.dumps({"source": source, "source_ref": ref, "payload": payload}).encode()
    if source == "form":
        form = {"submission_id": ref, "name": NAME, "email": email, "phone": "555 0100", "message": "Please call me."}
        return json.dumps(form).encode()
    hook = {"message_id": ref, "from_name": NAME, "from_email": email, "subject": "Quote", "body": "Please call me."}
    return json.dumps(hook).encode()


def _post_once(url: str, body: bytes) -> int | str:
    req = urllib.request.Request(url, body, {"Content-Type": "application/json"})  # noqa: S310 (url from the caller)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=REQUEST_TIMEOUT_SECONDS) as r:  # noqa: S310
            return int(r.status)
    except urllib.error.HTTPError as e:
        return int(e.code)
    except urllib.error.URLError as e:
        return "refused" if isinstance(e.reason, ConnectionRefusedError) else type(e.reason).__name__
    except OSError as e:
        return type(e).__name__


def fire(url: str, n: int, email: str, ref_prefix: str, source: str, wrap_n8n: bool = False) -> dict[str, object]:
    """n requests at the same moment (start barrier). A 503 or a refused connect is retried up to
    BURST_MAX_RETRIES times with BURST_BACKOFF_SECONDS back-off. Returns final statuses and retry counts."""
    barrier = threading.Barrier(n)
    final: list[int | str] = []
    stats = {"busy503": 0, "refused": 0}
    lock = threading.Lock()

    def one(i: int) -> None:
        body = build_body(source, f"{ref_prefix}-{i}", email, wrap_n8n)
        barrier.wait()
        for attempt in range(BURST_MAX_RETRIES + 1):
            res = _post_once(url, body)
            retryable = res == HTTP_BUSY or res == "refused"
            if retryable:
                with lock:
                    stats["busy503" if res == HTTP_BUSY else "refused"] += 1
            if not retryable or attempt == BURST_MAX_RETRIES:
                break
            time.sleep(BURST_BACKOFF_SECONDS)
        with lock:
            final.append(res)

    threads = [threading.Thread(target=one, args=(i,)) for i in range(1, n + 1)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return {"n": n, "final": final, **stats}


def main(argv: list[str] | None = None) -> int:
    """Post n requests, print SENT / STATUS / RETRIES / RESULT lines, return the exit code."""
    ap = argparse.ArgumentParser(prog="demo_only.burst")
    ap.add_argument("--url", required=True)
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--email", required=True)
    ap.add_argument("--ref-prefix", required=True)
    ap.add_argument("--source", choices=SOURCES, required=True)
    ap.add_argument("--expect", type=int)
    ap.add_argument("--wrap-n8n", action="store_true")
    a = ap.parse_args(argv)
    res = fire(a.url, a.n, a.email, a.ref_prefix, a.source, a.wrap_n8n)
    final: list[int | str] = list(res["final"])  # type: ignore[call-overload]
    counts = Counter(final)
    ok_count = sum(v for k, v in counts.items() if k in (HTTP_OK, HTTP_CREATED, HTTP_ACCEPTED))
    expected = a.n if a.expect is None else a.expect
    shown = " ".join(f"{k}={v}" for k, v in sorted(counts.items(), key=lambda kv: str(kv[0]), reverse=True))
    print(f"SENT n={a.n}")
    print(f"STATUS {shown}")
    print(f"RETRIES busy503={res['busy503']} refused={res['refused']}")
    if ok_count == expected:
        print(f"RESULT sent={ok_count} expected={expected}")
        return 0
    print(f"MISMATCH sent={ok_count} expected={expected}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
