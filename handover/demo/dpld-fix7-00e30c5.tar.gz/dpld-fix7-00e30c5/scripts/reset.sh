#!/usr/bin/env bash
# Stop what start_all.sh started (only those process ids) and delete the lead book, so the next run starts empty.
# Run from the repository root. It deletes the database file, its -wal/-shm/.lock files, the logs and the pid files.
set -eu
export PYTHONPATH="src:."
db="$(python -c 'from lead_desk.config import Config; print(Config.from_env().db_path)')"
data_dir="$(dirname "$db")"
for name in desk fakes; do
  pidfile="$data_dir/$name.pid"
  if [ -e "$pidfile" ]; then
    pid="$(cat "$pidfile")"
    kill "$pid" 2>/dev/null || true
    rm -f "$pidfile"
  fi
done
sleep 1
rm -f "$db" "$db-wal" "$db-shm" "$db.lock" "$data_dir/desk.log" "$data_dir/fakes.log" "$data_dir/crash.flag"
echo "reset done"
