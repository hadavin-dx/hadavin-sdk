"""Tiny n8n REST helper: import, export, activate, delete workflows. Needs an n8n API key in a file you name.

Run from the repository root with N8N_URL (default http://127.0.0.1:5679) and N8N_API_KEY_FILE set:
  python scripts/n8n_api.py import file.json | export NAME out.json | activate NAME
  | deactivate NAME | delete NAME | list
Workflows are addressed by NAME so no id is printed. The key is read from the file, sent as a header, never printed.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from http import HTTPStatus
from pathlib import Path

BASE = os.environ.get("N8N_URL", "http://127.0.0.1:5679").rstrip("/")
KEY = Path(os.environ["N8N_API_KEY_FILE"]).read_text(encoding="utf-8").strip()
KEEP = ("name", "nodes", "connections", "settings")  # the create call refuses other top-level keys


def call(method: str, path: str, body: object = None) -> tuple[int, object]:
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(  # noqa: S310 - local n8n, http by design
        BASE + "/api/v1" + path,
        data=data,
        method=method,
        headers={"X-N8N-API-KEY": KEY, "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:  # noqa: S310
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        return e.code, raw


def find(name: str) -> str:
    _, res = call("GET", "/workflows?limit=250")
    hits = [w["id"] for w in res["data"] if w["name"] == name]  # type: ignore[index]
    if len(hits) != 1:
        raise SystemExit(f"{len(hits)} workflows named {name!r}")
    return hits[0]


def main(a: list[str]) -> int:
    cmd = a[1]
    if cmd == "list":
        _, res = call("GET", "/workflows?limit=250")
        for w in res["data"]:  # type: ignore[index]
            print(w["name"], "active" if w["active"] else "inactive")
    elif cmd == "import":
        wf = json.loads(Path(a[2]).read_text(encoding="utf-8"))
        wf.setdefault("settings", {})
        code, res = call("POST", "/workflows", {k: wf[k] for k in KEEP if k in wf})
        print(wf["name"], code, "" if code == HTTPStatus.OK else res)
        return 0 if code == HTTPStatus.OK else 1
    elif cmd == "export":
        _, res = call("GET", "/workflows/" + find(a[2]))
        Path(a[3]).write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
    elif cmd in ("activate", "deactivate"):
        code, res = call("POST", f"/workflows/{find(a[2])}/{cmd}")
        print(a[2], cmd, code, "" if code == HTTPStatus.OK else res)
        return 0 if code == HTTPStatus.OK else 1
    elif cmd == "delete":
        wid = find(a[2])
        call("POST", f"/workflows/{wid}/deactivate")  # n8n refuses to delete an active workflow (409)
        code, _ = call("DELETE", "/workflows/" + wid)
        print(a[2], "delete", code)
    else:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
