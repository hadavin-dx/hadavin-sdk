"""Glue for the hygiene tests. Rung 3 first: git grep and a regex file do the finding;
this file only (1) runs `git grep -n -o -I -E -f patterns.txt | grep -v -E -f exceptions.txt` without needing a `grep`
program on PATH, (2) holds one canary per kind of pattern, (3) builds word-list variants. No secrets, no real names."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from urllib.parse import quote

# Canaries are built from parts so this file does not itself trip the scan. Each must be reported by the pipeline.
CANARIES: dict[str, str] = {
    "ipv4": ".".join(["10", "20", "30", "40"]),
    "ipv6": ":".join(["2001", "db8", "85a3", "0", "0", "8a2e", "370", "7334"]),
    "url": "https://" + "private-host" + ".corp" + ".invalid/x",
    "hostname": "build01." + "acme-corp" + ".invalid",
    "short hostname": "svc" + "." + "ai",
    "internal hostname": "db" + "." + "internal",
    "other github link": "https://" + "github.com/" + "someone/else",
    "windows path": "C:" + "\\" + "Users" + "\\" + "someone",
    "unix path": " /home" + "/someone/x",
    "email": "someone" + "@" + "example" + ".org",
    "hex": "0123456789abcdef" * 2,
    "token": "A" + "bcdefghijklmnopqrstuvwxyz" + "0123456789ABCD",
}
# Values that must NOT be reported (the allowed cases).
ALLOWED = [
    "127.0.0.1",
    "192.0.2.7",
    "ada@" + "example.test",
    "http://localhost:8765/leads",
    "https://github.com/gitleaks/gitleaks/releases/download/v1/x.tar.gz",
    "SELECT fu.ai_label FROM t",  # a column name after a dot is not a host name (the underscore ends the word)
    "tmp.co_worker, self.us_state",
]


def read_lines(path: Path) -> list[str]:
    return [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]


def git_grep(repo: Path, patterns: Path) -> list[str]:
    """`git grep -n -o -I -E -f patterns.txt` in repo (tracked files). Exit 1 = no match = empty list."""
    p = subprocess.run(  # noqa: S603
        ["git", "grep", "-n", "-o", "-I", "-E", "-f", str(patterns)],  # noqa: S607
        cwd=repo,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if p.returncode not in (0, 1):
        raise RuntimeError(f"git grep failed ({p.returncode}): {p.stderr[-300:]}")
    return p.stdout.splitlines()


def pipeline(repo: Path, patterns: Path, exceptions: Path) -> list[str]:
    """The reported lines after `| grep -v -E -f exceptions.txt` (a line is dropped if ANY exception matches)."""
    exc = [re.compile(x) for x in read_lines(exceptions)]
    return [ln for ln in git_grep(repo, patterns) if not any(e.search(ln) for e in exc)]


def variants(term: str) -> set[str]:
    """The term and the spellings a path or URL would give: escaped backslash, forward slash, URL-encoded."""
    out = {term, term.replace("\\", "\\\\"), term.replace("\\", "/"), quote(term, safe=""), quote(term, safe="/")}
    return {v.lower() for v in out if v}
