"""Shared test helpers. Made-up data only; hosts and ports come from Config; no secrets."""

from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from demo_only.fakes import BlindOutbox, FakeCrm, KeyedOutbox, RecordedQualifier
from lead_desk.config import Config
from lead_desk.contract import SimulatedCrash
from lead_desk.desk import Desk
from lead_desk.hooks import Hooks

REPO = Path(__file__).resolve().parents[1]
WAIT_SECONDS = 15.0
HOST = Config().bind  # the one source of the loopback host for tests

LEAD = {
    "name": "Ada Example",
    "email": "Ada@Example.test",
    "phone": "555 0100",
    "company": "Example Ltd",
    "message": "Please call me.",
}


def lead(**over: Any) -> dict[str, Any]:
    """A valid payload; a keyword set to None removes that field."""
    d: dict[str, Any] = {**LEAD, **over}
    return {k: v for k, v in d.items() if v is not None}


def child_env(**extra: str) -> dict[str, str]:
    """Environment for a child process: PYTHONPATH = src and the repo root (pytest's pythonpath is not inherited)."""
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([str(REPO / "src"), str(REPO)])
    env.update(extra)
    return env


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, 0))
        return int(s.getsockname()[1])


def wait_until(fn: Callable[[], Any], timeout: float = WAIT_SECONDS, what: str = "condition") -> Any:
    """Bounded poll. Returns the first truthy value of fn(); raises AssertionError after the timeout."""
    end = time.monotonic() + timeout
    while True:
        try:
            val = fn()
        except (OSError, ValueError):
            val = None
        if val:
            return val
        if time.monotonic() > end:
            raise AssertionError(f"timed out waiting for {what}")
        time.sleep(0.05)


# -- clock and hooks
class Clock:
    def __init__(self, start: int = 1_700_000_000) -> None:
        self.t = start

    def __call__(self) -> int:
        return self.t

    def advance(self, seconds: int) -> None:
        self.t += seconds


class CrashAt(Hooks):
    """Raise SimulatedCrash once at each named point (one-shot per point). An open transaction is rolled back first,
    as a kill would."""

    def __init__(self, *points: str) -> None:
        self.points = set(points)
        self.fired: list[str] = []

    def crash_point(self, name: str, conn: sqlite3.Connection | None) -> None:
        if name in self.points and name not in self.fired:
            self.fired.append(name)
            if conn is not None and conn.in_transaction:
                conn.rollback()
            raise SimulatedCrash(name)


class BlockAt(Hooks):
    """Block once at `point` until release is set (holds a receipt open, or a follow-up in `sending`)."""

    def __init__(self, point: str) -> None:
        self.point = point
        self.reached = threading.Event()
        self.release = threading.Event()
        self._used = False

    def crash_point(self, name: str, conn: sqlite3.Connection | None) -> None:
        if name == self.point and not self._used:
            self._used = True
            self.reached.set()
            self.release.wait(timeout=WAIT_SECONDS)


# -- desk builder
@dataclass
class Rig:
    desk: Desk
    config: Config
    crm: Any
    outbox: Any
    qualifier: RecordedQualifier
    clock: Clock
    db_path: Path
    replies_path: Path
    desks: list[Desk] = field(default_factory=list)

    def query(self, sql: str, args: tuple[Any, ...] = ()) -> list[tuple[Any, ...]]:
        return rows(self.db_path, sql, args)

    def leads(self) -> int:
        return int(self.query("SELECT count(*) FROM leads")[0][0])

    def state(self, lead_id: str | None = None) -> tuple[str, str | None]:
        sql = "SELECT state, last_error FROM followups" + (" WHERE lead_id=?" if lead_id else "")  # noqa: S608
        r = self.query(sql, (lead_id,) if lead_id else ())
        assert len(r) == 1, f"expected one follow-up row, got {len(r)}"
        return r[0][0], r[0][1]

    def restart(self, hooks: Hooks | None = None) -> Desk:
        """A new Desk on the same lead book and the same fakes, then startup() (the sweep). The old one is closed."""
        try:
            self.desk.close()
        except Exception:  # noqa: BLE001, S110 (a crashed desk may fail to close; the file is what matters)
            pass
        self.desk = Desk(
            self.config, self.crm, self.outbox, self.qualifier, hooks=hooks, now=self.clock, schema_sql=None
        )
        self.desks.append(self.desk)
        self.desk.startup()
        return self.desk


def rows(db_path: Path, sql: str, args: tuple[Any, ...] = ()) -> list[tuple[Any, ...]]:
    con = sqlite3.connect(db_path, timeout=10)
    try:
        return con.execute(sql, args).fetchall()
    finally:
        con.close()


def build_rig(
    tmp_path: Path,
    outbox: str | Any = "keyed",
    hooks: Hooks | None = None,
    schema_sql: str | None = None,
    replies: dict[str, str] | None = None,
    start: bool = True,
    **config_over: Any,
) -> Rig:
    """Config on tmp_path, in-process fakes, a Desk (started unless start=False)."""
    replies_path = tmp_path / "replies.json"
    replies_path.write_text(json.dumps(replies or {}), encoding="utf-8")
    config = Config(db_path=tmp_path / "desk.sqlite3", port=0, replies_path=replies_path, **config_over)
    ob = {"keyed": KeyedOutbox, "blind": BlindOutbox}[outbox]() if isinstance(outbox, str) else outbox
    crm, qual, clock = FakeCrm(), RecordedQualifier(replies_path), Clock()
    desk = Desk(config, crm, ob, qual, hooks=hooks, now=clock, schema_sql=schema_sql)
    rig = Rig(desk, config, crm, ob, qual, clock, config.db_path, replies_path, [desk])
    if start:
        desk.startup()
    return rig


# -- HTTP helpers
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def call(base: str, method: str, path: str, body: Any = None, raw: bytes | None = None, timeout: float = 30.0) -> Any:
    """Returns (status, parsed JSON). `body` is JSON-encoded; `raw` is sent as is."""
    data = raw if raw is not None else (None if body is None else json.dumps(body).encode())
    req = urllib.request.Request(base + path, data=data, method=method)  # noqa: S310 (loopback test URL)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with _OPENER.open(req, timeout=timeout) as r:  # noqa: S310
            return r.status, json.loads(r.read().decode() or "null")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "null")


def post_lead(base: str, source: str, ref: str, payload: Any) -> tuple[int, dict[str, Any]]:
    return call(base, "POST", "/leads", {"source": source, "source_ref": ref, "payload": payload})  # type: ignore[no-any-return]


def raw_exchange(base: str, request_bytes: bytes, timeout: float = 10.0) -> tuple[int, Any]:
    """Send raw bytes on a socket, read to the end of the connection, return (status, JSON body)."""
    host, port = base.removeprefix("http://").split(":")
    with socket.create_connection((host, int(port)), timeout=timeout) as s:
        s.sendall(request_bytes)
        chunks = []
        while chunk := s.recv(65536):
            chunks.append(chunk)
    data = b"".join(chunks)
    head, _, body = data.partition(b"\r\n\r\n")
    status = int(head.split(b" ", 2)[1])
    return status, json.loads(body.decode() or "null")


def run_threads(fns: list[Callable[[], Any]]) -> list[Any]:
    """Run each fn in its own thread behind one start barrier. Returns results (or the exception object) in order."""
    barrier = threading.Barrier(len(fns))
    out: list[Any] = [None] * len(fns)

    def wrap(i: int) -> None:
        barrier.wait()
        try:
            out[i] = fns[i]()
        except BaseException as e:  # noqa: BLE001 (collected and returned to the caller)
            out[i] = e

    ts = [threading.Thread(target=wrap, args=(i,)) for i in range(len(fns))]
    for t in ts:
        t.start()
    for t in ts:
        t.join(timeout=60)
    return out


# -- a tiny stand-in sender with scripted misbehaviour (for test_error_mapping)
class StubSender:
    """Serves GET /fake/info normally; POST /fake/outbox does what `behaviour` says."""

    def __init__(self, behaviour: str, status: int = 200, body: bytes = b"{}") -> None:
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
                return None

            def _json(self, status_: int, raw: bytes) -> None:
                self.send_response(status_)
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self) -> None:
                self._json(200, json.dumps({"outbox_capability": "keyed", "mode": "keyed"}).encode())

            def do_POST(self) -> None:
                n = int(self.headers.get("Content-Length") or 0)
                self.rfile.read(n)
                if outer.behaviour == "status":
                    return self._json(outer.status, outer.body)
                if outer.behaviour == "reset":  # TCP reset instead of a reply
                    import struct

                    self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
                    self.close_connection = True
                    self.connection.close()
                    return None
                if outer.behaviour == "garbage":
                    return self._json(200, b"this is not json")
                return None

        self.behaviour, self.status, self.body = behaviour, status, body
        self.srv = ThreadingHTTPServer((HOST, 0), H)
        self.srv.daemon_threads = True
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://{HOST}:{self.srv.server_address[1]}"

    def stop(self) -> None:
        self.srv.shutdown()
        self.srv.server_close()
        self.thread.join(timeout=5)


# -- subprocess helpers
def start_proc(args: list[str], env: dict[str, str]) -> subprocess.Popen[bytes]:
    return subprocess.Popen(  # noqa: S603 (our own interpreter and our own modules)
        [sys.executable, *args], cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )


def stop_proc(p: subprocess.Popen[bytes]) -> bytes:
    """Stop a child we started; returns its output."""
    if p.poll() is None:
        p.terminate()
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait(timeout=10)
    if p.stdout is None or p.stdout.closed:  # stopping twice (as test_crash_d2_subprocess does) is harmless
        return b""
    out = p.stdout.read()
    p.stdout.close()
    return out
