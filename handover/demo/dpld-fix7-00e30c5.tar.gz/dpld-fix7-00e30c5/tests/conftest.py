"""Fixtures for the desk tests. `env.rig(...)` builds a started Desk on fakes; everything is stopped at teardown."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

import pytest
from support import Rig, build_rig

from demo_only.fakes_server import FakesServer, serve_fakes_in_thread, stop_fakes
from lead_desk.server import serve_in_thread


class Env:
    def __init__(self, tmp_path: Path) -> None:
        self.tmp = tmp_path
        self._n = 0
        self.rigs: list[Rig] = []
        self._stops: list[Callable[[], None]] = []

    def rig(self, **kw: Any) -> Rig:
        self._n += 1
        sub = self.tmp / f"rig{self._n}"
        sub.mkdir()
        r = build_rig(sub, **kw)
        self.rigs.append(r)
        return r

    def serve(self, r: Rig) -> str:
        """Start the real HTTP server (port 0) around r.desk; returns the base URL."""
        base, stop = serve_in_thread(r.desk, port=0)
        self._stops.append(stop)
        return base

    def fakes(self, mode: str = "keyed", crm_mode: str = "keyed") -> tuple[FakesServer, str]:
        srv, url, th = serve_fakes_in_thread(mode, 0, crm_mode)
        self._stops.append(lambda: stop_fakes(srv, th))
        return srv, url

    def close(self) -> None:
        for stop in reversed(self._stops):
            try:
                stop()
            except Exception:  # noqa: BLE001, S110 (teardown must reach every item)
                pass
        for r in self.rigs:
            for d in r.desks:
                try:
                    d.close()
                except Exception:  # noqa: BLE001, S110
                    pass


@pytest.fixture
def env(tmp_path: Path) -> Iterator[Env]:
    e = Env(tmp_path)
    try:
        yield e
    finally:
        e.close()
