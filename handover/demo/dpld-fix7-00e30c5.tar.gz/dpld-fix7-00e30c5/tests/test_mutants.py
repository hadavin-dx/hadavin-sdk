"""Mutation guards (test side only, nothing in src). Each shows the tests can detect one fault: it
weakens the desk, re-runs a real test body and requires the expected AssertionError. Not a proof of correctness."""

from __future__ import annotations

import importlib.resources
import re
import sqlite3
import threading
from typing import Any

import pytest
from test_flow import cross_source_dupe_body, retry_twice_body

from lead_desk.desk import Desk

SEAM_START, SEAM_END = "-- mutation-seam: unique_email_key", "-- end mutation-seam"
UNIQUE_INDEX = "leads_email_key_uq"


def schema_without_unique_key() -> str:
    sql = importlib.resources.files("lead_desk").joinpath("schema.sql").read_text(encoding="utf-8")
    assert sql.count(SEAM_START) == 1 and sql.count(SEAM_END) == 1, "the mutation-seam marker is missing or doubled"
    a, b = sql.index(SEAM_START), sql.index(SEAM_END) + len(SEAM_END)
    weak = sql[:a] + sql[b:]
    assert UNIQUE_INDEX in sql and UNIQUE_INDEX not in weak  # the weakened version really lacks the index
    return weak


def test_mutant_no_unique_key(env, monkeypatch: pytest.MonkeyPatch) -> None:
    applied: list[bool] = []

    def no_such_lead(self: Desk, conn: Any, email_key: str) -> None:
        applied.append(True)

    monkeypatch.setattr(Desk, "_lookup_email_key", no_such_lead)
    rig = env.rig(schema_sql=schema_without_unique_key())
    with pytest.raises(AssertionError, match=re.escape("leads == 1")) as info:
        cross_source_dupe_body(rig)
    assert applied, "the weakened lookup was never called: the mutation was not applied"
    assert "got 2" in str(info.value)


def test_mutant_no_claim(env, monkeypatch: pytest.MonkeyPatch) -> None:
    applied: list[bool] = []
    lock = threading.Lock()

    def always_claimed(self: Desk, conn_or_none: Any, lead_id: str) -> bool:
        """The weakened claim: moves the row to `sending` WITHOUT the state precondition and always says yes."""
        with lock:
            applied.append(True)
        con = sqlite3.connect(self.config.db_path, isolation_level=None, timeout=10)
        try:
            con.execute("UPDATE followups SET state='sending', attempts=attempts+1 WHERE lead_id=?", (lead_id,))
        finally:
            con.close()
        return True

    monkeypatch.setattr(Desk, "_claim", always_claimed)
    rig = env.rig(outbox="blind")
    with pytest.raises(AssertionError, match=re.escape("emails == 1")) as info:
        retry_twice_body(rig)
    assert applied, "the weakened claim was never called: the mutation was not applied"
    assert "got 2" in str(info.value)
