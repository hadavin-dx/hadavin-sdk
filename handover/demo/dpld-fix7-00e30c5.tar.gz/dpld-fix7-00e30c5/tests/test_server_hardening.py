"""HTTP-layer hardening: framing, header and target abuse, a lost reply, and many simultaneous connections.
Made-up data only. Each test is one case from the review/hostile runs; the old server failed all of them."""

from __future__ import annotations

import json
import os
import socket
import struct
import threading
import time

import pytest
from support import BlockAt, call, lead, raw_exchange, run_threads, wait_until

from lead_desk import server
from lead_desk.constants import LISTEN_QUEUE

BODY = json.dumps({"source": "form", "source_ref": "r1", "payload": lead()}).encode()


def pending_zero(base: str) -> bool:
    return bool(call(base, "GET", "/counts")[1]["pending_followups"] == 0)


def rejected(base: str) -> int:
    return int(call(base, "GET", "/counts")[1]["rejected_envelopes"])


def head(extra: str, length: str | None = None) -> bytes:
    cl = f"Content-Length: {length}\r\n" if length is not None else ""
    return f"POST /leads HTTP/1.1\r\nHost: x\r\n{cl}{extra}Connection: close\r\n\r\n".encode()


def test_short_body_socket_held_open_is_408(env, monkeypatch) -> None:
    monkeypatch.setattr(server._Handler, "timeout", 1.0)
    base = env.serve(env.rig())
    host, port = base.removeprefix("http://").split(":")
    t0 = time.monotonic()
    with socket.create_connection((host, int(port)), timeout=10) as s:
        s.sendall(head("", str(len(BODY) + 50)) + BODY)  # announces 50 more bytes than it sends, then stays silent
        data = b""
        while chunk := s.recv(4096):
            data += chunk
    assert time.monotonic() - t0 < 8
    assert data.startswith(b"HTTP/1.0 408") or data.startswith(b"HTTP/1.1 408")
    assert json.loads(data.partition(b"\r\n\r\n")[2]) == {"error": "request_timeout", "receipt_id": None}
    assert rejected(base) == 1


def test_short_body_client_closes_is_400(env) -> None:
    base = env.serve(env.rig())
    host, port = base.removeprefix("http://").split(":")
    with socket.create_connection((host, int(port)), timeout=10) as s:
        s.sendall(head("", str(len(BODY) + 50)) + BODY)
        s.shutdown(socket.SHUT_WR)
        data = b""
        while chunk := s.recv(4096):
            data += chunk
    assert b" 400 " in data.split(b"\r\n", 1)[0]
    assert rejected(base) == 1


@pytest.mark.parametrize("length", ["9" * 20, "9" * 4301, "0" * 5000 + "9" * 20, "9" * 19])
def test_huge_content_length_is_413_without_waiting(env, length) -> None:
    base = env.serve(env.rig())
    t0 = time.monotonic()
    status, body = raw_exchange(base, head("", length), timeout=8)  # sends no body at all
    assert (status, body) == (413, {"error": "too_large", "receipt_id": None})
    assert time.monotonic() - t0 < 8
    assert rejected(base) == 1


def test_zero_padded_small_length_still_works(env) -> None:
    base = env.serve(env.rig())
    status, body = raw_exchange(base, head("", "000" + str(len(BODY))) + BODY)
    assert status == 201 and body["verdict"] == "new"


def test_conflicting_content_length_is_400(env) -> None:
    base = env.serve(env.rig())
    req = head(f"Content-Length: {len(BODY) + 5}\r\n", str(len(BODY))) + BODY
    status, body = raw_exchange(base, req)
    assert (status, body) == (400, {"error": "bad_envelope", "receipt_id": None})
    assert rejected(base) == 1
    assert call(base, "GET", "/counts")[1]["received"] == 0


@pytest.mark.parametrize("target", ["http://[/", "//[", "http://[::1/x", "/leads/%ff%fe/../[", "http://a:b:c/"])
def test_unparsable_target_is_json_400_or_404(env, target) -> None:
    base = env.serve(env.rig())
    status, body = raw_exchange(base, f"GET {target} HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n".encode())
    assert status in (400, 404), status
    assert isinstance(body, dict) and "error" in body


@pytest.mark.parametrize("item", ["R" + "9" * 20, "D" + "1" * 4301, "O" + "9" * 19, "F" + "9" * 20])
@pytest.mark.parametrize("action", ["retry", "resolve"])
def test_huge_item_id_is_not_500(env, item, action) -> None:
    base = env.serve(env.rig())
    status, body = call(base, "POST", f"/review/{item}/{action}", body={"decision": "sent"})
    assert status in (404, 409), (status, body)  # F + digits is just an unknown lead id: 404
    assert "error" in body


def test_reply_write_fails_after_commit_followup_still_runs(env) -> None:
    hook = BlockAt("A")  # holds the request after it has read the body, before the commit
    rig = env.rig(hooks=hook)
    base = env.serve(rig)
    host, port = base.removeprefix("http://").split(":")
    s = socket.create_connection((host, int(port)), timeout=10)
    s.sendall(head("", str(len(BODY))) + BODY)
    assert hook.reached.wait(timeout=15)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
    s.close()  # sends a reset: the reply can no longer be written
    time.sleep(0.3)
    hook.release.set()
    wait_until(lambda: pending_zero(base), what="follow-up driven although the reply write failed")
    assert rig.leads() == 1
    assert rig.state()[0] == "sent"
    assert rig.outbox.count == 1


def _burst(env, n: int, retry: bool) -> tuple[int, list[object]]:
    """n connections at the same moment, one lead (same email, different request ids). Returns (connections the
    operating system refused on the first try, results). With retry, a refused connection is tried again with the
    SAME request id (safe: the desk treats it as a replay)."""
    rig = env.rig()
    base = env.serve(rig)
    refused = [0]
    lock = threading.Lock()

    def one(i: int):  # type: ignore[no-untyped-def]
        def go():  # type: ignore[no-untyped-def]
            body = {"source": "form", "source_ref": f"b{i}", "payload": lead()}
            for attempt in range(6 if retry else 1):
                try:
                    return call(base, "POST", "/leads", body=body, timeout=60)
                except OSError as e:
                    if attempt == 0:
                        with lock:
                            refused[0] += 1
                    if not retry or attempt == 5:
                        raise e
                    time.sleep(0.2 * (attempt + 1))

        return go

    results = run_threads([one(i) for i in range(n)])
    errors = [r for r in results if isinstance(r, BaseException) or r is None]
    assert not errors, f"{len(errors)} of {n} got no answer; first-try refused {refused[0]}: {errors[:1]!r}"
    assert {r[0] for r in results} <= {200, 201, 503}  # type: ignore[index]
    wait_until(lambda: pending_zero(base), what="follow-ups finished", timeout=90)
    assert rig.outbox.count <= 1  # one lead, never a second email
    return refused[0], results


def test_150_simultaneous_connections_all_get_an_answer(env) -> None:
    assert LISTEN_QUEUE >= 1000
    _burst(env, 150, retry=False)


def test_300_simultaneous_connections_all_get_an_answer_with_retry(env) -> None:
    """This Windows machine refuses part of a 300-connection burst before the desk can accept (measured: it
    answers about 200 at once whatever the backlog); a client that retries with the same request id gets all."""
    _burst(env, 300, retry=True)


@pytest.mark.skipif(not os.environ.get("LEAD_DESK_LOAD_N"), reason="measurement run: set LEAD_DESK_LOAD_N")
def test_measure_burst(env) -> None:
    n = int(os.environ["LEAD_DESK_LOAD_N"])
    refused, results = _burst(env, n, retry=os.environ.get("LEAD_DESK_LOAD_RETRY") == "1")
    counts: dict[int, int] = {}
    for r in results:
        counts[r[0]] = counts.get(r[0], 0) + 1  # type: ignore[index]
    print(f"MEASURED n={n} first_try_refused={refused} status_counts={dict(sorted(counts.items()))}")
